# Graph Report - $HOME/.hermes/profiles/sage  (2026-08-10)

## Corpus Check
- cluster-only mode — file stats not available

## Summary
- 12966 nodes · 23832 edges · 1342 communities (837 shown, 505 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 475 edges (avg confidence: 0.75)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `396c6878`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- Evaluate
- train.optim.lr
- properties
- properties
- script_utils.py
- properties
- aiq.py
- gen_trt_engine
- Asset Validation Checks
- properties
- string
- AutoML Augmentation Params
- automl_disabled_parameters
- automl_disabled_parameters
- preflight_manifest.py
- train
- properties
- properties
- properties
- properties
- generate_dtsi.py
- properties
- ovrtx-render-service/scripts/run.py
- required
- required
- properties
- required
- automl_disabled_parameters
- properties
- properties
- content_agent_client.py
- print_log
- run_finetune.py
- next_step
- gen_trt_engine.tensorrt.calibration
- properties
- analyze_kpi.py
- train
- Deploy RTVI-CV-3D Stack
- properties
- simready_package.py
- type
- train
- run_rflow_ct.py
- train
- automl_disabled_parameters
- warnings
- optimization-plan.schema.json
- properties
- required
- automl_disabled_parameters
- properties
- USD Performance Tuning Workflow
- TimeMeasure
- properties
- properties
- usd-validation-runner/scripts/usd_validation_executor.py
- discover_assets.py
- OrderedDict
- .load_model
- properties
- simready-validate/scripts/run.py
- properties
- required
- target_coverage
- properties
- physical-ai-video-data-augmentation/scripts/endpoint_common.sh
- properties
- deploy_async.py
- properties
- run_nv_reason_cxr.py
- properties
- properties
- TestClassifyBound
- messager_reference.py
- properties
- run_mr_brain_finetune.py
- properties
- properties
- properties
- properties
- automl_disabled_parameters
- properties
- _meta
- properties
- convert-to-usd/scripts/run.py
- properties
- properties
- hf_benchmarks.py
- train
- SourceName
- operation-curation.schema.json
- audit-report.schema.json
- properties
- properties
- earth2studio-create-diagnostic/references/testing-guide.py
- huggingface-vision-trainer/scripts/dataset_inspector.py
- model_inventory
- run_vae_finetune.py
- run_ctmr.py
- actions
- evaluate
- properties
- properties
- uart_session.py
- properties
- enum
- properties
- train.lr
- properties
- ovrtx Renderer
- pluginctl
- required
- TestValidateFormat
- PaperManager
- run_mr_brain.py
- run_mr.py
- properties
- properties
- properties
- physical-ai-people-attribute-search/scripts/endpoint_common.sh
- required
- type
- earth2studio-create-prognostic/references/method-templates.py
- run_ct_image.py
- assemble-package-source/scripts/run.py
- kit_app_template_cad.py
- properties
- train
- object_detection_training.py
- NvInferServerCustomProcess
- required
- required
- hierarchy_dedupe
- setup-preflight.schema.json
- properties
- properties
- properties
- properties
- properties
- properties
- properties
- properties
- render_card.py
- usd-convert-cad/scripts/run.py
- properties
- properties
- enum
- DDMTensorRTEngine
- preflight_series.py
- check_interconnect.py
- earth2studio-create-diagnostic/references/method-templates.py
- _pinmux_dt.py
- detect_jetson.sh
- dataset_convert
- ModelName
- command
- huggingface-llm-trainer/scripts/dataset_inspector.py
- _pinmux_common.py
- cmd_commit
- properties
- properties
- simready-conform-profile/scripts/run.py
- probe-snapshot.schema.json
- layer_norm_forward
- fetch_api_support.py
- properties
- test_run_rflow_ct.py
- properties
- inference
- setup-nvidia-gpu-host.sh
- train
- parallel_npy_load.py
- properties
- required
- properties
- required
- properties
- align_token_usage.py
- cuopt-developer
- MissingNumberDetector
- cmd_set_pin
- properties
- properties
- CAD to SimReady
- server.py
- automl_disabled_parameters
- train
- BM25Retriever
- UartSession
- run_ct_from_mask.py
- properties
- properties
- conv2d_with_bias_dilation_groups.py
- conv_transpose_2d.py
- conv_transpose_3d.py
- DashboardNotifier
- automl_default_parameters
- modify_pinmux.py
- run_ct_mask.py
- validate-usd-minimum/scripts/run.py
- conv3d_with_bias_dilation_groups.py
- Apply Configuration Guide
- calibration_manager.py
- vss-deploy-detection-tracking-2d/scripts/common.sh
- instancing
- automl_disabled_parameters
- automl_disabled_parameters
- export
- receive_incident
- export_ddm_to_tensorrt_reference.py
- recommend.py
- omni-asset-validate/scripts/run.py
- 04_matmul/triton_kernel.py
- test_nv_reason_cxr.py
- required
- required
- recipe_tool.py
- properties
- FET_004_SIMULATE_MULTI_BODY_PHYSICS/scripts/run.py
- NVIDIA RAG Blueprint Skill
- tao-run-on-slurm
- open_claw_dashboard_notifier.py
- required
- capacity_report.py
- .process_sop_check
- mujoco-usd-converter/scripts/run.py
- usd-convert-cad/scripts/check_dependencies.py
- identify-asset-context/scripts/run.py
- validate_report.py
- TAO DEFT AOI
- export
- evaluate
- 03_layernorm/triton_kernel.py
- collect_metrics.sh
- NotifierBase
- properties
- required
- enum
- artifacts
- required
- AIQ Deploy Skill
- generate_pipeline.py
- validate_memory_format
- _anatomy.py
- main
- content_agent_material_cleanup.py
- content-agents/scripts/run.py
- urdf-usd-converter/scripts/run.py
- properties
- prepare_cosmos3_vlm_checkpoint.py
- Train a sentence-transformers Model
- tao-run-automl
- NVIDIA-Medtech/NV-Generate-CTMR
- author_grasp_line.py
- matmul
- validate_pipeline.py
- extract_elements_and_properties
- generate-benchmark-charts.py
- check_role.py
- jetson-customize-pinmux
- render_card
- render_preview.py
- concepts
- cluster-azure/scripts/preflight.sh
- cluster-microk8s/scripts/preflight.sh
- pre_submit_guard.py
- ml-plugin-app.py
- dataset
- train
- inference
- 03_softmax/cutile_python.py
- 02_softmax/triton_kernel.py
- matmul
- 05_attention/triton_kernel.py
- 03_rope_inplace_splitbuffer/fixed_launch.py
- group_norm_kernel
- vss-manage-video-io-storage
- main
- _make_dataset
- automl_disabled_parameters
- properties
- required
- enum
- composition
- dataset.augmentation.aug_prob
- automl_default_parameters
- validate_syntax
- SAMSegmentationDataset
- jetson-customize-pinmux
- test_run_mr.py
- properties
- physical-ai-video-data-augmentation/scripts/preflight_credentials.sh
- validate_training_csv.py
- model
- learning_rate
- evaluate
- rmsnorm
- rmsnorm
- 03_rope_inplace_splitbuffer/autotuned_launch.py
- split_k_gemm.py
- PyTorch Implementation Tracing Workflow
- Image Classification Training
- Assembly Root Management
- BM25 Retrieval & Scoring
- Pipeline Metadata Extraction
- Pipeline Structure Validation
- Datasource Testing
- main
- filename_fast_path.py
- test_run_mr_brain.py
- changenet_data_pair_prepare.py
- evaluate
- train
- evaluate
- evaluate
- train
- export
- gen_trt_engine
- actions
- inference
- matmul
- Clinical ASR Build
- fmha_kernel
- Riva NIM Setup
- sage-bioclip2
- blocks_scaling.py
- TestBM25Retriever
- main
- TRL Training on Hugging Face Jobs
- test_run_mr_brain_finetune.py
- apply_metadata
- required
- properties
- Physical AI Defect Image Generation
- Azure Provider Registration
- Azure Inference Preflight
- NIM Operator Preflight
- Osmo Azure Preflight
- Osmo Barrier Sync
- Training Hyperparameters
- TensorRT Calibration
- Model Export Schema
- 4D Tensor Matmul
- Sentence Transformer Training
- Slack Notification System
- MoE Implementation Patterns
- ds_sop_process.py
- test_fetch_api_support.py
- collect_dynamo_debug_bundle.py
- earth2studio-create-prognostic/references/skeleton-template.py
- main
- Build BSP Source Skill
- config.py
- properties
- test_run_vae_finetune.py
- properties
- Osmo K8s Preflight
- DEFT State Initialization
- Inference Spec Preparation
- evaluate
- gen_trt_engine
- export
- inference
- model
- inference
- train
- export
- inference
- model
- train
- prune
- quantize
- evaluate
- vector_add
- vector_add
- train_cross_encoder_distillation_example.py
- train_sparse_encoder_distillation_example.py
- apply_config.sh
- hsb-setup
- automl_default_parameters
- main
- scales_well.py
- extract
- test_basic.py
- Hugging Face Spaces
- Context Packs README
- nemotron-customize
- _write_nifti
- validator-concepts.schema.json
- inference-nvcf/scripts/preflight.sh
- osmo-cli/scripts/preflight.sh
- physical-ai-people-attribute-search/scripts/preflight_credentials.sh
- detr-resnet50-cppe5/train.py
- append_stage
- gen_trt_engine
- gen_trt_engine
- Classify Task
- gen_trt_engine
- 01_add/cutile_python.py
- cuTile to Triton Conversion Skill
- 3D Average Pooling
- 3D Max Pooling
- Cumulative Sum Kernel
- Image Generation Pipeline
- cuPyNumeric Migration Readiness Skill
- Mask2Former Deploy Skill
- PAS E2E Workflow
- implementation
- lint_data.py
- validate_platform_sink
- validate_element_ordering
- test_validator.py
- invoke_endpoint.py
- teardown.py
- inspect_vllm_uv.py
- lighteval_vllm_uv.py
- Gradio LoRA Space Builder Skill
- Trackio
- jetson-init-source
- nemo-data-designer-plugin Skill
- main.py
- Omniverse Realtime Viewer
- mask_former
- mask_former
- Integrate and create cuTile kernels into 🤗 Transformers
- main
- main
- main
- main
- main
- main
- train_sparse_encoder_example.py
- download_anomalygen_checkpoints.sh
- Kernel Type Templates
- NVIDIA DeepStream SDK
- WES Shared Filesystem and Cache Architecture
- holoscan-setup
- Iterative cuTile Kernel Performance Optimization
- $defs
- run_sample_calibration.py
- mps_solver/model.py
- needs_refactor.py
- BufferRetriever
- TestNewElements
- SOP Inference Microservice Evaluation Workflow
- mirror_image.py
- _inspect_evals_tasks_root
- huggingface-llm-trainer/scripts/estimate_cost.py
- HF Paper Publisher Skill
- hf_model_card_frontmatter.sh
- hf_model_papers_auth.sh
- huggingface-vision-trainer/scripts/estimate_cost.py
- bench_vllm.sh
- Jetson Memory Audit
- build_metric_bundle_example
- Nemotron Data Prep
- test_run_ct_image.py
- test_run_ct_mask.py
- _extract_case
- _write_nifti
- usd-convert-cad/scripts/report_schema.json
- Viewer Input Routing
- az-sub-init.sh
- generate_configs.py
- Handler
- Skill Card Generator
- scripts/run.sh
- tao-train-action-recognition/schemas/manifest.json
- train
- tensorrt
- train
- tensorrt
- train
- tao-train-depth-anything-v2/schemas/manifest.json
- gen_trt_engine
- train
- DINO Skill Guide
- actions
- train
- FastFoundationStereo Skill Guide
- tao-train-foundation-stereo/schemas/manifest.json
- gen_trt_engine
- train
- gen_trt_engine
- tensorrt
- gen_trt_engine
- train
- gen_trt_engine
- tensorrt
- transform
- last_layer_learning_rate
- tao-train-nvpanoptix3d/schemas/manifest.json
- train
- actions
- dataset
- train
- tensorrt
- train
- RT-DETR Model Manifest
- Training Hyperparameters
- TensorRT Calibration
- Training Hyperparameters
- Sparse4D Model Manifest
- Dataset Conversion Schema
- Evaluation Schema
- Export Schema
- Training Schema
- Visual ChangeNet Manifest
- Training Hyperparameters
- Matmul Kernel Implementation
- Softmax CUDA Implementation
- GEMV Kernel Implementation
- Environment Configuration Reference
- update_batch_size.sh
- AMC RTSP Mode
- Physical AI Defect Image Generation
- tao-finetune-cosmos-reason
- local-cache-design.md
- IncumbentCallback
- Physical AI Skills
- Osmo Workflow Orchestration
- TAO Port HuggingFace Model Skill
- enum
- run_video_calibration.py
- nv_msgbroker
- DeepStream Profiling Skill
- earth2studio-create-diagnostic Skill
- earth2studio-create-prognostic Skill
- SageMaker Deployment Planner
- run_aws
- nemo-mbridge-perf-activation-recompute Skill
- test_run_ct_from_mask.py
- Omniverse Asset Validation
- _write_report
- Omniverse Streaming Runtime
- RAG Evaluation Framework
- FoodSeg Segmentation Training
- HuggingFace Fine-Tune Detailed Workflow Map
- evaluate
- export
- tao-train-centerpose/schemas/manifest.json
- export
- evaluate
- gen_trt_engine
- inference
- train
- tao-train-deformable-detr/schemas/manifest.json
- export
- evaluate
- inference
- quantize
- train
- evaluate
- export
- inference
- quantize
- train
- distill
- evaluate
- export
- inference
- quantize
- train
- evaluate
- export
- inference
- quantize
- train
- quantize
- train
- export
- quantize
- model
- tao-train-mask-auto-encoder/schemas/manifest.json
- inference
- evaluate
- train
- quantize
- train
- tao-train-nvdinov2/schemas/manifest.json
- teacher_temperature
- weight_decay
- evaluate
- export
- inference
- train
- evaluate
- inference
- prune
- quantize
- inference
- evaluate
- export
- gen_trt_engine
- inference
- evaluate
- tao-train-oneformer/schemas/manifest.json
- evaluate
- gen_trt_engine
- train
- tao-train-optical-inspection/schemas/manifest.json
- export
- evaluate
- gen_trt_engine
- inference
- train
- gen_trt_engine
- train
- distill
- evaluate
- export
- inference
- quantize
- train
- tao-train-segformer/schemas/manifest.json
- export
- evaluate
- inference
- quantize
- train
- inference
- quantize
- evaluate
- inference
- segment_evaluate
- segment_inference
- segment_train
- train
- fetch_resources.sh
- README.md
- Texture Defect Generation Day 1 Real Alignment Workflow
- enum
- model.dropout_ratio
- SentenceTransformer
- BufferProvider
- DeepStream Pipeline Builder Skill
- .assert_platform_match
- check_router_health.py
- bashrc_hsb.sh
- convert_to_gguf.py
- find_models_by_paper.sh
- hf_enrich_models.sh
- Hugging Face ZeroGPU Skill
- bench_ollama.sh
- nemo-evaluator-plugin Skill
- response_guidance
- Nemotron Retrieval Recipes Skill Card
- _write_report
- Omniverse USD Performance Tuning
- operations/manifest.json
- USD Validation Runner
- Reolink Focus Control
- plugin-app.py
- tests/conftest.py
- AutoMLRunner
- stage_backbone.py
- inference
- train
- export
- optim
- evaluate
- train
- sem_seg_head
- quantize
- train
- 02_matmul/cutile_julia.jl
- Deploy and Use RT-VLM Dense Captioning
- update_output_sink.sh
- write_deployment_log.sh
- normalize
- Setup Task
- Performance Tuning Guide
- TAO Train Grounding DINO
- FrameSampler
- OCRNet Export
- TransformGizmo
- accelerated-computing-cudf
- Routing: Python API Examples
- cuPyNumeric HDF5 I/O Skill
- Idioms That Block
- nvmultiurisrcbin
- embed_images
- render-mermaid-for-pdf.py
- Dynamo Failure Decision Tree
- DataSource Validation Guide
- Deterministic Forecast Troubleshooting
- jetson-inference-mem-tune
- artifact_hints.sh
- NeMo-RL Auto Research Skill Card
- Viewer Control Patterns
- properties
- output
- inference-nim-operator/scripts/install.sh
- RAG Helm Deployment
- Image Metadata Naming and Eventlog Linking
- query-and-plot-durations.py
- sigpipe-pipefail-regression.sh
- main
- TAO Analyze ChangeNet RCA Skill
- segformer-b0-foodseg103/infer.py
- TAO Workflow Consistency Guide
- tao-run-inference-service
- TAO Inference Microservice
- evaluate
- gen_trt_engine
- inference
- Deformable DETR Deploy
- evaluate
- gen_trt_engine
- inference
- Depth Anything v2 Deploy
- GPU Evaluation Config
- GPU Inference Config
- GPU Evaluation Config
- GPU Inference Config
- GPU Evaluation Config
- GPU Inference Config
- evaluate
- tensorrt
- tensorrt
- tensorrt
- evaluate
- tensorrt
- sem_seg_head
- optim
- Optical Inspection Deploy
- GPU Evaluation Config
- TensorRT Engine Generation
- GPU Inference Config
- PointPillars Train Deploy
- GPU Evaluation Config
- GPU Inference Config
- GPU Evaluation Config
- TensorRT Engine Generation
- GPU Inference Config
- GPU Evaluation Config
- GPU Inference Config
- CUDA Julia Verification
- Platform Reference
- update_stream_sources.sh
- Base Profile Reference
- Workflow D: Alert Subscriptions
- E2E Workflow Config
- Search Strategies
- Qwen3-235B PVC
- Standalone Runtime Setup
- Input Controller
- Render Settings
- Scene Manager
- Stage Queries
- nv-reason-cxr
- Nemotron Policy Generator
- OneFormer Export
- Pipeline
- Calibrate Sample Dataset Skill
- lp_basic/client.py
- milp_basic/client.py
- pdp_basic/client.py
- vrp_basic/client.py
- vrp_simple/client.py
- DeepStream Development Skill
- DeepStream Import Vision Model Skill
- Config File Templates Guide
- DeepStream SOP Inference Microservice Skill
- Dynamo Recipe Runner
- graphify Skill
- local_manifest.py
- main
- baseline_hf_api.sh script
- apply.sh
- bench_llama_cpp.sh
- nemo-mbridge-mlm-bridge-training Skill
- nemo-mbridge-multi-node-slurm Skill
- nemo-mbridge-perf-expert-parallel-overlap Skill
- Retriever Query Workflow
- grep_corpus.py
- nemo-rl-auto-research
- Nemotron Policy Generator Skill Card
- Tauri + Rust OVRTX Omniverse Realtime Viewer
- preflight_urls.sh
- Azure OSMO Setup
- setup.sh
- system_node_capacity_test.sh
- install-terraform.sh
- inference-azure/scripts/install.sh
- llm_server.sh
- render_side_by_side.sh
- stage_run_artifacts.sh
- PhysicsNeMo Search Recipes
- Docker Build & Deploy for Sage Edge Plugins
- Job Scheduling and Liveness
- Sage Documentation Index
- onnode-verify-loop.sh
- sage-waggle/scripts/register-ecr-version.py
- tao-analyze-changenet-rca/hooks/rca-script-check.sh
- tao-analyze-gaps-visual-changenet/hooks/rca-script-check.sh
- CLIP Fine-tuning Skill
- Cosmos-RL Launch Intake and Preflight
- main
- main
- smolvlm-256m-vqav2/run_eval.py
- smolvlm-256m-vqav2/train.py
- train.py
- Image Grounding Pipeline
- Video Reasoning Annotation Pipeline
- get_prompt
- get_prompt
- mining-script-check.sh
- routing-script-check.sh
- parse_args
- TAO Train Image Classification
- TAO Train Mask2Former
- TAO Train Mask Auto Encoder
- TAO Train Mask Grounding DINO
- tao-train-metric-learning-recognition
- tao-train-nvdinov2
- TAO Train OCDNet
- TAO Train OCRNet
- TAO Train OneFormer
- Visual ChangeNet Deploy
- validate
- CuTile Autotuning Skill
- prelaunch_nvinfer_engine.sh
- run_app_and_wait.sh
- setup_tracker_reid.sh
- VSS Prerequisites Check
- probe_remote_models.sh
- VSS Agent /generate Endpoint
- vss-setup-behavior-analytics
- Pretrained Bundle Setup Workflow
- MeshContext
- nrl-k8s CLI
- Install Kit
- legate.io.hdf5
- Viewport
- nvidia.dali.experimental.dynamic
- OSMO Logs Reader Agent
- OSMO Workflow Patterns Reference
- OvRtxRendererAdapter
- Application
- pywaggle Plugin
- rtdetr-deploy
- BioCLIP Plugin
- aiq-deploy
- Reference cuFOLIO workflows
- cuopt_server.cuopt_service
- nvmsgbroker
- nvtracker
- BatchMetadataOperator
- Flow
- NvMultiObjectTracker
- DS Run Pipeline Steps 6-7
- benchmark-ds.sh
- ds-kitti-dump.sh
- ds-perf-run.sh
- ds-single-stream.sh
- ds-sweep.sh
- extract-frame.sh
- benchmark-trtexec.sh
- cleanup.sh
- hf-download-config.sh
- hf-list-files.sh
- ngc-download.sh
- ngc-list-files.sh
- safetensors-to-onnx.sh
- md-to-pdf.sh
- compose_reference.yaml
- copy_sources_reference.sh
- start_server.sh
- earth2studio-data-fetch Evaluation Report
- earth2studio-discover Evaluation Report
- earth2studio-install Evaluation Report
- check_conda.sh
- check_ngc_image.sh
- hsb_phase_runner.sh
- Local Models Hardware Acceleration
- Hub Discovery Guide
- Object Detection Training Reference
- plan.sh
- DUT Access Contract
- mcore-linting-and-formatting Skill
- mcore-run-on-slurm Benchmark
- mcore-split-pr Benchmark
- mcore-testing Benchmark
- mcore-testing Skill
- nemo-automodel-distributed-training Benchmark
- nemo-automodel-launcher-config Benchmark
- nemo-automodel-model-onboarding Skill
- nemo-automodel-recipe-development Benchmark
- MLM vs Bridge Training
- Activation Recompute
- nemo-mbridge-perf-cpu-offloading Benchmark
- MoE Dispatcher Selection Skill Card
- nemo-mbridge-perf-parallelism-strategies
- retriever ingest
- Evaluation Deployment Context
- NVIDIA Skill Finder
- preflight.sh script
- Camera Auto-Select
- Cloud Assets
- pick_best_step.sh
- physical-ai-defect-image-generation/scripts/preflight_credentials.sh
- preflight_pod_template.sh
- MicroK8s Cluster Setup
- Robot Assembly Auto-Labeling Config
- Trailer Dashcam Auto-Labeling Config
- Warehouse Auto-Labeling Config
- VDA Setup Guide
- prepare_demo_assets.sh
- vlm_server.sh
- BirdNET Audio Debugging
- BirdNET Audio Debugging and Geo-filter
- ECR Build to SES Cutover
- ECR Plugin Examples
- Frame-anchored Batch Consumers and Watchers
- Hugging Face MCP Server
- NVIDIA Jetson Thor Docs Index
- pywaggle2 NodeInfo and GPS API Design
- Sage Plugin
- Sage 3D Globe Viz
- Detect-then-Classify Vision Pipelines
- tao-analyze-changenet-rca/hooks/_parse-stdin.sh
- rca-defect-coverage.sh
- rca-depth-check.sh
- tao-analyze-changenet-rca/hooks/rca-package.sh
- rca-phase-completeness.sh
- rca-report-check.sh
- tao-analyze-gaps-visual-changenet/hooks/_parse-stdin.sh
- rca-artifacts-check.sh
- rca-label-coverage.sh
- tao-analyze-gaps-visual-changenet/hooks/rca-package.sh
- rca-section-check.sh
- Cosmos-Embed Fine-tuning Skill
- Cosmos-Reason AutoML And DEFT Notes
- VLM / LLM Pipeline Scripts Reference
- Image Referring Expression Configuration Reference
- mining-artifacts-check.sh
- mining-package.sh
- mining-section-check.sh
- tao-mine-aoi-images/hooks/_parse-stdin.sh
- Phase 6 — Container Testing & End-to-End Validation
- tao-route-visual-changenet-samples/hooks/_parse-stdin.sh
- routing-artifacts-check.sh
- routing-coverage-check.sh
- routing-package.sh
- routing-section-check.sh
- DINO Deploy Skill Info
- tao-train-nvpanoptix3d
- PointPillars Skill Card
- Pose Classification Train Skill Info
- Pose Classification Skill Card
- Re-Identification Train Skill Info
- ReID Skill Card
- RT-DETR Deploy
- Resource Plan
- add_streams.sh
- apply_in_container.sh
- cache_nvinfer_engine.sh
- check_container_gpu.sh
- clean_engine_cache.sh
- discover_streams.sh
- load_defaults.sh
- render_box.sh
- setup_gdino.sh
- setup_sparse4d.sh
- start_app_in_container.sh
- synthesize_docker_run.sh
- RTVI-CV Detection & Tracking
- Task-List Setup
- Troubleshooting
- Warehouse Blueprint Reference
- check_credentials.sh
- vss-setup-video-analytics-api
- TAO Deploy Fast Foundation Stereo
- aiperf
- E2E Super Resolution Workflow Config
- Setup Model Cache Workflow Config
- City Traffic Cookbook
- Glass AnomalyGen Config
- Metal Surface AnomalyGen Config
- PCB AnomalyGen Config
- Piazza Cookbook
- Robot Assembly Cookbook
- Trailer Dashcam Cookbook
- Warehouse Cookbook
- ViewerBackend
- Hardware Audit Logic
- Nemotron Retrieval Recipes
- Nemotron Speech
- OSMO CLI Command Reference
- PrimMode.CREATE_NEW
- Neural Reconstruction Router Skill
- People Attribute Search Skill
- Video Data Augmentation Skill
- CommonFactory
- PostProcessing
- SmartRecordConfig
- SourceConfig
- Packaging Sage Knowledge Bundles
- amc-run-sample-calibration
- amc-run-video-calibration
- amc-setup-calibration-stack
- cudaq-guide
- CUDA-Q Onboarding Guide Skill
- cufolio
- Parallel Sharded Data Load Skill
- Data Designer Skill
- Feeder
- MetadataExtractor
- ObjectDetectionTrigger
- Receiver
- nvdsdynamicsrcbin
- nvdsosd
- nvinfer
- nvmultiurisrcbin
- nvstreammux
- nvurisrcbin
- nvv4l2decoder
- EventMessageGenerator
- nvdsmetamux
- nvds_logger
- nvds_msgapi
- nvds_msgapi_disconnect
- nvinfer
- Troubleshooting Guide
- Use Cases: Pipeline Construction Patterns
- Utilities and Configuration Classes
- DeepStream SOP Skill
- DeepStream SOP Inference Microservice README
- Pydantic API Schemas Guide
- Custom C++ Postprocess Plugin Guide
- Basler Camera Support Guide
- Environment Variables Reference
- SOP Architecture Diagram
- DeepStream SOP Inference Microservice Skill Card
- DICOM Metadata Extract Skill Card
- DICOM Metadata Extract Manifest
- DICOM Metadata Extract SKILL.md
- DICOM Series Preflight Manifest
- DICOM Series to Volume Manifest
- earth2studio-data-fetch Skill Card
- earth2studio-discover Skill Card
- earth2studio-install Skill Card
- Finetune ASR
- Hugging Face CLI (hf)
- Hugging Face MCP Server
- HF Memory Estimator (hf_mem)
- Holoscan Conda Installation
- Phase Details — hsb-test
- HuggingFace Best Model Finder
- Hugging Face Community Evals
- Hugging Face Dataset Viewer
- Gradio
- HF Papers Skill
- HF API Tool Builder
- Using timm models with Hugging Face Trainer
- Jetson Customize Camera Skill
- jetson-customize-clocks
- BPMP DTB
- nvpower.sh
- jetson-customize-fan
- jetson-customize-nvpmodel
- jetson-diagnostic
- Recovery-mode entry via boardctl
- Jetson Print BSP Info
- Jetson Print Device Info
- launch-nemo-rl
- mcore-create-issue
- mcore-create-issue Skill
- mcore-linting-and-formatting
- mcore-linting-and-formatting Skill
- mcore-run-on-slurm Skill
- mcore-split-pr Skill
- nemo-automodel-launcher-config Skill
- nemo-automodel-model-onboarding Benchmark
- Model Capabilities and Precision
- Dense LLM Implementation Patterns
- NeMo Data Designer Plugin
- NeMo Evaluator Plugin
- optimizer_cpu_offload
- cuda_graph_scope
- Hierarchical Context Parallel Skill Card
- cp_comm_type
- hierarchical_context_parallel_sizes
- Megatron FSDP Skill Card
- use_megatron_fsdp
- sequence_parallel_input_regather
- MoE Dispatcher Types (alltoall, DeepEP, HybridEP)
- MoE Hardware Configuration Reference
- nemo-mbridge-perf-moe-long-context
- MoE Long Context Skill Card
- nemo-mbridge-perf-moe-optimization-workflow
- nemo-mbridge-perf-moe-vlm-training
- MoE VLM Training Skill Card
- nemo-mbridge-perf-sequence-packing
- nemo-mbridge-recipe-recommender
- Recipe Recommender Skill
- nemo-mbridge-resiliency
- NeMo AutoModel Recipe Development
- nemo-retriever
- NeMo Retriever Skill
- NeMo-RL Auto Research Benchmark
- NeMo-RL Brev Etiquette Benchmark
- NeMo-RL Brev Etiquette Skill Card
- NeMo-RL Docs Benchmark
- nemo-rl-docs
- NeMo-RL Docs Skill Card
- NeMo-RL Session Memory Benchmark
- NeMo-RL Session Memory Skill Card
- NemoClaw User Guide Benchmark
- nemoclaw-user-guide
- NemoClaw User Guide Skill Card
- Nemotron Customize Benchmark
- Calibration Examples
- Container-Backed Benchmarks
- Megatron-Bridge Parallelism And Performance
- Nemotron Policy Generator Benchmark
- Nemotron Retrieval Recipes Benchmark
- nemotron-speech
- NV-Generate-CT (rflow-ct)
- NV-Generate-MR
- OVRTX Render Service
- AOV Switching
- C++ Native ImGui OVRTX Viewer
- decodePickPaths
- enqueuePick
- OrbitCamera
- setEffectLayerFader
- setSelectionOutline
- TextureState
- ovrtx_helpers
- createRenderer
- Stage Queries
- Streaming Message Server Handler Map
- Troubleshooting Scenario Playbooks
- USD Sample Data
- Windows Native Setup
- Pipeline Recipes
- USD Layer Health
- Texture Defect Generation Day 1 Manual ROI Flow
- Texture Defect Generation Day 1 Real Alignment Flow
- Kubernetes OSMO Reference
- Azure AI Foundry Inference
- NVCF Inference
- Robot Assembly Template Generation Prompt
- Trailer Dashcam Augmentation Config
- Trailer Dashcam Prompt Polishing Prompt
- Trailer Dashcam Template Generation Prompt
- Trailer Dashcam Workflow Config
- Warehouse Augmentation Config
- Warehouse Prompt Polishing Prompt
- Warehouse Template Generation Prompt
- Warehouse Workflow Config
- VDA Container Images Reference
- Augmentation + AL Flow
- Auto-Labeling Only Flow
- E2E Parallel Flow
- E2E SR-Gated Flow
- PhysicsNeMo Discover Skill
- RAG API Reference
- Data Catalog Configuration
- Ingestion Configuration
- Migration Guide
- Multimodal Query Configuration
- Notebooks Guide
- Query and Conversation Configuration
- Reasoning and Generation Configuration
- Summarization Configuration
- User Interface Guide
- VLM Configuration
- RAG Blueprint Skill Card
- RAG Eval Skill Card
- rag-perf
- RAG Perf Skill Card
- Riva NIM Setup
- Audio Plugin FLAC Inlining
- Auth API Manifests Reference
- Camera JPEG Metadata and Native Still Acquisition
- Camera Input & RTSP Patterns
- CI Handoff Doc Discipline
- Cloud Trigger / External Notification Pattern
- Cloud Trigger Watchers
- Continuous Producer / Liveness / From-Cache Patterns
- Crop-producer: Detect-Classify Cascade
- Finding First Report and History Probing
- Sage Data Visualization & Data Honesty Rules
- Detect-Crop-Classify Cascade
- DuckDB Documentation Index
- Thor arm64 ECR Deployment
- ECR Build ACPI Failure
- ECR Catalog API and Thor Deploy
- ECR Image Generation
- External Project Edge Porting Review
- Git Bundle Transfer to Node
- GitHub MCP Server
- Graphify Guide
- Hanwha XNP-6400RW Audio
- Jobspec Verification Discipline
- Sage MCP Server Tools
- Milvus SDK Code Helper MCP
- Production ML Plugin Patterns
- Node Access and Job Ownership
- Node Sideload Test and Restore
- Node Stopped Reporting Diagnosis
- Plugin Duration Performance Telemetry
- Producer/Consumer GPU and Shared Mounts
- Publish-vs-Save and Portal Media Rendering
- Publish-vs-Save and Save-Match Design
- Publish-vs-Save Decoupling
- Publish-vs-Save Decoupling Pattern
- Publish vs Save Decoupling
- BirdNET Plugin
- fetch_snapshot
- sagecontinuum GitHub Org Index
- waggle-sensor GitHub Org Index
- Convert a TAO DAFT Dataset Skill
- Cosmos-RL AutoML / HPO
- Cosmos-RL Evaluate and Datasets
- Model Discovery Logic
- PROGRESS.md Tracking Reference
- Research Priorities Reference
- inference.py
- merge_lora.py
- run_eval.py
- HuggingFace Fine-Tune Intake And Preflight
- HuggingFace Fine-Tune Push And Rerun
- tao-finetune-huggingface-model
- Image Grounding Skill Info
- Referring Expressions Skill Info
- Video Reasoning Skill Info
- TAO Workflow Launch Intake
- TAO List Capabilities Skill
- TAO Skill Bank Capabilities
- TAO Repository Structure Guide
- TAO Toolkit Code Patterns
- CV Task Type Guide
- AutoML Class
- Pre-Flight Checks
- Prepare-for-Inference
- Bundled Scripts and Agents
- DEFT AOI RCA (VCN)
- DEFT AOI Mining
- DEFT AOI Routing (VCN)
- Visual ChangeNet Reference
- tao-train-centerpose
- tao-train-deformable-detr
- Depth Anything v2 Troubleshooting
- Quantize Action
- tao-daft validate
- Add cuTile Kernel Workflow
- cuTile Python to Julia Conversion
- Common Translation Gotchas
- File Structure & Registration
- Transformers.js - Machine Learning for JavaScript
- TRL Training Skill
- Upgrade & Rollback
- RTVI-CV API Skill
- VSS Deploy Profile Skill
- VSS Alerts Profile
- Brev Environment Reference
- Data Directory Layout
- Env Overrides Reference
- Deploy Readiness Gate
- Tear down Deployment
- vss-generate-video-calibration
- Workflow A: CV Mode
- Workflow E: Slack Notifications
- vss-query-analytics
- Video Summarization API Reference
- Video Summarization Debugging Reference
- Video Summarization Environment Variables
- so-create-proxy
- tao-analyze-changenet-rca
- TAO VCN Sample Routing Skill
- NVPanoptix3D Training Skill
- tao-train-sparse4d
- nn.LSTM Implementation Trace
- Instance Candidate Finder Spec
- VSS Agent UI
- HAProxy Ingress
- RT-CV
- vss-vios-ingress
- vss-vios-nvstreamer
- enum
- apply-restructure-manifest.schema.json
- properties
- properties
- enum

## God Nodes (most connected - your core abstractions)
1. `Evaluate` - 143 edges
2. `train.gpu_ids` - 140 edges
3. `export` - 134 edges
4. `inference.gpu_ids` - 132 edges
5. `train.cudnn` - 132 edges
6. `wandb.tags` - 132 edges
7. `evaluate.gpu_ids` - 129 edges
8. `train.optim` - 120 edges
9. `gen_trt_engine` - 117 edges
10. `gen_trt_engine.tensorrt` - 109 edges

## Surprising Connections (you probably didn't know these)
- `writeMat4Attribute` --references--> `ovrtx Renderer`  [INFERRED]
  skills/omniverse-realtime-viewer/references/cpp-native-viewer/interaction-features.md → local_app/renderer_runtime.py
- `stepRenderAndUpload` --references--> `ovrtx Renderer`  [INFERRED]
  skills/omniverse-realtime-viewer/references/cpp-native-viewer/presentation-loop.md → local_app/renderer_runtime.py
- `loadStage` --references--> `ovrtx Renderer`  [INFERRED]
  skills/omniverse-realtime-viewer/references/cpp-native-viewer/renderer-session.md → local_app/renderer_runtime.py
- `AxisOverlay` --conceptually_related_to--> `ovrtx Renderer`  [INFERRED]
  skills/omniverse-realtime-viewer/references/gl-viewport-overlay/README.md → local_app/renderer_runtime.py
- `ovrtx Renderer` --conceptually_related_to--> `pxr_worker`  [INFERRED]
  local_app/renderer_runtime.py → skills/omniverse-realtime-viewer/references/stage-hierarchy/README.md

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **cuOpt Numerical Optimization Suite** — skills_cuopt_numerical_optimization_api, skills_cuopt_numerical_optimization_formulation, skills_cuopt_multi_objective_exploration [INFERRED 0.90]
- **AutoMagicCalib Calibration Suite** — skills_amc_run_sample_calibration, skills_amc_run_video_calibration, skills_amc_setup_calibration_stack [INFERRED 0.90]
- **cuPyNumeric Tooling** — skills_cupynumeric_hdf5, skills_cupynumeric_install, skills_cupynumeric_migration_readiness, skills_cupynumeric_parallel_data_load [INFERRED 0.90]
- **DeepStream Development Tooling** — skills_deepstream_dev, skills_deepstream_generate_pipeline, skills_deepstream_import_vision_model, skills_deepstream_profile_pipeline, skills_deepstream_sop [INFERRED 0.90]
- **SOP Inference Pipeline** — nvds_action_detector_api_server, nvds_action_detector_ds_sop_process, nvds_action_detector_vllm_inference, nvds_action_detector_sop_step_checker [EXTRACTED 1.00]
- **Clinical ASR Flywheel** — skills_digital_health_clinical_asr_setup, skills_digital_health_clinical_asr_build, skills_digital_health_clinical_asr_eval, skills_digital_health_clinical_asr_finetune [EXTRACTED 1.00]
- **Holoscan Installation Suite** — skills_holoscan_install_conda, skills_holoscan_install_container, skills_holoscan_install_debian, skills_holoscan_install_source, skills_holoscan_install_wheel [INFERRED 0.95]
- **Dynamo Deployment Suite** — skills_dynamo_interconnect_check, skills_dynamo_recipe_runner, skills_dynamo_router_starter [INFERRED 0.90]
- **Holoscan Sensor Bridge Toolchain** — skills_hsb_setup, skills_hsb_app, skills_hsb_flash, skills_hsb_test [INFERRED 0.95]
- **Jetson I/O Customization Suite** — skills_jetson_customize_pinmux, skills_jetson_customize_uphy, skills_jetson_customize_pcie, skills_jetson_customize_mgbe, skills_jetson_customize_usb [EXTRACTED 1.00]
- **Jetson BSP Deployment Pipeline** — skills_jetson_build_source, skills_jetson_promote_image, skills_jetson_flash_image, skills_jetson_validate_image [EXTRACTED 1.00]
- **Jetson BSP Setup Flow** — skills_jetson_quick_start, skills_jetson_init_target, skills_jetson_init_image, skills_jetson_init_source, skills_jetson_promote_image, skills_jetson_flash_image, skills_jetson_validate_image [INFERRED 0.90]
- **Jetson LLM Optimization Flow** — skills_jetson_llm_serve, skills_jetson_llm_benchmark, skills_jetson_inference_mem_tune, skills_jetson_speculative_decoding [INFERRED 0.85]
- **NeMo Data Designer Workflow** — skills_nemo_data_designer_plugin_autopilot_workflow, skills_nemo_data_designer_plugin_interactive_workflow, skills_nemo_data_designer_plugin_skill_card [EXTRACTED 1.00]
- **Megatron Bridge Performance Tuning** — skills_nemo_mbridge_perf_activation_recompute_skill_card, skills_nemo_mbridge_perf_cpu_offloading_skill_card, skills_nemo_mbridge_perf_cuda_graphs_skill_card, skills_nemo_mbridge_perf_expert_parallel_overlap_skill_card [INFERRED 0.90]
- **MoE Performance Tuning Suite** — skills_nemo_mbridge_perf_moe_comm_overlap_skill, skills_nemo_mbridge_perf_moe_dispatcher_selection_card, skills_nemo_mbridge_perf_moe_hardware_configs_skill, skills_nemo_mbridge_perf_moe_long_context_card, skills_nemo_mbridge_perf_moe_optimization_workflow_card, skills_nemo_mbridge_perf_moe_vlm_training_card [EXTRACTED 1.00]
- **NeMo Retriever Core Workflow** — skills_nemo_retriever_setup, skills_nemo_retriever_query, skills_nemo_retriever_troubleshooting [EXTRACTED 1.00]
- **NeMo-RL Auto Research Framework** — skills_nemo_rl_auto_research_git_workflow, skills_nemo_rl_auto_research_exploration_ideas, skills_nemo_rl_auto_research_experiment_log [EXTRACTED 1.00]
- **Nemotron Retrieval Pipeline** — skills_nemotron_retrieval_recipes_embed, skills_nemotron_retrieval_recipes_rerank, skills_nemotron_retrieval_recipes_evaluation [EXTRACTED 1.00]
- **NV-Generate-CTMR based skills** — skills_nv_generate_ct_rflow, skills_nv_generate_mr, skills_nv_generate_mr_brain, skills_nv_generate_mr_brain_finetune, skills_nv_generate_vae_finetune, skills_nv_segment_ctmr [EXTRACTED 1.00]
- **NV-Segment-CT based skills** — skills_nv_segment_ct, skills_nv_segment_ct_finetune [EXTRACTED 1.00]
- **CAD to SimReady Workflow** — skills_omniverse_cad_to_simready_preflight, skills_omniverse_cad_to_simready_convert_to_usd, skills_omniverse_cad_to_simready_content_agents, skills_omniverse_cad_to_simready_simready_conform_profile, skills_omniverse_cad_to_simready_simready_validate, skills_omniverse_cad_to_simready_ovrtx_render_service, skills_omniverse_cad_to_simready_assemble_package_source, skills_omniverse_cad_to_simready_nv_core_package_sample [EXTRACTED 1.00]
- **RTX Viewer Runtime Stack** — skills_omniverse_realtime_viewer_ovrtx, skills_omniverse_realtime_viewer_ovui, skills_omniverse_realtime_viewer_ovstream, skills_omniverse_realtime_viewer_ov_web_rtc [EXTRACTED 1.00]
- **Local Viewer Core Loop** — local_app_runtime, local_app_renderer_runtime, local_app_viewport [INFERRED 0.90]
- **Stage Interaction Flow** — local_app_input_controller, local_app_selection_controller, local_app_stage_queries, local_app_widgets_prim_info_panel [INFERRED 0.85]
- **Defect Image Generation Pipeline** — skills_physical_ai_defect_image_generation_usd2roi_render, skills_physical_ai_defect_image_generation_augment_image_edit, skills_physical_ai_defect_image_generation_anomaly_infer, skills_physical_ai_defect_image_generation_finetune [EXTRACTED 1.00]
- **HF-PVC-NIM Deployment Pattern** — inference_nim_operator_nims_qwen25_14b_hf_download_job, inference_nim_operator_nims_qwen25_14b_pvc, inference_nim_operator_nims_qwen25_14b_nimservice [EXTRACTED 1.00]
- **PAS Inference Endpoints** — inference_nim_operator_nims_qwen_image_edit_nimservice, inference_nim_operator_nims_qwen3_vl_nimservice, inference_nim_operator_nims_qwen25_14b_nimservice [EXTRACTED 1.00]
- **Robot Assembly VDA Pipeline** — skills_physical_ai_video_data_augmentation_assets_cookbooks_robot_assembly_augmentation_prompts_template_generation_system_prompt, skills_physical_ai_video_data_augmentation_assets_cookbooks_robot_assembly_auto_labeling_auto_labeling_config, skills_physical_ai_video_data_augmentation_assets_cookbooks_robot_assembly_auto_labeling_prompts_event_analysis [EXTRACTED 1.00]
- **Trailer Dashcam VDA Pipeline** — skills_physical_ai_video_data_augmentation_assets_cookbooks_trailer_dashcam_augmentation_prompts_template_generation_system_prompt, skills_physical_ai_video_data_augmentation_assets_cookbooks_trailer_dashcam_auto_labeling_auto_labeling_config, skills_physical_ai_video_data_augmentation_assets_cookbooks_trailer_dashcam_auto_labeling_prompts_event_analysis [EXTRACTED 1.00]
- **Reolink Camera Management** — skills_sage_waggle_references_reolink_focus_control, skills_sage_waggle_references_reolink_snapshot_auth_and_exif, skills_sage_waggle_references_reolink_snapshot_capture [EXTRACTED 1.00]
- **Sage Edge Development Toolchain** — pluginctl, sesctl, ecr [EXTRACTED 1.00]
- **NVIDIA TAO Model Skills** — tao_analyze_gaps_visual_changenet, tao_analyze_gaps_vlm_bcq, tao_convert_dataset_format, tao_finetune_clip, tao_finetune_cosmos_embed, tao_finetune_cosmos_reason [EXTRACTED 1.00]
- **Cosmos-RL AutoML Workflow** — skills_tao_finetune_cosmos_reason_references_cosmos_automl_deft, skills_tao_finetune_cosmos_reason_references_cosmos_reason_automl, skills_tao_finetune_cosmos_reason_references_cosmos_reason_evaluate [EXTRACTED 1.00]
- **HuggingFace Fine-Tune Pipeline** — skills_tao_finetune_huggingface_model_references_core_rules, skills_tao_finetune_huggingface_model_references_research_priorities, skills_tao_finetune_huggingface_model_references_docker_runs, skills_tao_finetune_huggingface_model_references_progress_tracking [EXTRACTED 1.00]
- **TAO CV Integration Pipeline** — skills_tao_port_huggingface_model, tao_pytorch_base, tao_deploy_base [EXTRACTED 1.00]
- **VCN AOI Workflow** — skills_tao_route_visual_changenet_samples, skills_tao_mine_aoi_images, tao_toolkit_data_services [INFERRED 0.90]
- **DEFT AOI Improvement Loop** — skills_tao_analyze_gaps_visual_changenet, skills_tao_route_visual_changenet_samples, skills_paidf_anomalygen, skills_tao_mine_aoi_images, skills_tao_train_visual_changenet [EXTRACTED 1.00]
- **TAO Execution Platforms** — skills_tao_run_on_local_docker, skills_tao_run_on_brev, skills_tao_run_on_kubernetes [INFERRED 0.90]
- **TAO Platform Execution Flow** — skills_tao_run_platform, tao_sdk_build_entrypoint, tao_sdk_slurm_sdk [INFERRED 0.90]
- **SLURM Skill Reference Set** — skills_tao_run_on_slurm_references_slurm_ssh_credentials, skills_tao_run_on_slurm_references_slurm_container_execution, skills_tao_run_on_slurm_references_slurm_preflight_storage, skills_tao_run_on_slurm_references_slurm_execution_sdk [EXTRACTED 1.00]
- **TAO Deploy Workflow** — skills_tao_train_deformable_detr_references_tao_deploy_deformable_detr, skills_tao_train_depth_anything_v2_references_tao_deploy_depth_anything_v2, skills_tao_train_dino_references_tao_deploy_dino_skill_info [INFERRED 0.90]
- **Stereo Depth Estimation Suite** — tao_train_fast_foundation_stereo, tao_deploy_fast_foundation_stereo, tao_train_foundation_stereo, tao_deploy_foundation_stereo [INFERRED 0.95]
- **TAO Toolkit Training Skills** — skills_tao_train_mask_grounding_dino, skills_tao_train_mask2former, skills_tao_train_metric_learning_recognition, skills_tao_train_nvdinov2, skills_tao_train_nvpanoptix3d [INFERRED 1.00]
- **TAO Toolkit Training Skills** — tao_train_ocdnet, tao_train_ocrnet, tao_train_oneformer, tao_train_optical_inspection, tao_train_pointpillars, tao_train_pose_classification, tao_train_reid [INFERRED 0.90]
- **TAO Model Training Skills** — tao_train_rtdetr, tao_train_segformer, tao_train_sparse4d [INFERRED 1.00]
- **TAO Deployment Workflows** — segformer_deploy, rtdetr_deploy [INFERRED 0.90]
- **Visual ChangeNet Classification Flow** — skills_tao_train_visual_changenet_train, skills_tao_train_visual_changenet_evaluate, skills_tao_train_visual_changenet_inference, skills_tao_train_visual_changenet_export [INFERRED 0.90]
- **Visual ChangeNet Segmentation Flow** — skills_tao_train_visual_changenet_segment_train, skills_tao_train_visual_changenet_segment_evaluate, skills_tao_train_visual_changenet_segment_inference [INFERRED 0.90]
- **cuTile to Triton Conversion Pipeline** — skills_tilegym_converting_cutile_to_triton_translations_workflow, skills_tilegym_converting_cutile_to_triton_references_api_mapping, skills_tilegym_converting_cutile_to_triton_references_optimizing_reference, skills_tilegym_converting_cutile_to_triton_references_performance_gotchas [EXTRACTED 1.00]
- **Blackwell GPU Optimization Patterns** — skills_tilegym_converting_cutile_to_triton_references_optimizing_reference, skills_tilegym_converting_cutile_to_triton_translations_advanced_patterns [INFERRED 0.90]
- **Autotune Core Loop** — exhaustive_search, replace_hints, ct_launch [INFERRED 0.90]
- **cuTile Orchestration Pipeline** — main_agent, analyzer_agent, kernel_agent, composer_agent [EXTRACTED 1.00]
- **PyTorch Tracing Knowledge Base** — skills_tilegym_cutile_python_torch_learner_tracing_workflow, torch_learner_codebase_map, torch_learner_dispatch_mechanism, torch_learner_tracing_strategies, torch_learner_language_layers, torch_learner_well_known_ops [INFERRED 0.90]
- **cuTile Performance Optimization Suite** — improve_cutile_kernel_perf_opt_playbook, improve_cutile_kernel_perf_perf_knobs, improve_cutile_kernel_perf_api_ref, improve_cutile_kernel_perf_perf_model, improve_cutile_kernel_perf_ir_guide, improve_cutile_kernel_perf_patterns [INFERRED 0.90]
- **TileGym Kernel Integration Workflow** — skills_tilegym_monkey_patch_kernels_to_transformers_references_kernel_integration, skills_tilegym_monkey_patch_kernels_to_transformers_references_workflow_diagram, skills_tilegym_monkey_patch_kernels_to_transformers_references_kernel_inventory_schema [EXTRACTED 1.00]
- **Sentence Transformers Training Framework** — skills_train_sentence_transformers_references_training_args, skills_train_sentence_transformers_references_dataset_formats, skills_train_sentence_transformers_references_base_model_selection [INFERRED 0.90]
- **Transformers.js Configuration and Loading Flow** — skills_transformers_js_references_configuration, skills_transformers_js_references_cache, skills_transformers_js_references_pipeline_options, skills_transformers_js_references_model_registry [EXTRACTED 1.00]
- **RT-VLM Deployment and API Stack** — skills_vss_deploy_dense_captioning_skill, skills_vss_deploy_dense_captioning_references_deploy_rt_vlm, skills_vss_deploy_dense_captioning_references_api_surface, skills_vss_deploy_dense_captioning_references_kafka_workflows [EXTRACTED 1.00]
- **RTVI-CV Deployment Workflow** — skills_vss_deploy_detection_tracking_2d_deploy_vss_detection_tracking_2d, skills_vss_deploy_detection_tracking_2d_container_reuse, skills_vss_deploy_detection_tracking_2d_apply_config, skills_vss_deploy_detection_tracking_2d_next_steps [EXTRACTED 1.00]
- **Configuration Management Scripts** — skills_vss_deploy_detection_tracking_2d_apply_config_sh, skills_vss_deploy_detection_tracking_2d_update_batch_size_sh, skills_vss_deploy_detection_tracking_2d_update_output_sink_sh, skills_vss_deploy_detection_tracking_2d_update_stream_sources_sh [EXTRACTED 1.00]
- **TRT Engine Setup and Caching** — skills_vss_deploy_detection_tracking_2d_setup_gdino_sh, skills_vss_deploy_detection_tracking_2d_setup_sparse4d_sh, skills_vss_deploy_detection_tracking_2d_prelaunch_nvinfer_engine_sh, skills_vss_deploy_detection_tracking_2d_cache_nvinfer_engine_sh [EXTRACTED 1.00]
- **VSS 2D Deployment Flow** — skills_vss_deploy_detection_tracking_2d_task_list, skills_vss_deploy_detection_tracking_2d_resource_plan, skills_vss_deploy_detection_tracking_2d_pipeline_config, skills_vss_deploy_detection_tracking_2d_platforms, skills_vss_deploy_detection_tracking_2d_start_app [EXTRACTED 1.00]
- **VSS Core Skill Suite** — skills_vss_generate_video_calibration, skills_vss_generate_video_report, skills_vss_manage_alerts, skills_vss_manage_video_io_storage, skills_vss_query_analytics, skills_vss_search_archive, skills_vss_setup_behavior_analytics, skills_vss_setup_video_analytics_api, skills_vss_summarize_video [EXTRACTED 1.00]
- **Video Summarization Data Pipeline** — rt_vlm_service, kafka_broker, logstash_service, vss_video_summarization_service [EXTRACTED 1.00]
- **LVS Database Backends** — elasticsearch_db, neo4j_graph_db, arangodb_graph_db [EXTRACTED 1.00]
- **Sage Platform Redesign Effort** — docs_infra_problems, docs_local_cache, docs_pywaggle2 [EXTRACTED 1.00]
- **Hermes Profile Configuration** — distribution, config, soul, agents [INFERRED 0.90]
- **AI-Q Deployment Workflow** — skills_aiq_deploy_references_locate_or_clone, skills_aiq_deploy_references_env_and_secrets, skills_aiq_deploy_references_validation, skills_aiq_deploy_references_troubleshooting [EXTRACTED 1.00]
- **cuOpt Development Lifecycle** — skills_cuopt_developer_first_time_setup, skills_cuopt_developer_build_and_test, skills_cuopt_developer_contributing, skills_cuopt_developer_conventions [INFERRED 0.90]
- **Numerical Optimization Toolset** — skills_cuopt_numerical_optimization_formulation, skills_cuopt_numerical_optimization_api, skills_cuopt_multi_objective_exploration [INFERRED 0.90]
- **cuPyNumeric Migration Assessment Flow** — skills_cupynumeric_migration_readiness_decision_framework, skills_cupynumeric_migration_readiness_idioms_block [EXTRACTED 1.00]
- **cuPyNumeric Migration Guide** — skills_cupynumeric_migration_readiness_references_idioms_that_block, skills_cupynumeric_migration_readiness_references_idioms_that_scale, skills_cupynumeric_migration_readiness_references_partitioning_and_balance, skills_cupynumeric_migration_readiness_references_refactor_recipes [INFERRED 0.90]
- **DeepStream Development Guide** — skills_deepstream_dev_skill, skills_deepstream_dev_references_best_practices, skills_deepstream_dev_references_buffer_apis [INFERRED 0.90]
- **Buffer Injection Flow** — skills_deepstream_dev_references_buffer_apis_bufferprovider, skills_deepstream_dev_references_buffer_apis_feeder, skills_deepstream_dev_references_gstreamer_plugins_nvstreammux [INFERRED 0.90]
- **Frame Extraction Flow** — skills_deepstream_dev_references_buffer_apis_bufferretriever, skills_deepstream_dev_references_buffer_apis_receiver [INFERRED 0.90]
- **Messaging Pipeline Flow** — skills_deepstream_dev_references_gstreamer_plugins_nvmsgconv, skills_deepstream_dev_references_gstreamer_plugins_nvmsgbroker, skills_deepstream_dev_references_nvds_msgapi_adapter_nvds_msgapi [EXTRACTED 1.00]
- **Custom Message Broker Adapter API** — skills_deepstream_dev_references_nvds_msgapi_adapter_nvds_msgapi_connect, skills_deepstream_dev_references_nvds_msgapi_adapter_nvds_msgapi_send, skills_deepstream_dev_references_nvds_msgapi_adapter_nvds_msgapi_send_async, skills_deepstream_dev_references_nvds_msgapi_adapter_nvds_msgapi_do_work, skills_deepstream_dev_references_nvds_msgapi_adapter_nvds_msgapi_disconnect [EXTRACTED 1.00]
- **Dynamic Source Management Flow** — skills_deepstream_dev_references_rest_api_dynamic_nvmultiurisrcbin, skills_deepstream_dev_references_rest_api_dynamic_nvurisrcbin, skills_deepstream_dev_references_rest_api_dynamic_nvstreammux, skills_deepstream_dev_references_service_maker_api_sourcemanager [INFERRED 0.90]
- **Pipeline Generation Workflow** — skills_deepstream_generate_pipeline_references_requirement_extraction, skills_deepstream_generate_pipeline_references_assembly_rules, skills_deepstream_generate_pipeline_references_output_format [EXTRACTED 1.00]
- **Vision Model Import Workflow** — skills_deepstream_import_vision_model_references_model_acquire, skills_deepstream_import_vision_model_references_engine_build [EXTRACTED 1.00]
- **DeepStream Profiling Measurement Flow** — skills_deepstream_profile_pipeline_references_nvtx_coverage, skills_deepstream_profile_pipeline_references_hw_ceiling_formulas, skills_deepstream_profile_pipeline_references_config_derivation_rules, skills_deepstream_profile_pipeline_references_nsys_cli_recipes, skills_deepstream_profile_pipeline_references_boundedness_rules [EXTRACTED 1.00]
- **DeepStream SOP Evaluation Suite** — skills_deepstream_sop_references_skill_12_evaluation_workflow, skills_deepstream_sop_references_skill_13_verification_curl, skills_deepstream_sop_references_skill_15_latency_measurement, skills_deepstream_sop_references_skill_17_camera_latency_measurement [EXTRACTED 1.00]
- **MedTech DICOM Processing Skills** — skills_dicom_metadata_extract_skill_manifest, skills_dicom_series_preflight_skill_manifest, skills_dicom_series_to_volume_skill_manifest [INFERRED 0.90]
- **Dynamo Deployment Flow** — skills_dynamo_recipe_runner, skills_dynamo_interconnect_check, skills_dynamo_router_starter [INFERRED 0.90]
- **Earth2Studio Component Creation** — skills_earth2studio_create_datasource_skill, skills_earth2studio_create_diagnostic_skill, skills_earth2studio_create_prognostic_skill [INFERRED 0.90]
- **Earth2Studio Skill Evaluation** — skills_earth2studio_create_datasource_benchmark, skills_earth2studio_create_diagnostic_benchmark, skills_earth2studio_create_prognostic_benchmark, skills_earth2studio_data_fetch_benchmark, skills_earth2studio_discover_benchmark, skills_earth2studio_install_benchmark [EXTRACTED 1.00]
- **SageMaker Deployment Workflow** — skills_hf_cloud_sagemaker_deployment_planner_skill, skills_hf_cloud_aws_context_discovery_skill, skills_hf_cloud_python_env_setup_skill, skills_hf_cloud_sagemaker_iam_preflight_skill, skills_hf_cloud_serving_image_selection_skill, skills_hf_cloud_sagemaker_production_defaults_skill [EXTRACTED 1.00]
- **Holoscan SDK Installation Suite** — skills_holoscan_setup, skills_holoscan_install_container, skills_holoscan_install_debian, skills_holoscan_install_wheel, skills_holoscan_install_source, skills_holoscan_install_conda [EXTRACTED 1.00]
- **Holoscan Sensor Bridge Management** — skills_hsb_app, skills_hsb_flash [INFERRED 0.90]
- **HSB Lifecycle Toolchain** — skills_hsb_setup, skills_hsb_flash, skills_hsb_test [INFERRED 0.90]
- **TRL Training Lifecycle** — skills_huggingface_llm_trainer_skill, skills_huggingface_llm_trainer_references_training_methods, skills_huggingface_llm_trainer_references_hub_saving, skills_huggingface_llm_trainer_references_gguf_conversion [INFERRED 0.90]
- **HSB Test Execution Flow** — skills_hsb_test_references_phase_details [EXTRACTED 1.00]
- **LoRA Space Builder Workflow** — skills_huggingface_lora_space_builder_skill, skills_huggingface_lora_space_builder_references_tasks, skills_huggingface_lora_space_builder_references_adapting_to_the_lora, skills_huggingface_lora_space_builder_references_zerogpu_and_publishing [EXTRACTED 1.00]
- **Paper Publishing Pipeline** — skills_huggingface_paper_publisher_skill, skills_huggingface_paper_publisher_templates_standard, skills_huggingface_paper_publisher_templates_modern, skills_huggingface_paper_publisher_templates_arxiv, skills_huggingface_paper_publisher_templates_ml_report [EXTRACTED 1.00]
- **HF Spaces Management Flow** — skills_huggingface_spaces, skills_huggingface_spaces_zerogpu, skills_huggingface_spaces_debugging, skills_huggingface_spaces_requirements [EXTRACTED 1.00]
- **Trackio Experimentation Loop** — skills_huggingface_trackio_logging, skills_huggingface_trackio_alerts, skills_huggingface_trackio_retrieval [EXTRACTED 1.00]
- **Vision Training Pipeline** — skills_huggingface_vision_trainer, skills_huggingface_vision_trainer_hub_saving, skills_huggingface_trackio [INFERRED 0.90]
- **ZeroGPU Internal Mechanism Documentation** — skills_huggingface_zerogpu_references_concurrency, skills_huggingface_zerogpu_references_cuda_and_deps, skills_huggingface_zerogpu_references_how_quota_works, skills_huggingface_zerogpu_references_how_zerogpu_works [EXTRACTED 1.00]
- **Jetson BSP Build Reference Set** — skills_jetson_build_source_references_build_modes, skills_jetson_build_source_references_composite_registration, skills_jetson_build_source_references_long_tail_gotchas, skills_jetson_build_source_references_manifest_schema, skills_jetson_build_source_references_upstream_recipe [EXTRACTED 1.00]
- **BSP I/O Customization Flow** — skills_jetson_customize_uphy_skill, skills_jetson_customize_pcie_skill, skills_jetson_customize_mgbe_skill, skills_jetson_customize_pinmux_skill [EXTRACTED 1.00]
- **Deployment Chain** — skills_jetson_build_source_skill, skills_jetson_promote_image_skill, skills_jetson_flash_image_skill, skills_jetson_validate_image_skill [EXTRACTED 1.00]
- **BSP Overlay Deployment Flow** — skills_jetson_promote_image, skills_jetson_flash_image [EXTRACTED 1.00]
- **BSP Setup Flow** — skills_jetson_download_bsp, skills_jetson_init_image, skills_jetson_init_source, skills_jetson_link_docs [EXTRACTED 1.00]
- **BSP Setup Workflow** — skills_jetson_init_target, skills_jetson_init_image, skills_jetson_init_source, skills_jetson_link_docs, skills_jetson_generate_kb [EXTRACTED 1.00]
- **LLM Deployment and Tuning Flow** — skills_jetson_llm_serve, skills_jetson_llm_benchmark, skills_jetson_inference_mem_tune [EXTRACTED 1.00]
- **BSP Deployment Pipeline** — skills_jetson_promote_image, skills_jetson_validate_image [EXTRACTED 1.00]
- **Memory Management Flow** — skills_jetson_memory_audit, skills_jetson_optimize_memory [INFERRED 0.80]
- **NeMo AutoModel Skill Suite** — skills_nemo_automodel_distributed_training_skill, skills_nemo_automodel_launcher_config_skill, skills_nemo_automodel_model_onboarding_skill [INFERRED 0.90]
- **Megatron-Core Developer Suite** — skills_mcore_create_issue_skill, skills_mcore_linting_and_formatting_skill, skills_mcore_run_on_slurm_skill, skills_mcore_split_pr_skill, skills_mcore_testing_skill [INFERRED 0.90]
- **MoE Core Components** — nemo_automodel_components_moe_config_moeconfig, nemo_automodel_components_moe_fsdp_mixin_moefsdpsyncmixin, nemo_automodel_components_moe_layers_moe, nemo_automodel_components_moe_experts_groupedexperts [EXTRACTED 1.00]
- **MoE Performance Tuning Stack** — skills_nemo_mbridge_perf_moe_dispatcher_selection_dispatcher_types, skills_nemo_mbridge_perf_expert_parallel_overlap_overlap_moe_expert_parallel_comm, skills_nemo_mbridge_perf_cuda_graphs_cuda_graph_impl [INFERRED 0.90]
- **Memory Reduction Strategies** — skills_nemo_mbridge_perf_memory_tuning_expandable_segments, skills_nemo_mbridge_perf_cpu_offloading_cpu_offloading, skills_nemo_mbridge_perf_megatron_fsdp_use_megatron_fsdp [INFERRED 0.85]
- **MoE Performance Tuning Suite** — skills_nemo_mbridge_perf_moe_long_context, skills_nemo_mbridge_perf_moe_optimization_workflow, skills_nemo_mbridge_perf_moe_vlm_training [INFERRED 0.90]
- **Parallelism and Communication Optimization** — skills_nemo_mbridge_perf_parallelism_strategies, skills_nemo_mbridge_perf_tp_dp_comm_overlap, skills_nemo_mbridge_perf_sequence_packing [INFERRED 0.80]
- **Nemotron Customization Reference Set** — skills_nemotron_customize_references_catalog, skills_nemotron_customize_references_artifacts, skills_nemotron_customize_references_commands, skills_nemotron_customize_references_hardware, skills_nemotron_customize_references_patterns [EXTRACTED 1.00]
- **NeMo-RL Agent Support Skills** — skills_nemo_rl_auto_research_skill, skills_nemo_rl_session_memory_skill, skills_nemo_rl_brev_etiquette_skill [INFERRED 0.90]
- **Megatron-Bridge Training Flow** — skills_nemotron_customize_references_context_mbridge_pretrain, skills_nemotron_customize_references_context_mbridge_sft, skills_nemotron_customize_references_context_mbridge_parallelism_performance, skills_nemotron_customize_references_context_nemotron_data_prep [EXTRACTED 1.00]
- **Nemotron Content Safety Framework** — nemotron_policy_generator, ncs_reasoning_4b, ncs_3_content_safety [EXTRACTED 1.00]
- **Riva ASR Deployment Workflow** — skills_nemotron_speech_references_asr, skills_nemotron_speech_references_asr_custom, skills_nemotron_speech_references_pipelines [EXTRACTED 1.00]
- **Riva System Readiness Flow** — skills_nemotron_speech_references_setup, skills_nemotron_speech_references_deployment_readiness_checks [INFERRED 0.90]
- **CAD to SimReady Pipeline** — skills_omniverse_cad_to_simready_preflight, skills_omniverse_cad_to_simready_identify_asset_context, skills_omniverse_cad_to_simready_convert_to_usd, skills_omniverse_cad_to_simready_content_agents, skills_omniverse_cad_to_simready_simready_conform_profile, skills_omniverse_cad_to_simready_omni_asset_validate, skills_omniverse_cad_to_simready_simready_validate, skills_omniverse_cad_to_simready_ovrtx_render_service, skills_omniverse_cad_to_simready_assemble_package_source, skills_omniverse_cad_to_simready_nv_core_package_sample [EXTRACTED 1.00]
- **Content Agents Service Suite** — skills_omniverse_cad_to_simready_material_agent_client, skills_omniverse_cad_to_simready_physics_agent_client, skills_omniverse_cad_to_simready_texture_agent_client, skills_omniverse_cad_to_simready_deploy_content_agents [EXTRACTED 1.00]
- **USD Conversion Suite** — skills_omniverse_cad_to_simready_urdf_usd_converter, skills_omniverse_cad_to_simready_mujoco_usd_converter, skills_omniverse_cad_to_simready_usd_convert_cad, skills_omniverse_cad_to_simready_usd_convert_gsplat [EXTRACTED 1.00]
- **CAD to SimReady Validation Pipeline** — skills_omniverse_cad_to_simready_references_validate_usd_minimum, skills_omniverse_cad_to_simready_references_omni_asset_validate_geometry, skills_omniverse_cad_to_simready_references_omni_asset_validate_physics, skills_omniverse_cad_to_simready_references_simready_validate [EXTRACTED 1.00]
- **OVRTX Camera Management** — skills_omniverse_realtime_viewer_references_camera_auto_select, skills_omniverse_realtime_viewer_references_camera_controls, skills_omniverse_realtime_viewer_references_camera_picker [INFERRED 0.90]
- **C++ Native Render Loop Flow** — skills_omniverse_realtime_viewer_references_cpp_native_viewer_interaction_features_write_mat4_attribute, skills_omniverse_realtime_viewer_references_cpp_native_viewer_interaction_features_update_selection_animation, skills_omniverse_realtime_viewer_references_cpp_native_viewer_interaction_features_enqueue_pick, skills_omniverse_realtime_viewer_references_cpp_native_viewer_presentation_loop_step_render_and_upload [EXTRACTED 1.00]
- **Electron SHM Process Boundary** — electron_shm_viewer_python_server, electron_shm_viewer_native_shm_client, electron_shm_viewer_viewer_backend [EXTRACTED 1.00]
- **ovrtx Render Pipeline** — ovrtx_render_product_set_outputs, ovrtx_operation [EXTRACTED 1.00]
- **ovui Interaction System** — ovui_transform_gizmo, ovui_pointer_event, ovui_camera_state, ovui_viewport [EXTRACTED 1.00]
- **ovwidgets Adapter Pattern** — ovwidgets_renderer_adapter, ovrtx_ovrtx_renderer_adapter, ovwidgets_viewport_widget [EXTRACTED 1.00]
- **Streaming Architecture Core** — skills_omniverse_realtime_viewer_references_streaming_server, skills_omniverse_realtime_viewer_references_streaming_client, skills_omniverse_realtime_viewer_references_streaming_messages [EXTRACTED 1.00]
- **Tauri Local Viewer Stack** — skills_omniverse_realtime_viewer_references_tauri_local_viewer, skills_omniverse_realtime_viewer_references_tauri_shm_transform_gizmo, skills_omniverse_realtime_viewer_references_streaming_vs_local [INFERRED 0.90]
- **Viewer UI/UX Framework** — skills_omniverse_realtime_viewer_references_viewer_layout_patterns, skills_omniverse_realtime_viewer_references_viewer_control_patterns, skills_omniverse_realtime_viewer_references_viewer_data_view_patterns, skills_omniverse_realtime_viewer_references_viewer_feedback_status, skills_omniverse_realtime_viewer_references_viewer_ux_workflow [EXTRACTED 1.00]
- **USD Performance Optimization Workflow** — skills_omniverse_usd_performance_tuning, skills_omniverse_usd_performance_tuning_references_compare_profiles, skills_omniverse_usd_performance_tuning_references_output_workspace, skills_omniverse_usd_performance_tuning_references_runtime_artifact_token_budget [EXTRACTED 1.00]
- **Canonical 7-Phase Flow** — setup_usd_performance_tuning, profile_stage, usd_structure_assessment, usd_validation_runner, restructure_decision, apply_restructure, so_run_operations, compare_profiles, optimization_report [EXTRACTED 1.00]
- **Runtime Setup and Verification Flow** — skills_omniverse_usd_performance_tuning_references_setup_usd_performance_tuning_references_runtime_context_header, skills_omniverse_usd_performance_tuning_references_setup_usd_performance_tuning_references_runtime_probe, install_kit, install_so_standalone, install_so_via_kit, install_asset_validator_standalone [EXTRACTED 1.00]
- **Scene Optimizer Execution Pipeline** — skills_omniverse_usd_performance_tuning_references_so_run_operations_references_config_from_evidence, skills_omniverse_usd_performance_tuning_references_so_run_operations_references_operation_safety, skills_omniverse_usd_performance_tuning_references_so_run_operations_references_invocation, skills_omniverse_usd_performance_tuning_references_so_run_operations_references_batch_mode [EXTRACTED 1.00]
- **USD Structural Analysis Suite** — usd_structure_assessment, skills_omniverse_usd_performance_tuning_references_usd_structure_assessment_references_composition_audit, skills_omniverse_usd_performance_tuning_references_usd_structure_assessment_references_asset_structure_principles [EXTRACTED 1.00]
- **USD Restructuring Flow** — usd_hierarchy_dedupe_candidates, restructure_decision, apply_restructure [EXTRACTED 1.00]
- **Instancing and Deduplication Strategy** — instancing_readiness, skills_omniverse_usd_performance_tuning_references_usd_structure_assessment_references_instancing_readiness_references_instancing_guide, skills_omniverse_usd_performance_tuning_references_usd_structure_assessment_references_instancing_readiness_references_instancing_tradeoffs [EXTRACTED 1.00]
- **Edit Target Planning and Output Policy** — usd_edit_target_planner, skills_omniverse_usd_performance_tuning_references_usd_structure_assessment_references_usd_edit_target_planner_references_output_saving, skills_omniverse_usd_performance_tuning_references_usd_structure_assessment_references_usd_edit_target_planner_references_variants_payloads [EXTRACTED 1.00]
- **USD Validation Pipeline** — skills_omniverse_usd_performance_tuning_references_usd_validation_runner_readme, skills_omniverse_usd_performance_tuning_references_usd_validation_runner_references_validate_usd_asset_validator, skills_omniverse_usd_performance_tuning_references_usd_validation_runner_references_so_run_validators_readme, skills_omniverse_usd_performance_tuning_references_usd_validation_runner_references_so_interpret_validators_readme, skills_omniverse_usd_performance_tuning_references_usd_validation_runner_scripts_usd_validation_executor [EXTRACTED 1.00]
- **Defect Image Generation Workflows** — assets_configs_finetune, assets_configs_good_image_generation, assets_configs_structural_defect_generation, assets_configs_texture_defect_generation_day0, assets_configs_texture_defect_generation_day1_manual_roi [EXTRACTED 1.00]
- **Asset Setup Suite** — assets_configs_setup_setup_glass, assets_configs_setup_setup_metal, assets_configs_setup_setup_pcb, assets_configs_setup_setup_pretrained [EXTRACTED 1.00]
- **USD to ROI Pipeline** — scripts_usd2roi_render, scripts_usd2roi_register, scripts_usd2roi_crop [EXTRACTED 1.00]
- **PCBA Defect Image Generation Workflows** — skills_physical_ai_defect_image_generation_good_image_generation, skills_physical_ai_defect_image_generation_structural_defect_generation, skills_physical_ai_defect_image_generation_texture_defect_generation_day0 [EXTRACTED 1.00]
- **Azure Infrastructure Stack** — skills_physical_ai_infrastructure_setup_and_resilient_scaling_cluster_azure, skills_physical_ai_infrastructure_setup_and_resilient_scaling_osmo_azure, skills_physical_ai_infrastructure_setup_and_resilient_scaling_inference_azure [EXTRACTED 1.00]
- **NuRec Sibling Skills** — nurec_sibling_ncore, nurec_sibling_nre, nurec_sibling_datasets, nurec_sibling_harvester, nurec_sibling_fixer [EXTRACTED 1.00]
- **OSMO Workflow Management Commands** — osmo_workflow_submit, osmo_workflow_query, osmo_workflow_logs, osmo_data_download [EXTRACTED 1.00]
- **End-to-End Video Data Augmentation Flow** — assets_configs_osmo_e2e_setup, assets_configs_osmo_e2e_pl_original_worker_0, assets_configs_osmo_e2e_cosmos_worker_0, assets_configs_osmo_e2e_pl_augmented_worker_0 [EXTRACTED 1.00]
- **VDA Scene Cookbooks** — assets_cookbooks_city_traffic, assets_cookbooks_piazza, assets_cookbooks_robot_assembly, assets_cookbooks_trailer_dashcam, assets_cookbooks_warehouse [INFERRED 0.90]
- **RAG Deployment Modes** — skills_rag_blueprint_references_deploy_docker_self_hosted, skills_rag_blueprint_references_deploy_docker_nvidia_hosted, skills_rag_blueprint_references_deploy_helm_standard, skills_rag_blueprint_references_deploy_library_full, skills_rag_blueprint_references_deploy_library_lite [EXTRACTED 1.00]
- **RAG Evaluation Workflow** — skills_rag_eval_references_dataset_conversion, skills_rag_eval_references_benchmark_execution, skills_rag_eval_references_result_analysis [EXTRACTED 1.00]
- **Sage Edge Computing Stack** — pywaggle, beehive, beekeeper [EXTRACTED 1.00]
- **Sage Plugin Deployment Toolchain** — skills_sage_waggle_references_deployment_and_diagnostics, skills_sage_waggle_references_direct_node_testing, skills_sage_waggle_references_docker_build_deploy [INFERRED 0.90]
- **ECR Deployment Pipeline** — skills_sage_waggle_references_ecr_build_to_ses_cutover, skills_sage_waggle_references_ecr_builder_proc_acpi_runc_bug, skills_sage_waggle_references_ecr_catalog_api_and_thor_deploy, skills_sage_waggle_references_ecr_public_apps_api [EXTRACTED 0.90]
- **Image Provenance and Linking** — skills_sage_waggle_references_image_metadata_naming_and_eventlog_linking, skills_sage_waggle_references_image_upload_provenance_and_linking, skills_sage_waggle_references_linking_images_to_event_log_and_uniqueness [EXTRACTED 0.90]
- **SES Job Operations** — skills_sage_waggle_references_job_scheduling_and_debugging, skills_sage_waggle_references_job_scheduling_and_liveness, skills_sage_waggle_references_jobspec_verification_discipline, skills_sage_waggle_references_node_access_and_job_ownership [EXTRACTED 0.90]
- **Node Identity Resolution Flow** — node_manifest_v2_json, wes_gps_server, beehive [EXTRACTED 0.90]
- **Plugin Deployment Tooling** — pluginctl, sesctl, skills_sage_waggle_references_on_node_verification_recipe [EXTRACTED 0.90]
- **Publish-vs-Save Decoupling Pattern** — skills_sage_waggle_references_publish_vs_save_and_portal_media_rendering, skills_sage_waggle_references_publish_vs_save_and_save_match_design, skills_sage_waggle_references_publish_vs_save_decoupling_pattern, skills_sage_waggle_references_publish_vs_save_decoupling_save_match, skills_sage_waggle_references_publish_vs_save_decoupling [EXTRACTED 1.00]
- **pywaggle2 Ecosystem** — skills_sage_waggle_references_pywaggle2_nodeinfo_gps_design, skills_sage_waggle_references_pywaggle2_producer_consumer_architecture [EXTRACTED 1.00]
- **Node Deployment Tooling** — pluginctl, sesctl, ecr [INFERRED 0.90]
- **v2 Read Contract Skeleton** — skills_sage_waggle_references_pywaggle2_producer_consumer_architecture_consumer, skills_sage_waggle_references_pywaggle2_producer_consumer_architecture_selection, skills_sage_waggle_references_pywaggle2_producer_consumer_architecture_seenstore, skills_sage_waggle_references_pywaggle2_producer_consumer_architecture_node_info, skills_sage_waggle_references_pywaggle2_producer_consumer_architecture_save_match [EXTRACTED 1.00]
- **GPU Scheduling Strategies** — scheduling_continuous_vs_oneshot_yolo, scheduling_continuous_vs_oneshot_bioclip, skills_sage_waggle_references_scheduling_and_cameras_ses [INFERRED 0.90]
- **Thor GPU Deployment Workaround** — skills_sage_waggle_references_thor_arm64_deploy_pipeline, skills_sage_waggle_references_wes_node_service_daemonset_sideload, pluginctl [EXTRACTED 0.90]
- **WES Node Infrastructure** — waggle_edge_stack, edge_scheduler, wes_upload_agent, wes_local_cache_manager [INFERRED 0.90]
- **Visual ChangeNet RCA Workflow** — skills_tao_analyze_changenet_rca_investigation_phases, skills_tao_analyze_changenet_rca_output_structure, skills_tao_analyze_changenet_rca_parallelization [EXTRACTED 1.00]
- **VCN Gap Analysis Process** — skills_tao_analyze_gaps_visual_changenet_container_setup, skills_tao_analyze_gaps_visual_changenet_output_template, skills_tao_analyze_gaps_visual_changenet_visual_spot_check [EXTRACTED 1.00]
- **Cosmos-RL Action Suite** — skills_tao_finetune_cosmos_reason_cosmos_rl_train, skills_tao_finetune_cosmos_reason_cosmos_rl_evaluate, skills_tao_finetune_cosmos_reason_cosmos_rl_inference, skills_tao_finetune_cosmos_reason_cosmos_rl_quantize [EXTRACTED 1.00]
- **CV Evaluation and Inference Flow** — skills_tao_finetune_huggingface_model_references_cv_scripts_run_eval, skills_tao_finetune_huggingface_model_references_cv_scripts_inference, skills_tao_finetune_huggingface_model_references_reporting_report [EXTRACTED 0.90]
- **Pre-training Validation Suite** — skills_tao_finetune_huggingface_model_references_testing_test_dataset, skills_tao_finetune_huggingface_model_references_testing_test_collator, skills_tao_finetune_huggingface_model_references_testing_test_model, skills_tao_finetune_huggingface_model_references_testing_test_smoke [EXTRACTED 1.00]
- **HuggingFace Fine-Tuning Workflow** — skills_tao_finetune_huggingface_model_references_workflow_intake_preflight, skills_tao_finetune_huggingface_model_references_workflow_generate_train, skills_tao_finetune_huggingface_model_references_workflow_push_rerun [EXTRACTED 1.00]
- **VLM Training Script Set** — skills_tao_finetune_huggingface_model_references_vlm_scripts_model_py, skills_tao_finetune_huggingface_model_references_vlm_scripts_dataset_py, skills_tao_finetune_huggingface_model_references_vlm_scripts_train_py, skills_tao_finetune_huggingface_model_references_vlm_scripts_merge_lora_py, skills_tao_finetune_huggingface_model_references_vlm_scripts_run_eval_py, skills_tao_finetune_huggingface_model_references_vlm_scripts_inference_py [EXTRACTED 1.00]
- **TAO Toolkit Core Repositories** — tao_core, tao_pytorch, tao_deploy [EXTRACTED 1.00]
- **AutoML Workflow Documentation** — tao_run_automl, skills_tao_run_automl_references_automl_intent_algorithms, skills_tao_run_automl_references_automl_advanced_monitoring, skills_tao_run_automl_references_automl_examples [EXTRACTED 1.00]
- **AOI Three-Phase Training Pipeline** — skills_tao_run_automl, skills_tao_run_deft_aoi, skills_tao_run_automl_deft_pipeline [EXTRACTED 1.00]
- **DEFT Loop Execution Stages** — skills_tao_analyze_gaps_visual_changenet, skills_tao_route_visual_changenet_samples, skills_paidf_anomalygen, skills_tao_mine_aoi_images, skills_tao_train_visual_changenet [EXTRACTED 1.00]
- **DEFT Loop Pipeline Stages** — skills_tao_run_deft_aoi_references_tao_analyze_gaps_visual_changenet, skills_tao_run_deft_aoi_references_tao_route_visual_changenet_samples, skills_tao_run_deft_aoi_references_tao_mine_aoi_images, skills_tao_run_deft_aoi_references_visual_changenet [EXTRACTED 1.00]
- **SLURM Execution Stack** — skills_tao_run_platform_slurm_sdk, slurm_pyxis_enroot, slurm_lustre [EXTRACTED 1.00]
- **TAO SDK Core API** — tao_sdk_build_entrypoint, tao_sdk_action_workflow, skills_tao_run_platform_sdk [EXTRACTED 1.00]
- **DINO Knowledge Base** — skills_tao_train_dino_skill_md, skills_tao_train_dino_references_dino_actions_errors_md, skills_tao_train_dino_references_dino_automl_sdk_md, skills_tao_train_dino_references_dino_data_specs_md, skills_tao_train_dino_references_dino_tuning_multigpu_md, skills_tao_train_dino_references_tao_deploy_dino_md [EXTRACTED 1.00]
- **FastFoundationStereo Knowledge Base** — skills_tao_train_fast_foundation_stereo_skill_md, skills_tao_train_fast_foundation_stereo_references_error_patterns_md, skills_tao_train_fast_foundation_stereo_references_important_parameters_md, skills_tao_train_fast_foundation_stereo_references_parent_model_inference_md, skills_tao_train_fast_foundation_stereo_references_setup_and_run_md, skills_tao_train_fast_foundation_stereo_references_tao_deploy_fast_foundation_stereo_md [EXTRACTED 1.00]
- **FoundationStereo Lifecycle** — skills_tao_train_foundation_stereo_depth_net [EXTRACTED 1.00]
- **Grounding DINO Lifecycle** — skills_tao_train_grounding_dino_grounding_dino, skills_tao_train_grounding_dino_deploy [EXTRACTED 1.00]
- **TAO Segmentation Skills** — skills_tao_train_mask_grounding_dino, skills_tao_train_mask2former [EXTRACTED 1.00]
- **OCRNet End-to-End Pipeline** — ocrnet_dataset_convert, ocrnet_train, ocrnet_export, ocrnet_gen_trt_engine [EXTRACTED 1.00]
- **OneFormer End-to-End Pipeline** — oneformer_train, oneformer_export, oneformer_gen_trt_engine [EXTRACTED 1.00]
- **MV3DT Deployment Pipeline** — skills_vss_deploy_detection_tracking_3d_references_calibration_workflow, skills_vss_deploy_detection_tracking_3d_references_configure_cameras, skills_vss_deploy_detection_tracking_3d_references_deploy_rtvi_cv_3d_stack, skills_vss_deploy_detection_tracking_3d_references_verify_and_view [EXTRACTED 1.00]
- **MV3DT Core Services** — vss_rtvi_cv_mv3dt, vss_rtvi_cv_bev_fusion, vss_behavior_analytics_mv3dt [INFERRED 0.90]
- **VSS Base Deployment Stack** — vss_agent, vss_agent_ui, vss_haproxy_ingress, vss_vios_ingress [EXTRACTED 1.00]
- **VSS Search Pipeline** — vss_rtvi_cv, vss_rtvi_embed, vss_agent [INFERRED 0.90]
- **Video Embedding Documentation Set** — skills_vss_deploy_video_embedding_references_deploy, skills_vss_deploy_video_embedding_references_integrate, skills_vss_deploy_video_embedding_references_rest_api, skills_vss_deploy_video_embedding_references_environment, skills_vss_deploy_video_embedding_references_troubleshooting [EXTRACTED 1.00]
- **AutoMagicCalib Workflow** — skills_vss_generate_video_calibration_references_common_steps, skills_vss_generate_video_calibration_references_rtsp, skills_vss_generate_video_calibration_references_calibration_tail [EXTRACTED 1.00]
- **VSS Alert Management Workflows** — skills_vss_manage_alerts_workflow_a, skills_vss_manage_alerts_workflow_b, skills_vss_manage_alerts_workflow_c, skills_vss_manage_alerts_workflow_d, skills_vss_manage_alerts_workflow_e [EXTRACTED 1.00]
- **VSS Report Generation Modes** — skills_vss_generate_video_report_mode_a, skills_vss_generate_video_report_mode_b [EXTRACTED 1.00]
- **VIOS Core Microservices** — vss_vios_sensor, vss_vios_streamprocessing, vss_vios_ingress, vss_vios_postgres [EXTRACTED 1.00]
- **SDRC Routing Path** — vss_vios_sensor, sdr_controller, vss_vios_streamprocessing [EXTRACTED 1.00]
- **Search Ingestion Pipeline** — vss_agent_backend, vss_vios_sensor, elasticsearch [INFERRED 0.90]
- **Dynamic Configuration Flow** — vss_video_analytics_api, mdx_notification, vss_behavior_analytics [EXTRACTED 1.00]
- **Video Summarization Pipeline** — vss_lvs, vss_rtvi_vlm, vss_manage_video_io_storage [EXTRACTED 1.00]

## Communities (1342 total, 505 thin omitted)

### Community 0 - "Evaluate"
Cohesion: 0.08
Nodes (143): Evaluate, dataset.augmentation.color_jitter, dataset.augmentation_config.of_input_mean, dataset.augmentation_config.of_input_std, dataset.augmentation_config.random_rotate, dataset.augmentation_config.scales, dataset.augmentation.gaussian_radius_list, dataset.color_augmentation (+135 more)

### Community 1 - "train.optim.lr"
Cohesion: 0.10
Nodes (120): dataset.augmentation.distortion_prob, dataset.augmentation.iou_crop_prob, dataset.augmentation.random_color.color_probability, dataset.augmentation.random_erase.erase_probability, dataset.augmentation.random_flip.hflip_probability, dataset.augmentation.random_rotate.rotate_probability, dataset.classify.augmentation_config.augment, dataset.classify.augmentation_config.with_scale_random_crop.enable (+112 more)

### Community 2 - "properties"
Cohesion: 0.03
Nodes (89): CT_BODY, model_pt_present, MRI_BODY, MRI_BRAIN, minimum, type, type, type (+81 more)

### Community 3 - "properties"
Cohesion: 0.02
Nodes (108): command_prefix, config_stack, cwd, finetuned_ckpt_exists, multi_gpu, oom, return_code, seconds (+100 more)

### Community 4 - "script_utils.py"
Cohesion: 0.04
Nodes (83): check_dependencies(), main(), Any, Path, _write_report(), check_dependencies(), main(), Any (+75 more)

### Community 5 - "properties"
Cohesion: 0.03
Nodes (62): minimum, type, items, type, maximum, minimum, type, items (+54 more)

### Community 6 - "aiq.py"
Cohesion: 0.05
Nodes (89): _api_request(), _binary_request(), cancel_job(), chat_request(), _checked_job_status(), _command_agents(), _command_artifacts(), _command_cancel() (+81 more)

### Community 7 - "gen_trt_engine"
Cohesion: 0.23
Nodes (87): dataset.augmentation.eval_spatial_size, dataset.augmentation.multi_scales, dataset.augmentation.train_spatial_size, model.feat_channels, model.feat_strides, model.frozen_fm, model.use_encoder_idx, train.ema (+79 more)

### Community 8 - "Asset Validation Checks"
Cohesion: 0.08
Nodes (83): build_manifest(), _check_asset_validator(), _check_content_agents(), _check_content_agents_deployment_host(), _check_git_lfs(), _check_openusd_python(), _check_repo_python(), _check_request_inputs() (+75 more)

### Community 9 - "properties"
Cohesion: 0.03
Nodes (82): conversion_seconds, items, maxItems, minItems, type, items, maxItems, minItems (+74 more)

### Community 10 - "string"
Cohesion: 0.04
Nodes (80): type, type, type, type, properties, type, null, type (+72 more)

### Community 11 - "AutoML Augmentation Params"
Cohesion: 0.19
Nodes (77): automl_default_parameters, automl_disabled_parameters, automl_default_parameters, automl_disabled_parameters, automl_default_parameters, automl_disabled_parameters, dataset, dataset.infer_dataset (+69 more)

### Community 12 - "automl_disabled_parameters"
Cohesion: 0.15
Nodes (75): dataset.augmentation.crop_size, dataset.depth_size, dataset.occ_truncation_lvl, dataset.reduced_target_size, dataset.target_size, dataset.task_prob_train, dataset.task_prob_val, dataset.test.target_size (+67 more)

### Community 13 - "automl_disabled_parameters"
Cohesion: 0.08
Nodes (71): dataset.cam2img, dataset.lidar2cam, dataset.origin, dataset.val_dataset.data_prefix, default_hooks, input_modality, model.bbox_head, model.bbox_head.assigner (+63 more)

### Community 14 - "preflight_manifest.py"
Cohesion: 0.07
Nodes (57): check_dependencies(), _env_first(), _env_or_file_first(), main(), Any, Path, _skill_name(), _write_report() (+49 more)

### Community 15 - "train"
Cohesion: 0.04
Nodes (66): actions, distill, evaluate, export, gen_trt_engine, inference, quantize, train (+58 more)

### Community 16 - "properties"
Cohesion: 0.05
Nodes (40): standalone-package, kit-extension, pip, standalone, source, description, enum, type (+32 more)

### Community 17 - "properties"
Cohesion: 0.05
Nodes (64): boolean, type, type, type, type, type, type, type (+56 more)

### Community 18 - "properties"
Cohesion: 0.04
Nodes (64): before, change_pct, disposition, higher_is_better, id, lower_is_better, method, order (+56 more)

### Community 19 - "properties"
Cohesion: 0.05
Nodes (48): fast, long, minutes, concept, enum, items, type, pattern (+40 more)

### Community 20 - "generate_dtsi.py"
Cohesion: 0.06
Nodes (60): _apply_direction_state(), _apply_electrical(), _apply_one_edit(), apply_pin_edits(), build_pinmap_records(), _build_pinrow(), _collect_gpio_buckets(), _detect_data_sheet() (+52 more)

### Community 21 - "properties"
Cohesion: 0.04
Nodes (50): type, type, type, type, minimum, type, properties, type (+42 more)

### Community 22 - "ovrtx-render-service/scripts/run.py"
Cohesion: 0.09
Nodes (58): _collect_stage_stats(), _decode_png(), _emit(), _endpoint_host(), _endpoint_kind(), _endpoint_requires_token(), _env_first(), _env_first_named() (+50 more)

### Community 23 - "required"
Cohesion: 0.04
Nodes (56): assumptions, available_profiles, date, feature_results, policy_name, profile_name, profile_results, profile_target (+48 more)

### Community 24 - "required"
Cohesion: 0.05
Nodes (60): consistency, environment, input_dir, inventory, limitations, orientation, phi, plan (+52 more)

### Community 25 - "properties"
Cohesion: 0.05
Nodes (42): official_helper, inference_seconds, $comment, type, type, required, type, type (+34 more)

### Community 26 - "required"
Cohesion: 0.10
Nodes (30): anatomy_list_requested, body_region_requested, config_infer_override, config_infer_override_path, num_output_samples_requested, operationsAvailable, required, required (+22 more)

### Community 27 - "automl_disabled_parameters"
Cohesion: 0.16
Nodes (58): dataset.augmentation.bot_pct_lim, dataset.augmentation.final_dim, dataset.augmentation.image_size, dataset.augmentation.resize_lim, dataset.augmentation.rot3d_range, dataset.augmentation.rot_lim, dataset.normalize, dataset.normalize.mean (+50 more)

### Community 28 - "properties"
Cohesion: 0.03
Nodes (63): generated_tokens, hf_space_api, hf_transformers, local_files_only, max_new_tokens, mock, model_revision, torch_dtype (+55 more)

### Community 29 - "properties"
Cohesion: 0.04
Nodes (56): type, type, items, type, minimum, type, type, type (+48 more)

### Community 30 - "content_agent_client.py"
Cohesion: 0.11
Nodes (52): _apply_material_auto_optimizer(), _apply_physics_auto_optimizer(), _attempt_summary(), _base_report(), _command(), _convert_physics_output_to_usd(), _download_artifact(), _emit_report() (+44 more)

### Community 31 - "print_log"
Cohesion: 0.06
Nodes (27): print_log(), Test metadata endpoint, Test Prometheus metrics endpoint, Test file management endpoints, Full workflow: upload → list → chat → download → delete → verify 404, Test chat completion endpoint, Non-streaming chat completion with base64 video, Streaming chat completion returns SSE chunks (+19 more)

### Community 32 - "run_finetune.py"
Cohesion: 0.08
Nodes (53): audit_existing_datalist(), _audit_volume(), build_override(), compare_checkpoint_weights(), _config_arg(), _copy_if_missing_or_broken(), _copy_upstream_config(), detect_env() (+45 more)

### Community 33 - "next_step"
Cohesion: 0.04
Nodes (48): output_image_path, renderer_skill, additionalProperties, agent, checks, errors, passed, skill (+40 more)

### Community 34 - "gen_trt_engine.tensorrt.calibration"
Cohesion: 0.24
Nodes (51): dataset.classify, dataset.classify.augmentation_config, dataset.classify.augmentation_config.with_scale_random_crop, dataset.classify.grid_map, dataset.classify.infer_dataset, dataset.classify.input_map, dataset.classify.quant_calibration_dataset, dataset.classify.test_dataset (+43 more)

### Community 35 - "properties"
Cohesion: 0.04
Nodes (51): excellent, improved, mixed, moderate, neutral, regressed, stage_optimization, strong (+43 more)

### Community 36 - "analyze_kpi.py"
Cohesion: 0.09
Nodes (45): build_best_f1_missed_no_pass_rows(), build_candidate_thresholds(), build_histogram_bins(), clean_label(), compute_all_metrics(), compute_f1(), compute_metrics_for_threshold(), format_far_percentage() (+37 more)

### Community 37 - "train"
Cohesion: 0.05
Nodes (45): actions, evaluate, export, inference, train, automl_enabled, core_module, gpu_ids (+37 more)

### Community 38 - "Deploy RTVI-CV-3D Stack"
Cohesion: 0.05
Nodes (45): ArangoDB, ArangoDB Graph DB, Elasticsearch, Elasticsearch DB, Embedding Endpoint, Kafka, Kafka Broker, Logstash Service (+37 more)

### Community 39 - "properties"
Cohesion: 0.04
Nodes (59): minimum, type, type, type, additionalProperties, type, additionalProperties, type (+51 more)

### Community 40 - "simready_package.py"
Cohesion: 0.17
Nodes (42): check_result_with_code(), _base_report(), _build_bom(), _compute_content_hash(), _compute_package_hash(), _content_files(), create_package(), _emit() (+34 more)

### Community 41 - "type"
Cohesion: 0.07
Nodes (36): properties, type, items, type, items, type, type, items (+28 more)

### Community 42 - "train"
Cohesion: 0.05
Nodes (43): train.optim.text_lr, train.optim.vision_lr, actions, evaluate, export, train, automl_enabled, automl_default_parameters (+35 more)

### Community 43 - "run_rflow_ct.py"
Cohesion: 0.10
Nodes (42): Any, Return a list of error messages (empty if valid)., validate_anatomy_list(), validate_body_region(), validate_controllable_anatomy_size(), _aggregate(), _detect_cuda(), _effective_anatomy_names() (+34 more)

### Community 44 - "train"
Cohesion: 0.05
Nodes (41): actions, evaluate, inference, train, automl_enabled, automl_default_parameters, core_module, gpu_ids (+33 more)

### Community 45 - "automl_disabled_parameters"
Cohesion: 0.33
Nodes (40): dataset.class_names, dataset.data_augmentor, dataset.data_augmentor.aug_config_list, dataset.data_augmentor.disable_aug_list, dataset.data_processor, dataset.data_split, dataset.info_path, dataset.point_cloud_range (+32 more)

### Community 46 - "warnings"
Cohesion: 0.10
Nodes (37): file_name, local_identifiers, recommended_web_queries, suffix, warnings, errors, required, $schema (+29 more)

### Community 47 - "optimization-plan.schema.json"
Cohesion: 0.09
Nodes (23): additionalProperties, $comment, items, type, type, items, type, items (+15 more)

### Community 48 - "properties"
Cohesion: 0.04
Nodes (45): case_id, file, fixture_file, format, generated_fixture, height, jpeg, png (+37 more)

### Community 49 - "required"
Cohesion: 0.06
Nodes (38): component_body_candidates, failed_requirements, profile_version, requirements_skipped, rigid_body_roots_after, selected_calls, output_dir, errors (+30 more)

### Community 50 - "automl_disabled_parameters"
Cohesion: 0.27
Nodes (39): dataset.train_dataset.args.filter_keys, dataset.train_dataset.args.ignore_tags, dataset.train_dataset.args.pre_processes, dataset.train_dataset.loader.batch_size, dataset.validate_dataset, dataset.validate_dataset.args, dataset.validate_dataset.args.filter_keys, dataset.validate_dataset.args.ignore_tags (+31 more)

### Community 51 - "properties"
Cohesion: 0.06
Nodes (38): items, type, type, type, type, items, type, items (+30 more)

### Community 52 - "USD Performance Tuning Workflow"
Cohesion: 0.07
Nodes (38): Apply Restructure, CAD Conversion Advisor, Compare Profiles, Instancing Readiness, Omniverse Authentication, Find Occluded Meshes, Remove Prims, Optimization Report (+30 more)

### Community 53 - "TimeMeasure"
Cohesion: 0.07
Nodes (12): Future, Support for context manager (with statement), Get elapsed time since start or last reset, Reset the timer to current time, Get execution time since start or last reset, SafeThreadEventLoop, TimeMeasure, Any (+4 more)

### Community 54 - "properties"
Cohesion: 0.04
Nodes (58): errorCount, kind, openability, rule, target, warningCount, pattern, type (+50 more)

### Community 55 - "properties"
Cohesion: 0.06
Nodes (37): additionalProperties, type, type, type, null, type, type, type (+29 more)

### Community 56 - "usd-validation-runner/scripts/usd_validation_executor.py"
Cohesion: 0.11
Nodes (37): ConceptResolutionError, coverage_complete(), _expand_target(), get_rule_registry(), get_validation_engine_cls(), _iter_execution_units(), iter_registered_rules(), load_registry() (+29 more)

### Community 57 - "discover_assets.py"
Cohesion: 0.12
Nodes (37): categorize_skill_dir(), collect_repo_signals(), count_arguments_usage(), emit_read_next_guidance(), emit_signal_summary(), extract_repo_contents(), extract_skill_contents(), find_agents() (+29 more)

### Community 58 - "OrderedDict"
Cohesion: 0.12
Nodes (17): OrderedDict, AutoModelDiagnostic, GenerativeDiagnostic, AutoModelMixin, batch_coords, batch_func, check_optional_dependencies, CoordSystem (+9 more)

### Community 59 - ".load_model"
Cohesion: 0.07
Nodes (27): check_optional_dependencies, Package, PrognosticModel, Default pre-trained model package on HuggingFace/NGC/S3. Returns -------…, Load prognostic model from package. Parameters ---------- package : Package…, PhooModelName, fixture, package (+19 more)

### Community 60 - "properties"
Cohesion: 0.05
Nodes (37): type, type, type, type, type, type, type, type (+29 more)

### Community 61 - "simready-validate/scripts/run.py"
Cohesion: 0.17
Nodes (35): _apply_single_component_rbmb001_policy(), _blocked_report(), _build_command(), _cli_help(), _dedupe_requirements(), emit(), _empty_counts(), _empty_topology() (+27 more)

### Community 62 - "properties"
Cohesion: 0.06
Nodes (36): additionalProperties, $comment, items, type, type, type, items, type (+28 more)

### Community 63 - "required"
Cohesion: 0.08
Nodes (36): all_geometry_consistent, all_images_hu_like, all_inference_outputs_present, all_pairs_readable, any_foreground_present, autoencoder_checkpoint, autoencoder_checkpoint_present, best_autoencoder_checkpoints (+28 more)

### Community 64 - "target_coverage"
Cohesion: 0.07
Nodes (30): description, type, complete, entries, complete, source_manifests, target_coverage, description (+22 more)

### Community 65 - "properties"
Cohesion: 0.07
Nodes (28): key, requires_extension, since_version, properties, required, type, description, pattern (+20 more)

### Community 66 - "physical-ai-video-data-augmentation/scripts/endpoint_common.sh"
Cohesion: 0.07
Nodes (24): HF_TOKEN, LLM_API_KEY, OPENAI_API_KEY, _recover_augmented_video_from_tmp(), cosmos_worker.sh script, UV_PROJECT_ENVIRONMENT, VLM_API_KEY, load_setup_env_or_fail() (+16 more)

### Community 67 - "properties"
Cohesion: 0.06
Nodes (35): AccessionNumber, BitsAllocated, Columns, InstanceNumber, NumberOfFrames, PhotometricInterpretation, PixelRepresentation, Rows (+27 more)

### Community 68 - "deploy_async.py"
Cohesion: 0.13
Nodes (32): build_tags(), create_model(), log(), make_endpoint_name(), parse_env(), Any, Shared helpers for the deployment scripts (deploy.py, deploy_async.py).…, Poll DescribeEndpoint until InService, or raise on Failed/timeout. (+24 more)

### Community 69 - "properties"
Cohesion: 0.06
Nodes (35): type, items, type, items, maxItems, minItems, type, properties (+27 more)

### Community 70 - "run_nv_reason_cxr.py"
Cohesion: 0.15
Nodes (34): _build_parser(), _call_hf_space_endpoint(), _cuda_report(), _hf_space_chat_fn_index(), _hf_space_image_payload(), _http_fetch(), _image_info(), ImageInfo (+26 more)

### Community 71 - "properties"
Cohesion: 0.09
Nodes (23): type, properties, items, type, items, maxItems, minItems, type (+15 more)

### Community 72 - "properties"
Cohesion: 0.06
Nodes (34): already_optimized, optimization, structuring, additionalProperties, type, additionalProperties, type, type (+26 more)

### Community 73 - "TestClassifyBound"
Cohesion: 0.08
Nodes (14): Path, classify_bound applies the boundedness-rules.md decision tree., compute_capacity treats the measured peak as authoritative., _arch_bucket_from_compute_cap chooses the right NVDEC throughput bucket., _nvdec_count_for_gpu matches by substring., parse_microbench handles current + legacy schema and skips garbage., parse_dmon extracts max(SM/mem/dec) from a `nvidia-smi dmon -s mu` log., TestArchBucketLookup (+6 more)

### Community 74 - "messager_reference.py"
Cohesion: 0.09
Nodes (17): BaseMessageConsumer, BaseMessageProducer, convert_to_vision_llm(), create_consumer(), create_producer(), _delivery_report(), JSONMessageConsumer, JSONMessageProducer (+9 more)

### Community 75 - "properties"
Cohesion: 0.06
Nodes (36): type, type, type, type, type, type, items, type (+28 more)

### Community 76 - "run_mr_brain_finetune.py"
Cohesion: 0.18
Nodes (33): _build_command_plan(), build_parser(), _config_sources(), _create_embedding_sidecars(), _emit(), _empty_output(), _git_commit(), _load_json() (+25 more)

### Community 77 - "properties"
Cohesion: 0.06
Nodes (33): type, type, type, type, properties, type, type, type (+25 more)

### Community 78 - "properties"
Cohesion: 0.06
Nodes (34): type, items, type, items, maxItems, minItems, type, properties (+26 more)

### Community 79 - "properties"
Cohesion: 0.06
Nodes (34): type, type, type, properties, type, type, type, type (+26 more)

### Community 80 - "properties"
Cohesion: 0.06
Nodes (37): centimeters, meters, millimeters, X, Y, Z, additionalProperties, description (+29 more)

### Community 81 - "automl_disabled_parameters"
Cohesion: 0.34
Nodes (33): dataset.augmentation.random_aug, dataset.augmentation.random_rotate, dataset.augmentation.random_rotate.enable, dataset.augmentation.scale, dataset.augmentation.with_scale_random_crop, dataset.augmentation.with_scale_random_crop.enable, dataset.train_nolabel, distill.teacher (+25 more)

### Community 82 - "properties"
Cohesion: 0.09
Nodes (23): ref_remap, restructure, type, type, enum, type, type, type (+15 more)

### Community 83 - "_meta"
Cohesion: 0.14
Nodes (14): GoldenTestBase, _meta(), Assert at least one of the top-N results contains all expected_in strings., TestColorConversion, TestCrop, TestDewarp, TestFlipRotate, TestMultiStream (+6 more)

### Community 84 - "properties"
Cohesion: 0.06
Nodes (33): properties, affine_match, affine_max_abs_diff, anatomy, image_affine, image_bytes, image_error, image_hu_bone_present (+25 more)

### Community 85 - "convert-to-usd/scripts/run.py"
Cohesion: 0.20
Nodes (28): already_usd_report(), ambiguous_directory_report(), append_selection_warnings(), ConversionReport, convert_to_usd(), directory_inspection_report(), emit_report(), is_existing_usd() (+20 more)

### Community 86 - "properties"
Cohesion: 0.07
Nodes (32): type, items, type, items, type, type, type, null (+24 more)

### Community 87 - "properties"
Cohesion: 0.06
Nodes (37): attached, direct, external, measured, not_measured, not_run, proxy, type (+29 more)

### Community 88 - "hf_benchmarks.py"
Cohesion: 0.15
Nodes (29): auth_headers(), benchmark_catalog(), build_parser(), collect_prefixed_tags(), dataset_search_blob(), dataset_search_fields(), expand_aliases(), first_text() (+21 more)

### Community 89 - "train"
Cohesion: 0.09
Nodes (32): batch_size, num_classes, num_instances, num_workers, val_batch_size, gpu_ids, num_gpus, num_nodes (+24 more)

### Community 90 - "SourceName"
Cohesion: 0.10
Nodes (20): DataArray, datetime64, check_optional_dependencies, datetime, ndarray, A single async fetch unit. Each task represents one (time, variable) pair to be…, Short description of the data source. Extended description: what data this…, Initialize the async filesystem connection. (+12 more)

### Community 91 - "operation-curation.schema.json"
Cohesion: 0.06
Nodes (30): analysis, canonical, deprecated, documentary, specialty, wired_into, rationale, properties (+22 more)

### Community 92 - "audit-report.schema.json"
Cohesion: 0.08
Nodes (24): artifact_paths, recommendedNextActions, schema_version, scope, selection_reason, targets, tier_assignments, findings (+16 more)

### Community 93 - "properties"
Cohesion: 0.06
Nodes (30): baseline, coverage_ledger, phase, summary, validators, additionalProperties, type, $comment (+22 more)

### Community 94 - "properties"
Cohesion: 0.07
Nodes (30): acceptable, n_fail, n_warn, warn, type, type, properties, fail (+22 more)

### Community 95 - "earth2studio-create-diagnostic/references/testing-guide.py"
Cohesion: 0.12
Nodes (28): assert_diagnostic_coord_order(), assert_generative_coord_order(), load_mock_model(), make_coords(), make_input(), PhooModelName, fixture, Package (+20 more)

### Community 96 - "huggingface-vision-trainer/scripts/dataset_inspector.py"
Cohesion: 0.12
Nodes (30): analyze_annotations(), api_request(), check_image_classification_compatibility(), check_object_detection_compatibility(), check_sam_segmentation_compatibility(), detect_bbox_format(), _extract_image_size(), find_columns() (+22 more)

### Community 97 - "model_inventory"
Cohesion: 0.06
Nodes (31): type, items, type, files, properties, required, type, all_present (+23 more)

### Community 98 - "run_vae_finetune.py"
Cohesion: 0.21
Nodes (30): _build_command(), build_parser(), _emit(), _empty_output(), _git_commit(), _load_json(), _loss_weighted_sum(), main() (+22 more)

### Community 99 - "run_ctmr.py"
Cohesion: 0.18
Nodes (30): _build_command(), _candidate_upstream_roots(), _coerce_label_id(), emit(), _empty_geometry(), _empty_output_summary(), _error_payload(), _expected_output_candidates() (+22 more)

### Community 100 - "actions"
Cohesion: 0.06
Nodes (30): actions, dataset_convert, evaluate, export, inference, automl_enabled, core_module, path (+22 more)

### Community 101 - "evaluate"
Cohesion: 0.06
Nodes (30): actions, evaluate, export, inference, train, automl_enabled, automl_default_parameters, core_module (+22 more)

### Community 102 - "properties"
Cohesion: 0.07
Nodes (29): binary, clean_v2, graded_s0_s4, mostly_custom, v2_plus_custom, type, type, format (+21 more)

### Community 103 - "properties"
Cohesion: 0.09
Nodes (28): ddpm-ct, rflow-ct, type, type, type, type, items, type (+20 more)

### Community 104 - "uart_session.py"
Cohesion: 0.10
Nodes (27): _check_sudo_pw(), check_tty_lock(), cmd_pull(), cmd_push(), _dispatch(), _ensure_pyserial(), main(), parse_args() (+19 more)

### Community 105 - "properties"
Cohesion: 0.04
Nodes (46): type, device, type, device, preflight_only, runtime, subprocess_seconds, properties (+38 more)

### Community 106 - "enum"
Cohesion: 0.07
Nodes (29): approved, BLOCKED, blocked_validation_runtime, probed_clean, probed_with_findings, TIMEOUT, timeout_recorded, user_declined (+21 more)

### Community 107 - "properties"
Cohesion: 0.07
Nodes (29): dependent_after, independent, shared_first, enum, type, properties, type, description (+21 more)

### Community 108 - "train.lr"
Cohesion: 0.17
Nodes (29): train.decay_step_list, train.lr_clip, train.lr_decay, train.lr_warmup, train.momentum, train.wd, train.weight_decay, automl_default_parameters (+21 more)

### Community 109 - "properties"
Cohesion: 0.05
Nodes (36): code, level, type, items, type, type, type, type (+28 more)

### Community 110 - "ovrtx Renderer"
Cohesion: 0.08
Nodes (28): AppStreamer Client, NativeShmClient, Python SHM Server, AxisOverlay, ovusd-shm, Renderer Runtime, Runtime, AttributeBinding (+20 more)

### Community 111 - "pluginctl"
Cohesion: 0.08
Nodes (28): Beehive, Beekeeper, BioCLIP, BirdNET V2.4, ECR, /etc/waggle/node-manifest-v2.json, pluginctl, pywaggle (+20 more)

### Community 112 - "required"
Cohesion: 0.07
Nodes (26): BodyPartExamined, dicom_metadata, n_slices, phi_present, phi_scope_disclaimer, phi_tags_found, SeriesDescription, SeriesInstanceUID (+18 more)

### Community 113 - "TestValidateFormat"
Cohesion: 0.11
Nodes (14): compact JSON output should be substantially smaller than full json., argparse should reject an unknown --format value., validate_pipeline.py --format {json,summary}, Multi-stream pipelines should mention 'live-parse skipped' in summary., The Step 5 generated script uses 'gst-launch-1.0 -e' — validator must accept., generate_pipeline.py --format {json,compact,summary}, Default (no --format) must remain full JSON for backward compat., --format=json explicitly should match the default behavior. (+6 more)

### Community 114 - "PaperManager"
Cohesion: 0.13
Nodes (16): main(), PaperManager, Any, Link a paper to a model/dataset/space repository. Args: repo_id: Repository…, Add paper reference to README content. Args: content: Current README content…, Create a research article from template. Args: template: Template name…, Fetch paper information from arXiv API. Args: arxiv_id: arXiv identifier…, Generate citation for a paper. Args: arxiv_id: arXiv identifier format:… (+8 more)

### Community 115 - "run_mr_brain.py"
Cohesion: 0.20
Nodes (27): _aggregate(), _build_command(), _candidate_upstream_roots(), _detect_cuda(), emit(), _estimate_cost(), file_sha256_safe(), git_commit() (+19 more)

### Community 116 - "run_mr.py"
Cohesion: 0.20
Nodes (27): _aggregate(), _build_command(), _candidate_upstream_roots(), _detect_cuda(), emit(), _estimate_cost(), file_sha256_safe(), git_commit() (+19 more)

### Community 117 - "properties"
Cohesion: 0.07
Nodes (27): additionalProperties, type, type, type, null, type, type, type (+19 more)

### Community 118 - "properties"
Cohesion: 0.07
Nodes (27): additionalProperties, type, type, type, null, type, type, type (+19 more)

### Community 119 - "properties"
Cohesion: 0.07
Nodes (27): additionalProperties, type, type, type, null, type, type, type (+19 more)

### Community 120 - "physical-ai-people-attribute-search/scripts/endpoint_common.sh"
Cohesion: 0.08
Nodes (17): HF_TOKEN, IMAGE_EDIT_API_KEY, LLM_API_KEY, OPENAI_API_KEY, augmentation_worker.sh script, UV_PROJECT_ENVIRONMENT, VLM_API_KEY, HF_TOKEN (+9 more)

### Community 121 - "required"
Cohesion: 0.09
Nodes (26): asset_physical_context, hierarchy_dedupe, load_time, phase_recommendation, storage_proxy, structure_proxy, summary_counts, validation_scope (+18 more)

### Community 122 - "type"
Cohesion: 0.08
Nodes (27): cross_component_pairs, per_asset, skip, items, type, items, items, type (+19 more)

### Community 123 - "earth2studio-create-prognostic/references/method-templates.py"
Cohesion: 0.10
Nodes (26): call_template(), create_iterator_template(), default_generator_template(), input_coords_template(), input_coords_with_history_template(), load_default_package_template(), load_model_template(), output_coords_template() (+18 more)

### Community 124 - "run_ct_image.py"
Cohesion: 0.20
Nodes (25): _aggregate(), _build_command(), _candidate_upstream_roots(), _detect_cuda(), _estimate_cost(), _load_config_override(), _load_json(), main() (+17 more)

### Community 125 - "assemble-package-source/scripts/run.py"
Cohesion: 0.22
Nodes (26): _anchored_relative(), assemble(), _authored_asset_paths(), _copy_with_collision(), _errors_from_checks(), _file_same(), _is_uri(), _iter_prim_specs() (+18 more)

### Community 126 - "kit_app_template_cad.py"
Cohesion: 0.21
Nodes (26): _cad_core_for_source(), check_dependencies(), _compact(), convert_with_kit_app_template(), _core_command(), _core_exec_payload(), discover_generated_files(), _host_platform() (+18 more)

### Community 127 - "properties"
Cohesion: 0.07
Nodes (26): additionalProperties, type, type, type, type, type, type, type (+18 more)

### Community 128 - "train"
Cohesion: 0.10
Nodes (27): inference, gpu_ids, num_gpus, num_nodes, popular, popular, batch_size, gpu_id (+19 more)

### Community 129 - "object_detection_training.py"
Cohesion: 0.11
Nodes (25): AutoImageProcessor, BatchFeature, EvalPrediction, augment_and_transform_batch(), collate_fn(), compute_metrics(), convert_bbox_yolo_to_pascal(), DataTrainingArguments (+17 more)

### Community 130 - "NvInferServerCustomProcess"
Cohesion: 0.12
Nodes (20): IBatchArray, IBatchBuffer, IInferCustomProcessor, InferBufferDescription, InferDataType, InferMemType, IOptions, map (+12 more)

### Community 131 - "required"
Cohesion: 0.06
Nodes (30): artifacts, gates, inputs, measurement_context, metric_groups, metrics, optimization_score, output_path (+22 more)

### Community 132 - "required"
Cohesion: 0.10
Nodes (26): amp, batch_size, cache_rate, dataset_dir, finetune, label_mappings, lr, nproc_per_node (+18 more)

### Community 133 - "hierarchy_dedupe"
Cohesion: 0.08
Nodes (26): copies, estimated_prim_savings, path_pattern, reason, recommended, subtree_prims, top_candidates, additionalProperties (+18 more)

### Community 134 - "setup-preflight.schema.json"
Cohesion: 0.06
Nodes (40): runtime_context, runtime_route, assetValidator, kit, sceneOptimizer, required, additionalProperties, additionalProperties (+32 more)

### Community 135 - "properties"
Cohesion: 0.08
Nodes (25): type, type, type, properties, type, type, type, type (+17 more)

### Community 136 - "properties"
Cohesion: 0.08
Nodes (26): type, type, properties, type, device, type, device, exit_code (+18 more)

### Community 137 - "properties"
Cohesion: 0.08
Nodes (26): type, type, properties, type, device, type, device, exit_code (+18 more)

### Community 138 - "properties"
Cohesion: 0.08
Nodes (26): type, type, type, type, type, type, null, type (+18 more)

### Community 139 - "properties"
Cohesion: 0.08
Nodes (26): type, type, type, type, type, type, null, type (+18 more)

### Community 140 - "properties"
Cohesion: 0.08
Nodes (26): type, type, type, type, type, type, null, type (+18 more)

### Community 141 - "properties"
Cohesion: 0.08
Nodes (26): type, type, type, type, type, type, null, type (+18 more)

### Community 142 - "properties"
Cohesion: 0.08
Nodes (25): additionalProperties, type, type, type, type, null, type, type (+17 more)

### Community 143 - "render_card.py"
Cohesion: 0.14
Nodes (25): _apply_marker_defaults(), _load_catalog(), main(), Path, Load a canned-entries catalog from references/catalog/<name>.json. Missing…, Ensure optional verify-marker fields exist so StrictUndefined doesn't bite., render(), _type_name() (+17 more)

### Community 144 - "usd-convert-cad/scripts/run.py"
Cohesion: 0.22
Nodes (20): AST, cad_to_usd(), ConversionReport, default_upstream_root(), discover_generated_files(), emit_probe(), emit_report(), main() (+12 more)

### Community 145 - "properties"
Cohesion: 0.08
Nodes (25): cuda_available, gpu_count, gpu_free_mb, gpu_total_mb, host_ram_mb, type, properties, required (+17 more)

### Community 146 - "properties"
Cohesion: 0.08
Nodes (25): default, type, additionalProperties, type, type, items, type, properties (+17 more)

### Community 147 - "enum"
Cohesion: 0.29
Nodes (7): S0, S1, S2, S3, S4, severity, enum

### Community 148 - "DDMTensorRTEngine"
Cohesion: 0.12
Nodes (12): load_ddm_net_model(), Module, DDMTensorRTEngine, Tensor, Run one TRT call on exactly trt_batch_size windows. Returns: logits:…, Run TRT inference over an arbitrary number of windows, chunking into…, This function allows the model to initialize any state associated with this…, Step 1: load a cached engine from DDM_TRT_ENGINE_OUTPUT_PATH if it exists and… (+4 more)

### Community 149 - "preflight_series.py"
Cohesion: 0.15
Nodes (20): dicom-series-preflight, _axcodes_from_iop(), _iop_list(), _is_compressed_transfer_syntax(), _list_dicom_paths(), main(), _phi_tags_found(), preflight() (+12 more)

### Community 150 - "check_interconnect.py"
Cohesion: 0.15
Nodes (24): Check, check_env(), check_nixl(), check_node(), classify_node_probe(), exec_prefix(), find_env_value(), main() (+16 more)

### Community 151 - "earth2studio-create-diagnostic/references/method-templates.py"
Cohesion: 0.11
Nodes (24): automodel_call_template(), generative_call_template(), generative_output_coords_template(), input_coords_template(), load_default_package_template(), load_model_template(), output_coords_template(), check_optional_dependencies (+16 more)

### Community 152 - "_pinmux_dt.py"
Cohesion: 0.12
Nodes (24): _apply_pinmux_edits(), Apply all session pin_edits to a pinmux DTSI text in memory., _append_one_gpio(), gpio_macro_for(), _insert_marker(), _patch_function(), patch_gpio_block(), _patch_optional() (+16 more)

### Community 153 - "detect_jetson.sh"
Cohesion: 0.11
Nodes (11): need_value(), common.sh script, __assign_variant(), __derive_generation_and_product_line(), __jetson_present(), detect_jetson.sh script, render_line(), mem_summary.sh script (+3 more)

### Community 154 - "dataset_convert"
Cohesion: 0.08
Nodes (24): actions, dataset_convert, inference, train, automl_enabled, automl_default_parameters, automl_disabled_parameters, core_module (+16 more)

### Community 155 - "ModelName"
Cohesion: 0.14
Nodes (16): PrognosticMixin, ModelName, AutoModelMixin, batch_coords, batch_func, CoordSystem, Module, Tensor (+8 more)

### Community 156 - "command"
Cohesion: 0.15
Nodes (24): config_file, required, required, required, required, command, exit_code, model_inventory (+16 more)

### Community 157 - "huggingface-llm-trainer/scripts/dataset_inspector.py"
Cohesion: 0.15
Nodes (23): api_request(), check_dpo_compatibility(), check_grpo_compatibility(), check_kto_compatibility(), check_sft_compatibility(), find_columns(), format_value_preview(), generate_mapping_code() (+15 more)

### Community 158 - "_pinmux_common.py"
Cohesion: 0.13
Nodes (23): _augment_with_gpio(), cmd_lookup(), Decorate edits with `_gpio` (bank/idx/kind) when sfio == 'gpio'., Resolve a CVM ball / signal / pin query against the pinmap KB., load_pinmap(), load_session(), lookup_summary(), parse_gpio_sfio() (+15 more)

### Community 159 - "cmd_commit"
Cohesion: 0.11
Nodes (24): _build_commit_state(), cmd_commit(), _CommitState, _emit_diff(), _FileEdit, _prep_commit(), _print_commit_plan(), _print_lookup_suggestions() (+16 more)

### Community 160 - "properties"
Cohesion: 0.08
Nodes (23): type, type, properties, type, type, type, type, properties (+15 more)

### Community 161 - "properties"
Cohesion: 0.09
Nodes (23): type, items, type, type, type, null, type, type (+15 more)

### Community 162 - "simready-conform-profile/scripts/run.py"
Cohesion: 0.30
Nodes (23): _append_unique(), conform(), _core_output_path(), emit(), _empty_report(), _failed_requirements(), _finalize(), _load_json() (+15 more)

### Community 163 - "probe-snapshot.schema.json"
Cohesion: 0.06
Nodes (34): kit_application, so_build_date, so_extension_version, $comment, description, type, probed_at, description (+26 more)

### Community 164 - "layer_norm_forward"
Cohesion: 0.11
Nodes (22): next_power_of_2(), Constant, kernel, Tensor, Test function to verify correctness., Return the smallest power of 2 >= n., cuTile kernel for row-wise softmax. Each block processes multiple rows using…, Host wrapper for cuTile softmax. Applies softmax along the last dimension (row-… (+14 more)

### Community 165 - "fetch_api_support.py"
Cohesion: 0.13
Nodes (16): HTMLParser, ApiEntry, _Cell, _classify_row(), _ComparisonParser, fetch_html(), main(), _notes_for() (+8 more)

### Community 166 - "properties"
Cohesion: 0.05
Nodes (41): description, type, items, type, items, type, type, type (+33 more)

### Community 167 - "test_run_rflow_ct.py"
Cohesion: 0.11
Nodes (10): ndarray, Path, _save_pair(), test_aggregate_checks_saved_output_label_ordinals_not_raw_maisi_ids(), test_aggregate_flags_empty_foreground_and_constant_image(), test_aggregate_pass(), test_aggregate_reports_missing_expected_output_label(), test_curated_lung_tumor_fixture_uses_robust_size() (+2 more)

### Community 168 - "properties"
Cohesion: 0.09
Nodes (23): type, properties, items, type, items, maxItems, minItems, type (+15 more)

### Community 169 - "inference"
Cohesion: 0.09
Nodes (22): actions, inference, quantize, automl_enabled, failures, automl_default_parameters, automl_disabled_parameters, core_module (+14 more)

### Community 170 - "setup-nvidia-gpu-host.sh"
Cohesion: 0.25
Nodes (22): add_invoker_to_docker_group(), configure_docker_runtime(), confirm_install(), container_toolkit_ok(), cuda_ok(), detect_distro(), docker_installed_ok(), docker_runtime_ok() (+14 more)

### Community 171 - "train"
Cohesion: 0.10
Nodes (23): evaluate, core_module, gpu_ids, num_gpus, num_nodes, path, popular, schema_action (+15 more)

### Community 172 - "parallel_npy_load.py"
Cohesion: 0.20
Nodes (21): OutputStore, build_parser(), build_reference(), cleanup_phase(), demo_phase(), discover_layout(), load_seed_if_present(), load_tile() (+13 more)

### Community 173 - "properties"
Cohesion: 0.09
Nodes (22): authored_list_op_items, mixed_or_unknown, prims_with_authored_arcs, properties, description, enum, type, type (+14 more)

### Community 174 - "required"
Cohesion: 0.09
Nodes (25): metersPerUnit, openedWith, upAxis, identifier, rootLayer, required, type, identifier (+17 more)

### Community 175 - "properties"
Cohesion: 0.09
Nodes (22): type, type, properties, type, device, device, exit_code, invocation (+14 more)

### Community 176 - "required"
Cohesion: 0.12
Nodes (22): checks, errors, passed, skill, status, required, checks, errors (+14 more)

### Community 177 - "properties"
Cohesion: 0.10
Nodes (21): type, items, type, type, type, type, properties, asset_path (+13 more)

### Community 178 - "align_token_usage.py"
Cohesion: 0.16
Nodes (21): _accumulate(), align(), _build_parser(), collect_assistant_usage(), cwd_to_project_slug(), discover_project_dir(), _empty_tokens(), main() (+13 more)

### Community 179 - "cuopt-developer"
Cohesion: 0.10
Nodes (21): cuopt-developer, Build & Test, Contributing, Coding Conventions, First-Time Dev Environment Setup, Numerical Debugging, Python Bindings Guide, Troubleshooting & CI Gotchas (+13 more)

### Community 180 - "MissingNumberDetector"
Cohesion: 0.11
Nodes (12): generate_clean_sequence(), MissingNumberDetector, Complete the current cycle and detect any missing numbers and collect mis-…, Get comprehensive statistics about the detection process, Get status of the current incomplete cycle, Complete any remaining cycles, Detects missing numbers and mis-ordered numbers in a sequence that should…, Print a summary of the sequence processing (+4 more)

### Community 181 - "cmd_set_pin"
Cohesion: 0.13
Nodes (21): _build_edit_record(), cmd_generate(), cmd_probe(), cmd_set_pin(), _GenerateCtx, _load_generate_dtsi(), Namespace, Validate set-pin CLI args. Returns 0 on success, error code otherwise. (+13 more)

### Community 182 - "properties"
Cohesion: 0.10
Nodes (21): properties, all_finite, finite_fraction, image_affine, image_bytes, image_error, image_nonconstant, image_nonnegative (+13 more)

### Community 183 - "properties"
Cohesion: 0.10
Nodes (21): properties, all_finite, finite_fraction, image_affine, image_bytes, image_error, image_nonconstant, image_nonnegative (+13 more)

### Community 184 - "CAD to SimReady"
Cohesion: 0.12
Nodes (21): CAD to SimReady, Assemble Package Source, Content Agents, Convert to USD, Deploy Content Agents, Identify Asset Context, Material Agent Client, MuJoCo to USD Converter (+13 more)

### Community 185 - "server.py"
Cohesion: 0.18
Nodes (19): FastAPI, get, _build_backend(), _enrich_incident_with_video(), health(), lifespan(), main(), _parse_backend_names() (+11 more)

### Community 186 - "automl_disabled_parameters"
Cohesion: 0.10
Nodes (20): custom.train_dataset, custom.val_dataset, custom.vision, logging, logging.logger, policy, policy.lora, policy.lora.alpha_pattern (+12 more)

### Community 187 - "train"
Cohesion: 0.10
Nodes (20): policy.lora.lora_alpha, policy.lora.lora_dropout, policy.lora.r, train.optm_decay_type, train.optm_lr, train.optm_weight_decay, train.train_batch_per_replica, train (+12 more)

### Community 188 - "BM25Retriever"
Cohesion: 0.15
Nodes (7): BM25Retriever, BM25 retriever with structural metadata boosting. Pure stdlib., Load pipeline dataset from CSV. The fully-indexed retriever state (documents,…, Compute IDF with BM25 formula: log((N - df + 0.5) / (df + 0.5) + 1)., Precompute term frequency dicts per document., Regression: the BM25 index is cached to a sibling JSON file keyed on (CSV…, TestIndexCache

### Community 189 - "UartSession"
Cohesion: 0.13
Nodes (14): check_cuda(), main(), parse_args(), Check CUDA availability and exit if not available., LoginError, Exception, Pattern, Raised when UART login or PS1 sentinel setup fails. (+6 more)

### Community 190 - "run_ct_from_mask.py"
Cohesion: 0.30
Nodes (19): _aggregate(), _build_command(), _candidate_upstream_roots(), _detect_cuda(), _load_json(), _load_request(), main(), _model_inventory() (+11 more)

### Community 191 - "properties"
Cohesion: 0.10
Nodes (20): type, type, type, type, type, type, type, minimum (+12 more)

### Community 192 - "properties"
Cohesion: 0.10
Nodes (20): type, type, type, type, type, type, type, minimum (+12 more)

### Community 193 - "conv2d_with_bias_dilation_groups.py"
Cohesion: 0.12
Nodes (17): _adjust_group_size(), conv2d_implicit_gemm_kernel(), launch(), next_power_of_2(), Constant, kernel, pytorch_reference(), Compute 2D convolution with bias via implicit im2col GEMM on tensor cores. (+9 more)

### Community 194 - "conv_transpose_2d.py"
Cohesion: 0.13
Nodes (17): _adjust_group_size(), conv_transpose_2d_implicit_gemm_kernel(), launch(), next_power_of_2(), Constant, kernel, pytorch_reference(), Compute 2D transposed convolution via implicit im2col GEMM on tensor cores. (+9 more)

### Community 195 - "conv_transpose_3d.py"
Cohesion: 0.13
Nodes (17): _adjust_group_size(), conv_transpose_3d_implicit_gemm_kernel(), launch(), next_power_of_2(), Constant, kernel, pytorch_reference(), Compute 3D transposed convolution via implicit im2col GEMM on tensor cores. (+9 more)

### Community 196 - "DashboardNotifier"
Cohesion: 0.16
Nodes (10): DashboardNotifier, GatewayRpcError, _http_url_to_ws_url(), Any, Exception, Injects incident notifications directly into the OpenClaw Dashboard ``alerts``…, Send a single RPC request and wait for the matching response., Open a WebSocket, complete the connect handshake, return the ws. (+2 more)

### Community 197 - "automl_default_parameters"
Cohesion: 0.35
Nodes (19): train.optim.embedder.base_lr, train.optim.embedder.bias_lr_factor, train.optim.embedder.momentum, train.optim.embedder.weight_decay, train.optim.embedder.weight_decay_bias, train.optim.gamma, train.optim.miner_function_margin, train.optim.triplet_loss_margin (+11 more)

### Community 198 - "modify_pinmux.py"
Cohesion: 0.15
Nodes (18): _add_apply_parser(), _add_commit_parser(), _add_generate_parser(), _add_lookup_parser(), _add_probe_parser(), _add_set_pin_parser(), build_parser(), cmd_apply() (+10 more)

### Community 199 - "run_ct_mask.py"
Cohesion: 0.33
Nodes (18): _aggregate(), _anatomy_size_condition(), _candidate_upstream_roots(), _detect_cuda(), _expected_label_mapping(), _load_json(), _load_label_dict(), _load_request() (+10 more)

### Community 200 - "validate-usd-minimum/scripts/run.py"
Cohesion: 0.26
Nodes (14): _base_metadata(), _collect_usd_structure_metadata(), _count_applied_api(), _count_authored_references(), _count_material_bindings(), _count_meshes(), emit_report(), main() (+6 more)

### Community 201 - "conv3d_with_bias_dilation_groups.py"
Cohesion: 0.13
Nodes (16): _adjust_group_size(), conv3d_implicit_gemm_kernel(), launch(), next_power_of_2(), Constant, kernel, pytorch_reference(), Compute 3D convolution (no bias) via implicit im2col GEMM on tensor cores. (+8 more)

### Community 202 - "Apply Configuration Guide"
Cohesion: 0.11
Nodes (19): RTVI-CV API Reference, Apply Configuration Guide, apply_config.sh, cache_nvinfer_engine.sh, Container Reuse Guide, Deploy Defaults, RTVI-CV Runbook, Environment and Secrets (+11 more)

### Community 203 - "calibration_manager.py"
Cohesion: 0.23
Nodes (18): CalibrationError, cmd_check(), cmd_ensure(), generate_calibration(), generate_sensor_id(), get_sensor_count(), load_calibration(), main() (+10 more)

### Community 204 - "vss-deploy-detection-tracking-2d/scripts/common.sh"
Cohesion: 0.19
Nodes (11): backup_once(), compute_tile_grid(), die(), require_dir(), require_file(), resolve_unique_path(), common.sh script, update_ds_config() (+3 more)

### Community 205 - "instancing"
Cohesion: 0.11
Nodes (18): candidates, instances, prototypes, ratio, type, type, additionalProperties, description (+10 more)

### Community 206 - "automl_disabled_parameters"
Cohesion: 0.29
Nodes (18): dataset.transform, dataset.transform.local_crops_scale, model.distill, train.schedulers, train.schedulers.last_layer_learning_rate, train.schedulers.learning_rate, train.schedulers.momentum, train.schedulers.teacher_temperature (+10 more)

### Community 207 - "automl_disabled_parameters"
Cohesion: 0.11
Nodes (18): evaluate.dataset, evaluate.evaluation, evaluate.evaluation.soft_accuracy, evaluate.generation, evaluate.metrics.names, evaluate.model, evaluate.results, evaluate.task (+10 more)

### Community 208 - "export"
Cohesion: 0.14
Nodes (18): train.optimizer.args.lr, train.optimizer.args.weight_decay, export, train, automl_default_parameters, automl_default_parameters, core_module, path (+10 more)

### Community 209 - "receive_incident"
Cohesion: 0.17
Nodes (17): Request, day_stats(), has_day(), main(), _post(), _valid(), _fan_out(), Run backend coroutines concurrently and normalise exceptions to results. (+9 more)

### Community 210 - "export_ddm_to_tensorrt_reference.py"
Cohesion: 0.16
Nodes (15): build_trt_engine(), DDMWrapper, export_to_onnx(), find_ddm_base_path(), load_ddm_model(), main(), Module, Tensor (+7 more)

### Community 211 - "recommend.py"
Cohesion: 0.22
Nodes (17): audit_int(), build_alternatives(), build_flags(), build_notes(), l4t_major(), llama_cpp_flags(), load_audit(), main() (+9 more)

### Community 212 - "omni-asset-validate/scripts/run.py"
Cohesion: 0.25
Nodes (13): AssetValidatorIssue, AssetValidatorReport, dependency_blocked_report(), emit_report(), flatten_issues(), issue_location(), issue_requirement(), issue_suggestion() (+5 more)

### Community 213 - "04_matmul/triton_kernel.py"
Cohesion: 0.18
Nodes (16): autotune, benchmark_matmul(), matmul(), matmul_fp16(), matmul_kernel(), matmul_kernel_autotuned(), constexpr, jit (+8 more)

### Community 214 - "test_nv_reason_cxr.py"
Cohesion: 0.26
Nodes (16): ModuleType, CompletedProcess, Path, _run(), _script_module(), test_api_backend_mock_keeps_json_contract(), test_api_backend_rejects_local_files_only(), test_check_setup_reports_json() (+8 more)

### Community 215 - "required"
Cohesion: 0.13
Nodes (17): anatomy, maisi_label_id, output_label_id, required, items, type, output_label_mapping, samples (+9 more)

### Community 216 - "required"
Cohesion: 0.12
Nodes (16): copied_files, deliverable_root, output_root, rewritten_paths, root_usd_path, root_usd_relative_path, thumbnail_path, additionalProperties (+8 more)

### Community 217 - "recipe_tool.py"
Cohesion: 0.29
Nodes (16): discover(), gpu_count_hint(), gpu_values_in_yaml_blocks(), line_matches(), main(), match_recipes(), metadata_names(), model_cache_dir_for() (+8 more)

### Community 218 - "properties"
Cohesion: 0.12
Nodes (17): severity, items, type, properties, required, message, name, passed (+9 more)

### Community 219 - "FET_004_SIMULATE_MULTI_BODY_PHYSICS/scripts/run.py"
Cohesion: 0.32
Nodes (16): _aggregate_rigid_bodies_to_remove(), emit(), _find_component_body_candidates(), _find_rigid_bodies(), _has_schema(), _is_collider(), _is_mass_api(), _is_rigid_body() (+8 more)

### Community 220 - "NVIDIA RAG Blueprint Skill"
Cohesion: 0.15
Nodes (17): Agentic RAG Configuration, NeMo Guardrails Configuration, MCP Server & Client Configuration, Models and Infrastructure Configuration, Observability Configuration, Search and Retrieval Configuration, RAG Deployment Guide, RAG Docker Deployment (+9 more)

### Community 221 - "tao-run-on-slurm"
Cohesion: 0.15
Nodes (12): tao-run-on-slurm, tao-run-platform, TAO Execution SDK, SlurmSDK, tao-setup-nvidia-gpu-host, tao-train-action-recognition, tao-train-bevfusion, Lustre Filesystem (+4 more)

### Community 222 - "open_claw_dashboard_notifier.py"
Cohesion: 0.21
Nodes (14): build_test_incident(), humanize_category(), Any, Safely traverse nested dicts/lists, returning *default* on any miss., ``"ppe_violation"`` → ``"Ppe Violation"``., Synthetic incident for end-to-end wiring tests., safe_get(), build_dashboard_message() (+6 more)

### Community 223 - "required"
Cohesion: 0.12
Nodes (16): case, definition, examples_safe, examples_unsafe, in_scope, out_of_scope, resolution, items (+8 more)

### Community 224 - "capacity_report.py"
Cohesion: 0.19
Nodes (15): _arch_bucket_from_compute_cap(), classify_bound(), compute_capacity(), main(), _nvdec_count_for_gpu(), parse_dmon(), parse_microbench(), Path (+7 more)

### Community 225 - ".process_sop_check"
Cohesion: 0.17
Nodes (9): Load the checker from the cache., Save the checker to the cache., Try to delete the checker from the cache., Process SOP checking logic. Args: action_json: The content of the actions.json…, Parse SOP steps from content string and return them as a list. Args: content…, read_sop_steps(), SopCheckerCache, SopCheckerRequest (+1 more)

### Community 226 - "mujoco-usd-converter/scripts/run.py"
Cohesion: 0.31
Nodes (11): ConversionReport, discover_generated_files(), emit_probe(), emit_report(), is_mujoco_source(), main(), probe_source(), Any (+3 more)

### Community 227 - "usd-convert-cad/scripts/check_dependencies.py"
Cohesion: 0.25
Nodes (14): check_dependencies(), check_upstream_validation(), default_upstream_root(), main(), Any, Path, resolve_usd_convert_cad_root(), _write_report() (+6 more)

### Community 228 - "identify-asset-context/scripts/run.py"
Cohesion: 0.36
Nodes (15): _dedupe(), _detect_source_format(), _emit(), inspect_source_asset(), _local_identifiers(), main(), _markdown(), _metadata_from_excerpt() (+7 more)

### Community 229 - "validate_report.py"
Cohesion: 0.23
Nodes (15): load_recorded_manifests(), main(), _manifest_targets(), Any, Path, Return a list of schema-violation messages; empty list means the report…, Enforce the load-bearing apply-restructure manifest invariants. Independent of…, Load the manifests recorded in ``target_coverage.source_manifests[]``. Relative… (+7 more)

### Community 230 - "TAO DEFT AOI"
Cohesion: 0.13
Nodes (16): PAIDF AnomalyGen, TAO Analyze Gaps Visual ChangeNet, Container Setup and Path Mounting, Output Report Structure, Common Pitfalls, TAO VCN Classify Gap Analysis Skill, Visual Spot Check, VLM Binary Classification Gap Analysis Skill (+8 more)

### Community 231 - "export"
Cohesion: 0.12
Nodes (16): actions, export, inference, train, core_module, path, schema_action, spec_template (+8 more)

### Community 232 - "evaluate"
Cohesion: 0.20
Nodes (16): gpu_ids, num_gpus, num_nodes, popular, popular, batch_size, gpu_id, gpu_ids (+8 more)

### Community 233 - "03_layernorm/triton_kernel.py"
Cohesion: 0.18
Nodes (15): layernorm_backward(), layernorm_backward_kernel(), layernorm_dgamma_dbeta_kernel(), layernorm_forward(), layernorm_forward_kernel(), constexpr, jit, Tensor (+7 more)

### Community 234 - "collect_metrics.sh"
Cohesion: 0.12
Nodes (12): API_FAILS, CPU_UTILS, FPS_COUNT, FPS_SUM, GPU_MEM_GB, GPU_POWERS, GPU_TEMPS, GPU_UTILS (+4 more)

### Community 235 - "NotifierBase"
Cohesion: 0.14
Nodes (9): ABC, NotifierBase, Any, Abstract notifier. Each delivery backend implements this interface. Lifecycle:…, Validate config and connect to the backend. Raise on fatal errors., Deliver a formatted notification for the given incident payload., Deliver a synthetic test notification to verify end-to-end wiring., Release any resources held by the backend (HTTP clients, etc.). (+1 more)

### Community 236 - "properties"
Cohesion: 0.12
Nodes (17): $comment, type, $comment, pattern, type, properties, type, type (+9 more)

### Community 237 - "required"
Cohesion: 0.13
Nodes (14): custom_layer_key, custom_layer_written, sidecar_json_path, tool, checks, errors, metadata, passed (+6 more)

### Community 238 - "enum"
Cohesion: 0.13
Nodes (15): customer_byo_policy, eval_rubric, ncs, ncs-reasoning, ncs-vl, nemo-guardrails, runtime_guardrails, training_data_labeling (+7 more)

### Community 239 - "artifacts"
Cohesion: 0.13
Nodes (15): html, json, markdown, additionalProperties, description, properties, required, type (+7 more)

### Community 240 - "required"
Cohesion: 0.13
Nodes (15): instance_count, material_count, payload_count, prim_count, prototype_count, reference_count, target_class, mesh_count (+7 more)

### Community 241 - "AIQ Deploy Skill"
Cohesion: 0.13
Nodes (15): AI-Q Workflow Configs, Docker Compose Deployment, Deep Research Completion Validation, Environment And Secrets, FRAG / Foundational RAG, Kubernetes And Helm Deployment, Local Web Deployment, Locate Or Clone AI-Q (+7 more)

### Community 242 - "generate_pipeline.py"
Cohesion: 0.19
Nodes (8): main(), normalize_user_params(), Map user CLI params to the same vocabulary as pipeline metadata., Lowercase, strip punctuation, split into tokens. `/` is intentionally NOT in…, tokenize(), The tokenizer keeps compound hyphenated tokens (config-file-path) intact but…, TestNormalizeUserParams, TestTokenizer

### Community 243 - "validate_memory_format"
Cohesion: 0.20
Nodes (6): Detect memory format mismatches — e.g. nvjpegdec (system memory) feeding…, validate_memory_format(), Test memory format mismatch detection between elements., Test that NVMM checks cover encoders too., TestExpandedNVMMChecks, TestMemoryFormatValidation

### Community 244 - "_anatomy.py"
Cohesion: 0.23
Nodes (13): classes_by_region(), _edit_distance(), load_label_dict(), Path, Read the upstream's label_dict.json. Drops the `dummy*` placeholder entries…, Return the region grouping for a class name, or None if it has no canonical…, Group `label_dict` entries by region. Classes with no canonical region land…, Tiny Levenshtein-ish suggestion for typos. No external deps. (+5 more)

### Community 246 - "main"
Cohesion: 0.27
Nodes (14): _find_output_mask(), _geometry_summary(), _input_summary(), main(), _mask_summary(), _public_path(), Path, SpatialImage (+6 more)

### Community 247 - "content_agent_material_cleanup.py"
Cohesion: 0.41
Nodes (14): _asset_path_record(), _base_info(), _bound_material_paths(), _cleanup_external(), cleanup_material_output(), _cleanup_with_pxr(), _invalid_shader_records(), _invalid_source_asset_reason() (+6 more)

### Community 248 - "content-agents/scripts/run.py"
Cohesion: 0.35
Nodes (14): _child_output_path(), emit(), _empty_report(), _finalize(), _load_json(), main(), Any, Namespace (+6 more)

### Community 249 - "urdf-usd-converter/scripts/run.py"
Cohesion: 0.31
Nodes (10): ConversionReport, discover_generated_files(), emit_probe(), emit_report(), main(), probe_source(), Any, Path (+2 more)

### Community 250 - "properties"
Cohesion: 0.13
Nodes (15): type, type, description, type, type, instance_count, material_count, payload_count (+7 more)

### Community 251 - "prepare_cosmos3_vlm_checkpoint.py"
Cohesion: 0.37
Nodes (14): conversion_command(), converted_checkpoint_status(), docker_checkpoint_mount(), docker_env_args(), ensure_cosmos_framework(), expand_path(), main(), parse_args() (+6 more)

### Community 252 - "Train a sentence-transformers Model"
Cohesion: 0.19
Nodes (15): Base Model Selection, Dataset Formats, Evaluators (Cross-Encoder), Evaluators (Bi-Encoder), Evaluators (Sparse Encoder), Hardware Guide, Hugging Face Jobs Execution, Cross-Encoder Losses (+7 more)

### Community 253 - "tao-run-automl"
Cohesion: 0.15
Nodes (14): AutoMLRunner, depth_net CLI, segformer-deploy, TAO AutoML Advanced Monitoring, TAO AutoML Example Conversations, TAO AutoML Intent And Algorithms, depth_net CLI, FoundationStereo (+6 more)

### Community 254 - "NVIDIA-Medtech/NV-Generate-CTMR"
Cohesion: 0.15
Nodes (14): ct_segmentation_finetune_quality_v1, ct_segmentation_quality_v1, ct_synthesis_quality_v1, mr_synthesis_quality_v1, nv-generate-ct-rflow, nv-generate-mr, nv-generate-mr-brain, nv-generate-mr-brain-finetune (+6 more)

### Community 255 - "author_grasp_line.py"
Cohesion: 0.26
Nodes (13): Prim, author_curve(), copy_sidecar(), main(), make_extent(), next_grasp_name(), parse_point(), Any (+5 more)

### Community 256 - "matmul"
Cohesion: 0.20
Nodes (13): SimpleNamespace, benchmark_matmul(), matmul(), _matmul_autotune_configs(), matmul_kernel(), Constant, kernel, Tensor (+5 more)

### Community 257 - "validate_pipeline.py"
Cohesion: 0.20
Nodes (10): check_element_exists(), main(), Check if a GStreamer element is registered using gst-inspect-1.0., Validate all elements exist and properties are recognized., Use gst-launch-1.0 for a dry-run parse check by substituting fakesrc/fakesink…, validate_elements(), validate_with_gst_launch(), Dry-run is skipped for multi-stream pipelines with named pad refs. (+2 more)

### Community 258 - "extract_elements_and_properties"
Cohesion: 0.22
Nodes (5): extract_elements_and_properties(), Parse a gst-launch-1.0 pipeline string and extract elements with properties.…, Regression: a run of leading flags such as '-e -v' must be stripped together.…, Regression: the live-parse source/sink replacement must not match the element…, TestElementParser

### Community 259 - "generate-benchmark-charts.py"
Cohesion: 0.25
Nodes (13): chart_ds_streams_vs_fps(), chart_efficiency(), chart_trt_vs_ds(), chart_trtexec_bs1_vs_bsmax(), chart_trtexec_throughput(), main(), Single bar: GPU-only imgs/sec at MAX_BS with PEAK_GPU_STREAMS annotation., Line chart: X=stream count, Y=fps/stream. Red dashed line at 30fps. (+5 more)

### Community 260 - "check_role.py"
Cohesion: 0.26
Nodes (13): aws_bin(), get_role(), log(), main(), CompletedProcess, Resolve the `aws` executable, honoring PATHEXT (finds aws.exe/aws.cmd on…, Run an aws CLI command, capturing output. Never raises on nonzero exit., Return the Role dict from `aws iam get-role`, or None if it can't be read. (+5 more)

### Community 261 - "jetson-customize-pinmux"
Cohesion: 0.38
Nodes (14): jetson-build-source, jetson-customize-mgbe, jetson-customize-pcie, jetson-customize-pinmux, jetson-customize-uphy, jetson-customize-usb, jetson-derive-carrier, jetson-flash-image (+6 more)

### Community 262 - "render_card"
Cohesion: 0.27
Nodes (13): _categorical_palette(), _emit_card_fallback(), _esc(), _fmt(), Any, Path, 132-class palette built from matplotlib qualitative colormaps so adjacent label…, Drop a minimal summary.html that records the reason rendering failed. (+5 more)

### Community 263 - "render_preview.py"
Cohesion: 0.32
Nodes (13): build_context(), _eval_condition(), _find_endfor(), _find_if_parts(), main(), Any, _render_block(), render_template() (+5 more)

### Community 264 - "concepts"
Cohesion: 0.22
Nodes (9): items, minItems, type, items, minItems, type, $ref, concepts (+1 more)

### Community 265 - "cluster-azure/scripts/preflight.sh"
Cohesion: 0.35
Nodes (11): check_az_auth(), check_deploy_tfvars(), check_min_version(), fail(), finish(), ok(), require_cmds(), require_file() (+3 more)

### Community 266 - "cluster-microk8s/scripts/preflight.sh"
Cohesion: 0.37
Nodes (13): check_disk_gb(), check_driver(), check_min_version(), check_port_listener(), check_ports_free(), fail(), finish(), microk8s_is_running() (+5 more)

### Community 267 - "pre_submit_guard.py"
Cohesion: 0.34
Nodes (13): _check_object_url_non_empty(), _collect_cache_input_urls(), _collect_localpaths(), _collect_setup_input_urls(), _emit_cache_default_action(), _find_setup_task(), _invalid_video_name_values(), _is_aug_task() (+5 more)

### Community 268 - "ml-plugin-app.py"
Cohesion: 0.20
Nodes (10): Detector, fetch_snapshot(), iter_image_dir(), main(), ndarray, Sage/Waggle ML Vision Plugin Template Updated pattern from yolo-object-counter…, Load your ML model here., Run inference on a numpy image (H, W, C) BGR. Returns dict of {class_name:… (+2 more)

### Community 269 - "dataset"
Cohesion: 0.19
Nodes (14): batch_size, pin_memory, workers, popular, batch_size, gpu_id, gpu_ids, num_gpus (+6 more)

### Community 270 - "train"
Cohesion: 0.14
Nodes (14): optim, train, checkpoint_interval, clip_grad_norm, gpu_ids, layerwise_decay, num_epochs, num_gpus (+6 more)

### Community 271 - "inference"
Cohesion: 0.14
Nodes (14): box_thresh, max_candidates, thresh, unclip_ratio, post_processing, gpu_ids, height, num_gpus (+6 more)

### Community 272 - "03_softmax/cutile_python.py"
Cohesion: 0.29
Nodes (13): main(), online_softmax_kernel_tma(), Constant, kernel, TMA single-tile strategy (TILE_SIZE >= N)., Online 2-pass strategy (one block per row)., Chunked 3-pass strategy (persistent scheduling)., _ref_softmax() (+5 more)

### Community 273 - "02_softmax/triton_kernel.py"
Cohesion: 0.19
Nodes (13): benchmark_softmax(), constexpr, jit, Tensor, Host wrapper for Triton softmax. Applies softmax along the last dimension (row-…, Test function to verify correctness., Benchmark Triton vs PyTorch softmax., Triton kernel for row-wise softmax. Each program processes one row using the… (+5 more)

### Community 274 - "matmul"
Cohesion: 0.21
Nodes (13): matmul(), matmul_fp16(), matmul_kernel(), Constant, kernel, Tensor, Host wrapper for cuTile matrix multiplication. Args: a: Input tensor [M, K] b:…, FP16 matrix multiplication optimized for tensor cores. Args: a: Input tensor… (+5 more)

### Community 275 - "05_attention/triton_kernel.py"
Cohesion: 0.20
Nodes (13): flash_attention_backward(), flash_attention_backward_kernel(), flash_attention_forward(), flash_attention_forward_kernel(), constexpr, jit, Tensor, Flash Attention backward pass. Key insight: Recompute attention weights on-the-… (+5 more)

### Community 276 - "03_rope_inplace_splitbuffer/fixed_launch.py"
Cohesion: 0.22
Nodes (13): benchmark_rope(), precompute_freqs(), Constant, kernel, Tensor, Apply RoPE in-place to Q. Q is modified directly. Args: Q: (seq_len, num_heads,…, Reference RoPE using PyTorch ops (returns new tensor, not in-place)., In-place RoPE: one block handles one (token, head) pair. Persistent loop over… (+5 more)

### Community 277 - "group_norm_kernel"
Cohesion: 0.15
Nodes (11): cutile_groupnorm(), group_norm_kernel(), GroupNorm, Constant, kernel, pytorch_reference(), Compute group normalization using PyTorch's built-in module., Initialize PyTorch GroupNorm wrapper. (+3 more)

### Community 278 - "vss-manage-video-io-storage"
Cohesion: 0.18
Nodes (14): vss-generate-video-report, Mode A: Video Clip Report, Mode B: Incident Range Report, vss-manage-alerts, Alert Notify, CV Verifier Prompts, vss-manage-video-io-storage, NvStreamer API (+6 more)

### Community 279 - "main"
Cohesion: 0.24
Nodes (12): DatasetDict, autocast_ctx(), build_evaluator(), load_parallel_data(), log_trackio_dashboard(), main(), Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., Load (en, target_lang) parallel pairs for each target language as a DatasetDict. (+4 more)

### Community 280 - "_make_dataset"
Cohesion: 0.21
Nodes (11): FileDataset, generate(), Path, main(), _make_dataset(), _make_volume(), ndarray, Path (+3 more)

### Community 281 - "automl_disabled_parameters"
Cohesion: 0.15
Nodes (13): aicity, aicity.anchor_init_config, aicity.class_config, aicity.class_config.ATTRIBUTE_DICT, aicity.class_config.CLASS_LIST, aicity.class_config.CLASS_RANGE_DICT, aicity.class_config.MAP_CLASS_NAMES, aicity.class_config.SUB_CLASS_DICT (+5 more)

### Community 282 - "properties"
Cohesion: 0.07
Nodes (31): description, type, properties, type, description, description, type, properties (+23 more)

### Community 283 - "required"
Cohesion: 0.20
Nodes (10): backing_op, canonical_name, cost_class, gpu_bound, implementations, preferred_provider, scope_policy, required (+2 more)

### Community 284 - "enum"
Cohesion: 0.15
Nodes (13): conformance_audit, opportunity_detector, performance_tuning, regression_evidence, safety_gate, target_scoping, enum, role (+5 more)

### Community 285 - "composition"
Cohesion: 0.15
Nodes (13): counting_method, layers, usedLayers, variants, required, payloads, references, additionalProperties (+5 more)

### Community 286 - "dataset.augmentation.aug_prob"
Cohesion: 0.46
Nodes (13): dataset.augmentation.aug_prob, dataset.augmentation.blur_prob, dataset.augmentation.reverse_color_prob, dataset.augmentation.rotate_prob, automl_default_parameters, automl_default_parameters, automl_default_parameters, automl_default_parameters (+5 more)

### Community 287 - "automl_default_parameters"
Cohesion: 0.51
Nodes (13): dataset.augmentation_config.augment, dataset.augmentation_config.random_color.color_probability, dataset.augmentation_config.random_flip, dataset.augmentation_config.random_flip.hflip_probability, dataset.augmentation_config.random_rotate.enable, dataset.augmentation_config.random_rotate.rotate_probability, dataset.fpratio_sampling, model.margin (+5 more)

### Community 288 - "validate_syntax"
Cohesion: 0.26
Nodes (4): Check for common syntax errors., validate_syntax(), Regression: the underscore-typo check must scope to the segment that owns…, TestSyntaxValidation

### Community 289 - "SAMSegmentationDataset"
Cohesion: 0.21
Nodes (8): collate_fn(), compute_loss(), DataTrainingArguments, main(), ModelArguments, Dataset, Wraps a HF dataset into the format expected by SAM/SAM2 processors. Each sample…, SAMSegmentationDataset

### Community 290 - "jetson-customize-pinmux"
Cohesion: 0.31
Nodes (13): jetson-build-source, jetson-customize-clocks, jetson-customize-fan, jetson-customize-mgbe, jetson-customize-nvpmodel, jetson-customize-pcie, jetson-customize-pinmux, jetson-customize-uphy (+5 more)

### Community 291 - "test_run_mr.py"
Cohesion: 0.26
Nodes (9): ndarray, Path, _save_image(), test_build_command_matches_documented_entrypoint(), test_load_config_override_accepts_flat_and_nested_keys(), test_load_config_override_rejects_unknown_key(), test_stage_config_writes_model_and_environment_overrides(), test_summarize_image_and_aggregate_pass() (+1 more)

### Community 292 - "properties"
Cohesion: 0.15
Nodes (13): $comment, type, minLength, type, properties, minLength, type, category (+5 more)

### Community 293 - "physical-ai-video-data-augmentation/scripts/preflight_credentials.sh"
Cohesion: 0.19
Nodes (5): emit_user_input_required(), probe_nvcr_image_ref(), run_workflow_registry_probe(), preflight_credentials.sh script, usage()

### Community 294 - "validate_training_csv.py"
Cohesion: 0.26
Nodes (12): _build_parser(), _check_label_case(), _check_leakage(), main(), normalize_label(), ArgumentParser, Path, Return a list of human-readable validation errors (empty == valid). Uses stdlib… (+4 more)

### Community 295 - "model"
Cohesion: 0.15
Nodes (13): drop_path_rate, img_size, num_register_tokens, patch_size, disable_masking, enable, bottleneck_dim, hidden_dim (+5 more)

### Community 296 - "learning_rate"
Cohesion: 0.15
Nodes (13): max_decay_steps, val_base, val_final, val_start, warm_up_steps, max_decay_steps, val_base, val_final (+5 more)

### Community 297 - "evaluate"
Cohesion: 0.18
Nodes (13): batch_size, gpu_ids, num_gpus, num_nodes, height, opset_version, popular, width (+5 more)

### Community 298 - "rmsnorm"
Cohesion: 0.23
Nodes (12): benchmark_rmsnorm(), Constant, kernel, Tensor, RMSNorm kernel. Occupancy is supplied at runtime via replace_hints. Steps per…, Occupancy-only search: try 1, 2, 4, 8 CTAs per SM., Host wrapper: RMSNorm with exhaustive_search + cache (occupancy-only search).…, _ref_rmsnorm() (+4 more)

### Community 299 - "rmsnorm"
Cohesion: 0.22
Nodes (12): benchmark_rmsnorm(), Constant, kernel, Tensor, Reference implementation using PyTorch ops., Simple timing benchmark., RMSNorm kernel. Each block handles one or more rows (persistent loop). For each…, Host wrapper: RMSNorm with a fixed occupancy=4 ct.launch. Args: x: Input tensor… (+4 more)

### Community 300 - "03_rope_inplace_splitbuffer/autotuned_launch.py"
Cohesion: 0.26
Nodes (12): benchmark_rope(), precompute_freqs(), Constant, kernel, Tensor, Apply RoPE in-place to Q using exhaustive_search + cache with split-buffer. On…, RoPE kernel: reads from Q_in, writes to Q_out. Decoupling Q_in and Q_out is the…, _ref_rope() (+4 more)

### Community 301 - "split_k_gemm.py"
Cohesion: 0.21
Nodes (12): _adjust_group_size(), launch_split_gemm(), main(), Constant, kernel, Compute reference matrix multiplication using torch.matmul., Run split-K GEMM and verify correctness against torch reference., Adjust GROUP_SIZE_M to evenly divide num_tiles_m. (+4 more)

### Community 302 - "PyTorch Implementation Tracing Workflow"
Cohesion: 0.20
Nodes (12): Analyzer Agent, Composer Agent, Kernel Agent, Main Agent (Orchestrator), Deep Agent Orchestration Overview, Deep Agent Orchestration Workflow, PyTorch Implementation Tracing Workflow, PyTorch Codebase Map (+4 more)

### Community 303 - "Image Classification Training"
Cohesion: 0.20
Nodes (9): Compose, build_transforms(), DataTrainingArguments, main(), ModelArguments, Build torchvision transforms from the image processor's config., main(), build_transforms() (+1 more)

### Community 304 - "Assembly Root Management"
Cohesion: 0.20
Nodes (12): assembly_root, loadable_subasset, new_root, parent_assembly, prototype, shared_layer, enum, type (+4 more)

### Community 305 - "BM25 Retrieval & Scoring"
Cohesion: 0.20
Nodes (6): expand_with_synonyms(), Add domain-specific synonyms to boost recall., Score a single document against query tokens., Compute a multiplier based on structural metadata match., Find top-K most relevant pipelines for a query., TestSynonymExpansion

### Community 306 - "Pipeline Metadata Extraction"
Cohesion: 0.29
Nodes (3): extract_pipeline_metadata(), Extract structural metadata from a pipeline string for filtering., TestPipelineMetadata

### Community 307 - "Pipeline Structure Validation"
Cohesion: 0.29
Nodes (3): Check source/sink presence, required props, and named-pad consistency., validate_pipeline_structure(), TestStructureValidation

### Community 308 - "Datasource Testing"
Cohesion: 0.30
Nodes (11): parametrize, test_source_available(), test_source_cache(), test_source_call_mock(), test_source_call_mock_dataframe(), test_source_exceptions(), test_source_fetch(), test_source_validate_time() (+3 more)

### Community 309 - "main"
Cohesion: 0.32
Nodes (11): build_exact_match_spec(), load_jsonl_rows(), main(), Any, Path, Write rows as JSONL and return the written path., Load plain JSONL or .gz JSONL rows., Build a local exact-match spec that does not require model credentials. (+3 more)

### Community 310 - "filename_fast_path.py"
Cohesion: 0.27
Nodes (11): extract_pages(), find_matches(), main(), page_records(), page_text(), rank_pages(), Query-turn filename fast path for the nemo-retriever skill. Reads `./pdfs/`…, Return list of (score, page_number, doc_stem, text) sorted by descending score,… (+3 more)

### Community 311 - "test_run_mr_brain.py"
Cohesion: 0.29
Nodes (9): ndarray, Path, _save_image(), test_build_command_matches_documented_entrypoint(), test_load_config_override_accepts_flat_and_nested_keys(), test_load_config_override_rejects_unknown_key(), test_stage_config_writes_model_and_environment_overrides(), test_summarize_image_and_aggregate_pass() (+1 more)

### Community 312 - "changenet_data_pair_prepare.py"
Cohesion: 0.27
Nodes (11): convert_to_jpg(), generate_csv(), generate_csv_siamese(), main(), normalize_label(), parse_label_from_filename(), NV_PCB_Siamese 14-column CSV mode. Copies SDG images into images_dir with the…, Extract label from filename pattern like 'PCB+bridge_00000.png'. (+3 more)

### Community 313 - "evaluate"
Cohesion: 0.17
Nodes (11): actions, evaluate, automl_enabled, core_module, path, schema_action, spec_template, failures (+3 more)

### Community 314 - "train"
Cohesion: 0.17
Nodes (12): lr_backbone, lr_linear_proj_mult, momentum, weight_decay, train, checkpoint_interval, gpu_ids, num_epochs (+4 more)

### Community 315 - "evaluate"
Cohesion: 0.17
Nodes (11): actions, evaluate, automl_enabled, core_module, path, schema_action, spec_template, failures (+3 more)

### Community 316 - "evaluate"
Cohesion: 0.17
Nodes (11): actions, evaluate, automl_enabled, core_module, path, schema_action, spec_template, failures (+3 more)

### Community 317 - "train"
Cohesion: 0.17
Nodes (12): lr_backbone, lr_linear_proj_mult, momentum, weight_decay, train, checkpoint_interval, gpu_ids, num_epochs (+4 more)

### Community 318 - "export"
Cohesion: 0.17
Nodes (11): actions, export, automl_enabled, core_module, path, schema_action, spec_template, failures (+3 more)

### Community 319 - "gen_trt_engine"
Cohesion: 0.17
Nodes (12): cal_batch_size, cal_batches, batch_size, gpu_id, height, tensorrt, width, gen_trt_engine (+4 more)

### Community 320 - "actions"
Cohesion: 0.17
Nodes (11): actions, train, automl_enabled, failures, model, network_arch, schema_version, core_module (+3 more)

### Community 321 - "inference"
Cohesion: 0.26
Nodes (12): popular, gpu_id, gpu_ids, num_gpus, num_nodes, popular, gen_trt_engine, inference (+4 more)

### Community 322 - "matmul"
Cohesion: 0.23
Nodes (11): benchmark_matmul(), matmul(), matmul_kernel(), Constant, kernel, Tensor, Block-swizzle for L2 cache locality (L2 reuse across tiles)., Tiled GEMM: C = A @ B. Each block computes one (TILE_M, TILE_N) output tile by… (+3 more)

### Community 323 - "Clinical ASR Build"
Cohesion: 0.20
Nodes (11): Two-tier IPA Pipeline, Keyword Error Rate (KER), NeMo Data Designer, Data Designer, Clinical ASR Build, Clinical ASR Eval, Clinical ASR Finetune, Clinical ASR Setup (+3 more)

### Community 324 - "fmha_kernel"
Cohesion: 0.22
Nodes (10): ConstBool, ConstInt, fmha_forward(), fmha_kernel(), kernel, Tensor, Host wrapper for FMHA forward pass. Args: q: Query tensor [batch, num_heads,…, Test FMHA against PyTorch reference. (+2 more)

### Community 325 - "Riva NIM Setup"
Cohesion: 0.24
Nodes (11): nvidia-riva-client, riva-build, riva-deploy, Riva ASR NIM, Riva ASR Custom Model Deployment, Riva NIM Deployment Readiness Checks, Riva Model Selection & Routing, Riva NMT NIM (+3 more)

### Community 326 - "sage-bioclip2"
Cohesion: 0.18
Nodes (11): save_match.py, consumer.py, crop_writer.py, image-sampler2, node_info.py, sage-bioclip2, sage-yolo2, save_match.py (+3 more)

### Community 327 - "blocks_scaling.py"
Cohesion: 0.33
Nodes (10): convergence_every_iteration(), fortran_order_reshape(), item_in_hot_loop(), iterate_array(), object_dtype(), per_element_loop(), ndarray, python_min_max() (+2 more)

### Community 329 - "main"
Cohesion: 0.33
Nodes (10): dicom-series-to-volume, _affine_from_dicom(), main(), _missing_required_tags(), _public_path(), Dataset, ndarray, Path (+2 more)

### Community 330 - "TRL Training on Hugging Face Jobs"
Cohesion: 0.18
Nodes (11): GGUF Conversion Guide, Hardware Selection Guide, Saving Training Results to Hugging Face Hub, Local Training on macOS, Reliability Principles for Training Jobs, Trackio Integration for TRL Training, TRL Training Methods Overview, Common Training Patterns (+3 more)

### Community 331 - "test_run_mr_brain_finetune.py"
Cohesion: 0.47
Nodes (10): _args(), _fake_upstream(), Namespace, Path, test_custom_model_config_override_is_used(), test_preflight_payload_succeeds_without_upstream(), test_stage_configs_targets_existing_upstream_scripts(), test_validate_datalist_accepts_relative_images_and_default_modality() (+2 more)

### Community 332 - "apply_metadata"
Cohesion: 0.44
Nodes (10): apply_metadata(), _build_metadata(), _custom_layer_metadata(), emit(), _load_extra_metadata(), main(), Any, Namespace (+2 more)

### Community 333 - "required"
Cohesion: 0.10
Nodes (27): affine, axcodes, ground_truth_path, label_map_loaded, label_map_source, ndim, path, shape (+19 more)

### Community 334 - "properties"
Cohesion: 0.18
Nodes (11): type, type, properties, type, auditReport, converter, inputs, targetBottleneck (+3 more)

### Community 335 - "Physical AI Defect Image Generation"
Cohesion: 0.18
Nodes (11): Physical AI Defect Image Generation, anomaly-infer, augment-image-edit, finetune, Qwen Image Edit NVPCB OVSL2SL, usd2roi-render, Physical AI Infrastructure Setup and Resilient Scaling, Azure AKS (+3 more)

### Community 336 - "Azure Provider Registration"
Cohesion: 0.31
Nodes (8): move_cursor_to_first_line(), print_not_registered_state(), print_provider_name(), print_registered_state(), print_state(), register-azure-providers.sh script, test_cli_install(), usage()

### Community 337 - "Azure Inference Preflight"
Cohesion: 0.45
Nodes (9): check_az_auth(), check_min_version(), fail(), finish(), ok(), require_cmds(), preflight.sh script, version_ge() (+1 more)

### Community 338 - "NIM Operator Preflight"
Cohesion: 0.44
Nodes (9): check_min_version(), fail(), finish(), load_env(), ok(), require_cmds(), preflight.sh script, version_ge() (+1 more)

### Community 339 - "Osmo Azure Preflight"
Cohesion: 0.45
Nodes (9): check_az_auth(), check_min_version(), fail(), finish(), ok(), require_cmds(), preflight.sh script, version_ge() (+1 more)

### Community 340 - "Osmo Barrier Sync"
Cohesion: 0.33
Nodes (3): main(), run_client(), SyncServer

### Community 341 - "Training Hyperparameters"
Cohesion: 0.18
Nodes (11): backbone_multiplier, momentum, weight_decay, train, checkpoint_interval, gpu_ids, num_epochs, num_gpus (+3 more)

### Community 342 - "TensorRT Calibration"
Cohesion: 0.18
Nodes (11): cal_batch_size, cal_batches, batch_size, gpu_id, tensorrt, gen_trt_engine, calibration, max_batch_size (+3 more)

### Community 343 - "Model Export Schema"
Cohesion: 0.18
Nodes (11): actions, export, inference, core_module, path, schema_action, spec_template, core_module (+3 more)

### Community 344 - "4D Tensor Matmul"
Cohesion: 0.18
Nodes (10): _adjust_group_size(), matmul_kernel(), Constant, kernel, Compute reference matrix multiplication using torch.matmul., Heuristic tile config selection., Adjust GROUP_SIZE_M to evenly divide num_tiles_m., Compute matrix multiplication over 4D tensors using tiled MMA. (+2 more)

### Community 345 - "Sentence Transformer Training"
Cohesion: 0.25
Nodes (10): autocast_ctx(), load_pair_dataset(), log_trackio_dashboard(), main(), Dataset, Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., Load a contrastive-pair dataset for training. StaticEmbedding starts from…, bf16/fp16 autocast for evaluator calls outside the trainer. (+2 more)

### Community 346 - "Slack Notification System"
Cohesion: 0.25
Nodes (5): NotifierResult, Outcome of a single backend delivery attempt., Any, Posts incident notifications to a Slack channel via the Slack Web API., SlackNotifier

### Community 347 - "MoE Implementation Patterns"
Cohesion: 0.20
Nodes (10): StateDictAdapter, MoEConfig, GroupedExperts, MoEFSDPSyncMixin, MLP Layer, MoE Layer, MoESplitExpertsStateDictMixin, MoE Implementation Patterns (+2 more)

### Community 348 - "ds_sop_process.py"
Cohesion: 0.27
Nodes (5): FastAPI Endpoints Guide, SOP Process Manager Guide, SOP Checker Guide, SSE Streaming Pattern Guide, Test Suite Coverage Guide

### Community 349 - "test_fetch_api_support.py"
Cohesion: 0.22
Nodes (4): _by_name(), Internal ApiEntry bookkeeping (token strings, docs_url, cupynumeric_name) must…, test_parse_comparison_covers_all_token_formats(), test_render_markdown_drops_redundant_fields()

### Community 350 - "collect_dynamo_debug_bundle.py"
Cohesion: 0.44
Nodes (9): container_names(), kubectl_json(), main(), pod_names(), Any, Path, redact(), run() (+1 more)

### Community 351 - "earth2studio-create-prognostic/references/skeleton-template.py"
Cohesion: 0.20
Nodes (9): # TODO: Store time step as timedelta, # TODO: Set grid dimensions from reference. Keep public, # TODO: Replace with actual checkpoint URL, # NOTE: Only override .to() if there is non-PyTorch state to manage, # TODO: Reshape input tensor for the core model, # TODO: Reshape output back to E2S format, # TODO: Return actual output instead of placeholder, # TODO: Import optional packages here (+1 more)

### Community 352 - "main"
Cohesion: 0.38
Nodes (9): find_base_python(), interpreter_version(), log(), main(), parse_version(), Path, Path to the interpreter inside a venv, per platform., Locate a base interpreter for the requested version for `python -m venv`. (+1 more)

### Community 353 - "Build BSP Source Skill"
Cohesion: 0.20
Nodes (10): Build BSP Source Skill, Per-mode build snippets, Composite Custom-Overlay Registration, Long-Tail Gotchas, Build manifest + watermark schema, Upstream NVIDIA Build Recipe, Customize camera Skill, NVIDIA tegra-capture-vi / tegra-camera-platform binding cheat-sheet (+2 more)

### Community 354 - "config.py"
Cohesion: 0.22
Nodes (8): cpu_offloading, cuda_graph_impl, delay_wgrad_compute, overlap_moe_expert_parallel_comm, expandable_segments, MoE Communication Overlap Skill, TP DP Comm Overlap Skill Card, Resiliency Skill Card

### Community 355 - "properties"
Cohesion: 0.20
Nodes (10): type, type, properties, type, cuda, estimated_cost, preflight, warnings (+2 more)

### Community 356 - "test_run_vae_finetune.py"
Cohesion: 0.49
Nodes (9): _args(), _fake_upstream(), Namespace, Path, test_preflight_payload_reports_skill_entrypoint(), test_stage_configs_writes_absolute_paths_and_training_options(), test_validate_datalist_rejects_missing_validation_split(), test_validate_datalist_requires_training_and_validation_cases() (+1 more)

### Community 357 - "properties"
Cohesion: 0.20
Nodes (10): minLength, type, minLength, type, properties, op, param, question (+2 more)

### Community 358 - "Osmo K8s Preflight"
Cohesion: 0.44
Nodes (8): check_min_version(), fail(), finish(), ok(), require_cmds(), preflight.sh script, version_ge(), warn()

### Community 359 - "DEFT State Initialization"
Cohesion: 0.29
Nodes (9): _build_parser(), build_state(), main(), ArgumentParser, Namespace, Path, Return a resolved image URI from versions.yaml at the given key path. Looks at…, _resolve_image_from_versions_yaml() (+1 more)

### Community 360 - "Inference Spec Preparation"
Cohesion: 0.29
Nodes (9): _build_inference_spec(), main(), _pick_best(), prepare(), Any, Path, Write best_model.json and best_model_inference_spec.yaml. Returns a dict…, Return (iteration_label, iteration_dict) with the lowest far_pct. (+1 more)

### Community 361 - "evaluate"
Cohesion: 0.22
Nodes (10): gpu_ids, num_gpus, num_nodes, gpu_ids, num_gpus, num_nodes, popular, evaluate (+2 more)

### Community 362 - "gen_trt_engine"
Cohesion: 0.20
Nodes (10): cal_batch_size, cal_batches, batch_size, gpu_id, tensorrt, gen_trt_engine, calibration, max_batch_size (+2 more)

### Community 363 - "export"
Cohesion: 0.20
Nodes (10): export, core_module, path, popular, schema_action, spec_template, gpu_ids, num_gpus (+2 more)

### Community 364 - "inference"
Cohesion: 0.20
Nodes (10): inference, gpu_ids, num_gpus, num_nodes, core_module, path, popular, schema_action (+2 more)

### Community 365 - "model"
Cohesion: 0.20
Nodes (10): backbone, bbox_loss_coef, cls_loss_coef, giou_loss_coef, num_queries, num_select, set_cost_bbox, set_cost_class (+2 more)

### Community 366 - "inference"
Cohesion: 0.20
Nodes (10): inference, gpu_ids, num_gpus, num_nodes, core_module, path, popular, schema_action (+2 more)

### Community 367 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 368 - "export"
Cohesion: 0.20
Nodes (10): export, core_module, path, popular, schema_action, spec_template, gpu_ids, num_gpus (+2 more)

### Community 369 - "inference"
Cohesion: 0.20
Nodes (10): inference, gpu_ids, num_gpus, num_nodes, core_module, path, popular, schema_action (+2 more)

### Community 370 - "model"
Cohesion: 0.20
Nodes (10): backbone, bbox_loss_coef, cls_loss_coef, giou_loss_coef, num_queries, num_select, set_cost_bbox, set_cost_class (+2 more)

### Community 371 - "train"
Cohesion: 0.20
Nodes (10): lr, args, train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes (+2 more)

### Community 372 - "prune"
Cohesion: 0.33
Nodes (6): prune, core_module, path, popular, schema_action, spec_template

### Community 373 - "quantize"
Cohesion: 0.33
Nodes (6): quantize, core_module, path, popular, schema_action, spec_template

### Community 374 - "evaluate"
Cohesion: 0.22
Nodes (10): gpu_ids, num_gpus, num_nodes, gpu_ids, num_gpus, num_nodes, popular, evaluate (+2 more)

### Community 375 - "vector_add"
Cohesion: 0.24
Nodes (9): Constant, kernel, Tensor, Test function to verify correctness., cuTile kernel for vector addition: C = A + B Translation from Triton: -…, Host wrapper for cuTile vector addition. Args: a: Input tensor A b: Input…, test_vector_add(), vector_add() (+1 more)

### Community 376 - "vector_add"
Cohesion: 0.22
Nodes (9): constexpr, jit, Tensor, Triton kernel for vector addition: C = A + B Translation from CUDA: -…, Host wrapper for Triton vector addition. Equivalent to CUDA launch_vector_add…, Test function to verify correctness., test_vector_add(), vector_add() (+1 more)

### Community 377 - "train_cross_encoder_distillation_example.py"
Cohesion: 0.29
Nodes (9): autocast_ctx(), load_resolved_dataset(), log_trackio_dashboard(), main(), Load (query, positive, negative, score) rows. The MSMARCO subset is keyed by…, bf16/fp16 autocast for evaluator calls outside the trainer (which has its own…, Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam. (+1 more)

### Community 378 - "train_sparse_encoder_distillation_example.py"
Cohesion: 0.29
Nodes (9): autocast_ctx(), load_resolved_dataset(), log_trackio_dashboard(), main(), Load (query, positive, negative, score) rows. The MSMARCO subset is keyed by…, bf16/fp16 autocast for evaluator calls outside the trainer (which has its own…, Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam. (+1 more)

### Community 379 - "apply_config.sh"
Cohesion: 0.22
Nodes (7): CONFIGS, resolve_or_override(), resolve_unique(), RESOURCES, apply_config.sh script, SPARSE4D_REPO, TRITON_REPO

### Community 380 - "hsb-setup"
Cohesion: 0.33
Nodes (9): hololink-demo Container, HSB Lattice Board, Leopard Imaging VB1940, Holoscan Sensor Bridge, HSB Demo Container, hsb-app, hsb-flash, hsb-setup (+1 more)

### Community 381 - "automl_default_parameters"
Cohesion: 0.50
Nodes (9): dataset.test_dataset.batch_size, dataset.test_dataset.num_workers, dataset.train_dataset.batch_size, dataset.train_dataset.num_workers, dataset.val_dataset.batch_size, dataset.val_dataset.num_workers, automl_default_parameters, automl_default_parameters (+1 more)

### Community 382 - "main"
Cohesion: 0.31
Nodes (8): SequentialEvaluator, autocast_ctx(), log_trackio_dashboard(), main(), Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., bf16/fp16 autocast for evaluator calls outside the trainer (which has its own…, Surface the Trackio dashboard URL so the user can watch training live., setup_logging()

### Community 383 - "scales_well.py"
Cohesion: 0.42
Nodes (8): fused_with_out(), jacobi_step(), masked_assign(), matmul_chain(), ndarray, residual(), solve(), vectorized_update()

### Community 384 - "extract"
Cohesion: 0.36
Nodes (8): extract(), main(), _public_path(), Any, Path, Extract metadata from a DICOM file., Extract metadata from a DICOM file. Returns a JSON-serialisable dict., _safe_str()

### Community 385 - "test_basic.py"
Cohesion: 0.44
Nodes (8): fixture_path(), fixture, Path, _run(), test_output_validates_against_schema(), test_phi_flag_true_for_synthetic_phi(), test_required_schema_fields(), test_script_runs_and_returns_json()

### Community 386 - "Hugging Face Spaces"
Cohesion: 0.22
Nodes (9): Hugging Face Spaces, HF Buckets, Spaces Debugging, Gradio for Spaces, Community GPU Grants, Inference Providers, Known Errors, Spaces Requirements (+1 more)

### Community 387 - "Context Packs README"
Cohesion: 0.22
Nodes (9): AutoModel Launcher Context, AutoModel Pretraining Context, AutoModel SFT and PEFT Context, BYOB Benchmark Context, Checkpoint Conversion Context, Context Packs README, Curator Data Acquisition Context, Curator Processing and Quality Context (+1 more)

### Community 388 - "nemotron-customize"
Cohesion: 0.25
Nodes (9): Project scaffold brief, Stage implementation brief, Artifact Compatibility, Nemotron Step Catalog, Run Command Reference, Hardware And Backend Routing, Cross-Step Patterns, Nemotron Customize Workflow (+1 more)

### Community 389 - "_write_nifti"
Cohesion: 0.39
Nodes (8): ndarray, Nifti1Image, Path, test_build_command_uses_documented_monai_bundle_entrypoint(), test_find_output_mask_prefers_upstream_single_image_layout(), test_mask_summary_accepts_known_labels_and_matching_geometry(), test_mask_summary_flags_labels_missing_from_loaded_label_map(), _write_nifti()

### Community 390 - "validator-concepts.schema.json"
Cohesion: 0.18
Nodes (10): additionalProperties, $comment, type, properties, $comment, schema_version, $schema, type (+2 more)

### Community 391 - "inference-nvcf/scripts/preflight.sh"
Cohesion: 0.53
Nodes (8): check_min_version(), fail(), finish(), ok(), require_cmds(), preflight.sh script, version_ge(), warn()

### Community 392 - "osmo-cli/scripts/preflight.sh"
Cohesion: 0.44
Nodes (7): check_min_version(), fail(), finish(), ok(), osmo_client_version(), preflight.sh script, version_ge()

### Community 393 - "physical-ai-people-attribute-search/scripts/preflight_credentials.sh"
Cohesion: 0.31
Nodes (4): emit_user_input_required(), run_workflow_registry_probe(), preflight_credentials.sh script, usage()

### Community 394 - "detr-resnet50-cppe5/train.py"
Cohesion: 0.31
Nodes (8): augment_and_transform_batch(), compute_metrics(), format_image_annotations_as_coco(), main(), make_collate_fn(), no_grad, Format (image_id, categories, areas, bboxes) as a COCO annotation dict for DETR…, Replicate HF repo compute_metrics: post-process + torchmetrics…

### Community 395 - "append_stage"
Cohesion: 0.33
Nodes (8): append_stage(), _build_parser(), main(), next_seq(), ArgumentParser, Path, Append one stage event. Caller is responsible for measuring duration. Raises:…, Return seq for the next entry: last entry's seq + 1, or 1 if no log yet.

### Community 396 - "gen_trt_engine"
Cohesion: 0.25
Nodes (9): popular, batch_size, gpu_id, gpu_ids, num_gpus, num_nodes, popular, gen_trt_engine (+1 more)

### Community 397 - "gen_trt_engine"
Cohesion: 0.22
Nodes (9): cal_batch_size, cal_batches, batch_size, gpu_id, tensorrt, gen_trt_engine, calibration, min_batch_size (+1 more)

### Community 398 - "Classify Task"
Cohesion: 0.22
Nodes (9): Classify Task, Evaluate Action, Inference Action, Segment Task, Segment Evaluate Action, Segment Inference Action, Segment Train Action, Train Action (+1 more)

### Community 399 - "gen_trt_engine"
Cohesion: 0.22
Nodes (9): cal_batch_size, cal_batches, batch_size, gpu_id, tensorrt, gen_trt_engine, calibration, min_batch_size (+1 more)

### Community 400 - "01_add/cutile_python.py"
Cohesion: 0.42
Nodes (8): add_kernel(), add_scalar_kernel(), main(), Constant, kernel, run_add(), run_add_scalar(), verify()

### Community 401 - "cuTile to Triton Conversion Skill"
Cohesion: 0.25
Nodes (9): API Mapping (cuTile to Triton), Triton Runtime Error Debugging, Testing & Validation Harness, Optimization Strategy Hub, Triton Optimization Reference, Performance Gotchas (10-50x Regression), cuTile to Triton Conversion Skill, Advanced Triton Patterns (+1 more)

### Community 402 - "3D Average Pooling"
Cohesion: 0.22
Nodes (8): avgpool3d_kernel(), next_power_of_2(), Constant, kernel, pytorch_reference(), Return the smallest power of 2 >= x., Compute 3D average pooling over each output element using gather-based window…, Compute 3D average pooling using PyTorch's built-in function.

### Community 403 - "3D Max Pooling"
Cohesion: 0.22
Nodes (8): maxpool3d_kernel(), next_power_of_2(), Constant, kernel, pytorch_reference(), Return the smallest power of 2 >= x., Compute 3D max pooling with dilation using gather-based window access., Compute 3D max pooling using PyTorch's built-in function.

### Community 404 - "Cumulative Sum Kernel"
Cohesion: 0.25
Nodes (8): kernel_cumsum(), Constant, kernel, Compute cumulative sum along axis 1 for each batch tile., Launch the cumulative sum kernel and return the output., Compute cumulative sum along dim 1 using PyTorch., test_cumsum(), torch_reference()

### Community 405 - "Image Generation Pipeline"
Cohesion: 0.25
Nodes (8): crop_components.py, sdg_pipeline.py, Good-Image Generation Flow, Structural-Defect Generation Flow, Texture Defect Generation Day 0 Flow, NIM Operator Inference, Qwen Image Edit NVPCB OVSL2SL NIMService, usd2roi_crop.py

### Community 406 - "cuPyNumeric Migration Readiness Skill"
Cohesion: 0.25
Nodes (8): cuPyNumeric, Legate, cuPyNumeric Install Skill, cuPyNumeric Migration Readiness Skill, Decision Framework, Legate Execution Model, Idioms That Block Scaling, cuPyNumeric Parallel Data Load Skill

### Community 407 - "Mask2Former Deploy Skill"
Cohesion: 0.29
Nodes (8): Generate TensorRT Engine, Inference, Mask2Former Deploy Skill, Metric Learning Recognition Deploy Skill, NVDINOv2 Deploy Skill, Mask2Former Training Skill, Metric Learning Recognition Training Skill, NVDINOv2 Training Skill

### Community 408 - "PAS E2E Workflow"
Cohesion: 0.25
Nodes (8): Qwen2.5-14B HF Download Job, Qwen2.5-14B NIMService, Qwen2.5-14B PVC, Qwen3-VL HF Download Job, Qwen3-VL NIMService, Qwen3-VL PVC, Qwen Image Edit NIMService, PAS E2E Workflow

### Community 409 - "implementation"
Cohesion: 0.25
Nodes (8): class_name, module, provider, use_for, implementation, additionalProperties, required, type

### Community 410 - "lint_data.py"
Cohesion: 0.36
Nodes (7): find_issues(), fix_row(), main(), normalize_pipeline(), Apply automatic fixes to a pipeline. Returns (prompt, fixed_pipeline) or None…, Normalize whitespace and line continuations for comparison., Return list of (row_index_0based, issue_type, message) tuples.

### Community 411 - "validate_platform_sink"
Cohesion: 0.36
Nodes (4): Detect platform-sink mismatches: - nveglglessink used alongside nv3dsink hints…, validate_platform_sink(), Test platform-sink mismatch detection., TestPlatformSinkValidation

### Community 412 - "validate_element_ordering"
Cohesion: 0.36
Nodes (4): Detect nonsensical element ordering — e.g. an encoder appearing before a…, validate_element_ordering(), Test element ordering checks., TestElementOrderingValidation

### Community 414 - "invoke_endpoint.py"
Cohesion: 0.50
Nodes (7): aws_bin(), load_payload(), log(), main(), Namespace, Return the raw payload text, BOM stripped. Validates JSON when applicable., resolve_region()

### Community 415 - "teardown.py"
Cohesion: 0.46
Nodes (7): aws_bin(), log(), main(), CompletedProcess, Region from arg, then env, then the active profile's config., resolve_region(), run_aws()

### Community 416 - "inspect_vllm_uv.py"
Cohesion: 0.39
Nodes (7): main(), Run inspect-ai evaluation with HuggingFace Transformers backend. Use this when…, Configure environment variables for HuggingFace authentication., Run inspect-ai evaluation with vLLM backend. Args: model_id: HuggingFace model…, run_inspect_hf(), run_inspect_vllm(), setup_environment()

### Community 417 - "lighteval_vllm_uv.py"
Cohesion: 0.39
Nodes (7): main(), Run lighteval with accelerate backend for multi-GPU distributed inference. Use…, Configure environment variables for HuggingFace authentication., Run lighteval with vLLM backend for efficient GPU inference. Args: model_id:…, run_lighteval_accelerate(), run_lighteval_vllm(), setup_environment()

### Community 418 - "Gradio LoRA Space Builder Skill"
Cohesion: 0.32
Nodes (8): Adapting the Demo to the Specific LoRA, Krea 2 Reference, LTX Reference, Qwen-Image Reference, Creative Mode: Custom HTML/JS UIs, Tasks: Per-Task Baseline UI Patterns, ZeroGPU and Publishing Guide, Gradio LoRA Space Builder Skill

### Community 419 - "Trackio"
Cohesion: 0.25
Nodes (8): Trackio, Trackio Alerts, Trackio Logging, Trackio Retrieval, HF Vision Trainer, Image Classification Training, Hub Saving for Vision, SAM2 Fine-tuning

### Community 420 - "jetson-init-source"
Cohesion: 0.39
Nodes (8): jetson-download-bsp, jetson-generate-kb, jetson-init-image, jetson-init-source, jetson-init-target, jetson-link-docs, jetson-quick-start, jetson-set-target

### Community 421 - "nemo-data-designer-plugin Skill"
Cohesion: 0.29
Nodes (8): Autopilot Workflow, nemo-data-designer-plugin Benchmark, Interactive Workflow, NeMo Plugin Additions, Person Sampling Reference, Preview Review Guide, Seed Datasets Reference, nemo-data-designer-plugin Skill

### Community 422 - "main.py"
Cohesion: 0.43
Nodes (7): any_match(), classify(), main(), parse_args(), Namespace, Route, score_route()

### Community 423 - "Omniverse Realtime Viewer"
Cohesion: 0.25
Nodes (8): Omniverse Realtime Viewer, ov-web-rtc client, ovrtx, ovstream, ovui, Camera Controls, Omniverse Realtime Viewer Conventions, Omniverse Realtime Viewer Routing

### Community 424 - "mask_former"
Cohesion: 0.25
Nodes (8): class_weight, dice_weight, hidden_dim, importance_sample_ratio, mask_weight, nheads, num_object_queries, mask_former

### Community 425 - "mask_former"
Cohesion: 0.25
Nodes (8): class_weight, dice_weight, hidden_dim, importance_sample_ratio, mask_weight, nheads, num_object_queries, mask_former

### Community 426 - "Integrate and create cuTile kernels into 🤗 Transformers"
Cohesion: 0.46
Nodes (8): Evaluation Report, Auto Kernelize, Environment Setup, Kernel Integration, Transformer Kernel Inventory Schema, Kernel Integration Workflow Diagram, Integrate and create cuTile kernels into 🤗 Transformers, Skill Card

### Community 427 - "main"
Cohesion: 0.36
Nodes (7): autocast_ctx(), log_trackio_dashboard(), main(), bf16/fp16 autocast for evaluator calls outside the trainer (which has its own…, Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., setup_logging()

### Community 428 - "main"
Cohesion: 0.36
Nodes (7): autocast_ctx(), log_trackio_dashboard(), main(), Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., bf16/fp16 autocast for evaluator calls outside the trainer (which has its own…, setup_logging()

### Community 429 - "main"
Cohesion: 0.36
Nodes (7): autocast_ctx(), log_trackio_dashboard(), main(), Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., bf16/fp16 autocast for evaluator calls outside the trainer (which has its own…, Surface the Trackio dashboard URL so the user can watch training live., setup_logging()

### Community 430 - "main"
Cohesion: 0.36
Nodes (7): autocast_ctx(), log_trackio_dashboard(), main(), bf16/fp16 autocast for evaluator calls outside the trainer (which has its own…, Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., setup_logging()

### Community 431 - "main"
Cohesion: 0.36
Nodes (7): autocast_ctx(), log_trackio_dashboard(), main(), Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., bf16/fp16 autocast for evaluator calls outside the trainer (which has its own…, setup_logging()

### Community 432 - "main"
Cohesion: 0.36
Nodes (7): autocast_ctx(), log_trackio_dashboard(), main(), bf16/fp16 autocast for evaluator calls outside the trainer (which has its own…, Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., setup_logging()

### Community 433 - "train_sparse_encoder_example.py"
Cohesion: 0.36
Nodes (7): autocast_ctx(), log_trackio_dashboard(), main(), bf16/fp16 autocast for evaluator calls outside the trainer (which has its own…, Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., setup_logging()

### Community 434 - "download_anomalygen_checkpoints.sh"
Cohesion: 0.29
Nodes (7): Glass Asset Setup Workflow, Metal Surface Asset Setup Workflow, PCB Asset Setup Workflow, download_anomalygen_checkpoints.sh, prepare_dataset_uc1.py, prepare_dataset_uc2.py, prepare_dataset_uc3.py

### Community 435 - "Kernel Type Templates"
Cohesion: 0.33
Nodes (7): cdiv, replace_hints, Kernel Type Templates, Parameter Space Design, Pitfall Checklist, Step-by-Step Workflow, swizzle_2d

### Community 436 - "NVIDIA DeepStream SDK"
Cohesion: 0.29
Nodes (7): NVIDIA DeepStream SDK, Nsight Systems (nsys), pyservicemaker API, DeepStream Dev Skill, DeepStream Generate Pipeline Skill, DeepStream Import Vision Model Skill, DeepStream Profile Pipeline Skill

### Community 437 - "WES Shared Filesystem and Cache Architecture"
Cohesion: 0.33
Nodes (7): edge-scheduler, WES Node Service DaemonSet Sideload, WES Pod Config and Manifest Exposure, WES Shared Filesystem and Cache Architecture, waggle-edge-stack, wes-local-cache-manager, wes-upload-agent

### Community 438 - "holoscan-setup"
Cohesion: 0.38
Nodes (7): Holoscan SDK, holoscan-install-conda, holoscan-install-container, holoscan-install-debian, holoscan-install-source, holoscan-install-wheel, holoscan-setup

### Community 439 - "Iterative cuTile Kernel Performance Optimization"
Cohesion: 0.29
Nodes (7): cuTile API Reference, IR Analysis Guide, Optimization Playbook, cuTile Patterns Quick-Reference Card, cuTile Performance Knobs Catalog, GPU Performance Model, Iterative cuTile Kernel Performance Optimization

### Community 440 - "$defs"
Cohesion: 0.15
Nodes (13): op, param, question, additionalProperties, type, $defs, concept, parameter_prerequisite (+5 more)

### Community 441 - "run_sample_calibration.py"
Cohesion: 0.38
Nodes (5): _find(), _find_sample_dir(), Path, # NOTE: do NOT write `Path(os.environ.get("SAMPLE_DIR", "")) or…, _read_env_key()

### Community 442 - "mps_solver/model.py"
Cohesion: 0.33
Nodes (6): compare_gaps(), download_air05(), Compare solutions at different MIP gap tolerances. Parameters ----------…, Download air05.mps from MIPLIB if not present., Solve an LP/MILP problem from an MPS file. Parameters ---------- filepath : str…, solve_mps()

### Community 443 - "needs_refactor.py"
Cohesion: 0.48
Nodes (6): alloc_in_loop(), nonzero_then_index(), ndarray, rebind_in_loop(), reshape_in_hot_loop(), stack_in_loop()

### Community 444 - "BufferRetriever"
Cohesion: 0.29
Nodes (7): BufferRetriever, FrameAnalyzer, FrameSaver, FrameStreamer, MultiBatchRetriever, QueuedRetriever, SelectiveFrameCapture

### Community 446 - "SOP Inference Microservice Evaluation Workflow"
Cohesion: 0.33
Nodes (7): SOP Inference Microservice Evaluation Workflow, Verification & curl Examples, Implementation Checklist, Latency Measurement (File Input), Kafka Message Schema Configuration, Camera / Live-Stream Chunk-E2E Latency Measurement, RTSP Streaming Output

### Community 447 - "mirror_image.py"
Cohesion: 0.57
Nodes (6): log(), main(), CompletedProcess, require(), resolve_region(), run()

### Community 448 - "_inspect_evals_tasks_root"
Cohesion: 0.43
Nodes (6): _inspect_evals_tasks_root(), main(), _normalize_task(), Path, Return the installed inspect_evals package path if available., Allow lighteval-style `suite|task|shots` strings by keeping the task name.

### Community 449 - "huggingface-llm-trainer/scripts/estimate_cost.py"
Cohesion: 0.43
Nodes (6): estimate_training_time(), extract_model_size(), main(), parse_args(), Estimate training time in hours., Extract model size from name or return parsed value.

### Community 450 - "HF Paper Publisher Skill"
Cohesion: 0.29
Nodes (7): Paper Publisher Example Usage, Paper Publisher Quick Reference, HF Paper Publisher Skill, arXiv Paper Template, ML Report Template, Modern Paper Template, Standard Paper Template

### Community 451 - "hf_model_card_frontmatter.sh"
Cohesion: 0.48
Nodes (5): emit_error(), parse_readme(), process_id(), hf_model_card_frontmatter.sh script, show_help()

### Community 452 - "hf_model_papers_auth.sh"
Cohesion: 0.52
Nodes (5): extract_papers(), get_model_papers(), get_trending_models(), hf_model_papers_auth.sh script, show_help()

### Community 453 - "huggingface-vision-trainer/scripts/estimate_cost.py"
Cohesion: 0.43
Nodes (6): estimate_training_time(), extract_model_params(), main(), parse_args(), Extract model size in millions of parameters from the model name., Estimate training time in hours for vision model training.

### Community 454 - "bench_vllm.sh"
Cohesion: 0.43
Nodes (5): orin_uses_upstream_vllm(), run_bench_cmd(), run_one(), bench_vllm.sh script, usage()

### Community 455 - "Jetson Memory Audit"
Cohesion: 0.29
Nodes (4): Jetson Memory Audit, audit.sh script, drop_caches.sh script, Jetson Optimize Memory

### Community 456 - "build_metric_bundle_example"
Cohesion: 0.48
Nodes (6): build_metric_bundle_example(), _bundle(), _ensure_deterministic_hash_seed(), main(), Any, Return bundled JSON for one configured SDK metric.

### Community 457 - "Nemotron Data Prep"
Cohesion: 0.29
Nodes (7): NeMo Curator Translation + FAITH, NeMo Data Designer Synthetic Data, Megatron-Bridge Pretraining, Megatron-Bridge SFT And PEFT, Model Optimization, NeMo-RL Alignment, Nemotron Data Prep

### Community 458 - "test_run_ct_image.py"
Cohesion: 0.38
Nodes (4): Path, test_build_command_matches_upstream_entrypoint(), test_load_config_override_accepts_nested_keys(), test_summarize_image_reports_ct_hu_like()

### Community 459 - "test_run_ct_mask.py"
Cohesion: 0.38
Nodes (4): Path, test_anatomy_size_condition_overwrites_requested_slot(), test_curated_lung_tumor_mask_fixture_uses_robust_size(), test_summarize_mask_reports_missing_expected_label()

### Community 460 - "_extract_case"
Cohesion: 0.57
Nodes (6): _download(), _extract_case(), _human(), main(), Path, Extract a single member from the MSD09 tar and return its path.

### Community 461 - "_write_nifti"
Cohesion: 0.48
Nodes (6): ndarray, Nifti1Image, Path, test_mask_summary_accepts_requested_labels_and_matching_geometry(), test_mask_summary_flags_unrequested_labels_and_geometry_mismatch(), _write_nifti()

### Community 462 - "usd-convert-cad/scripts/report_schema.json"
Cohesion: 0.29
Nodes (6): type, properties, install_hint, $schema, title, type

### Community 463 - "Viewer Input Routing"
Cohesion: 0.29
Nodes (7): Omniverse Realtime Viewer App, Viewer Backend Interface, Viewer Data View Patterns, Viewer Input Routing, Viewport Overlays, Viewport Resize, WebGL SHM Transport

### Community 464 - "az-sub-init.sh"
Cohesion: 0.43
Nodes (5): ARM_SUBSCRIPTION_ID, is_correct_tenant(), login_to_azure(), az-sub-init.sh script, validate_azure_token()

### Community 465 - "generate_configs.py"
Cohesion: 0.33
Nodes (6): find_videos(), generate_configs(), Deterministic hash stable across Python sessions (no PYTHONHASHSEED dependence)., Find all MP4 videos in input directory., Generate cosmos configs for each video and augmentation., _stable_hash()

### Community 467 - "Skill Card Generator"
Cohesion: 0.29
Nodes (7): Skill Card Generator, TAO Analyze Gaps Visual ChangeNet, TAO Analyze Gaps VLM BCQ, TAO Convert Dataset Format, TAO Fine-tune CLIP, TAO Fine-tune Cosmos Embed, TAO Fine-tune Cosmos Reason

### Community 468 - "scripts/run.sh"
Cohesion: 0.29
Nodes (7): inference.py, run_eval.py, prepare_data.py, local_loaders.py, scripts/run.sh, HF Hub Push Script, report.py

### Community 469 - "tao-train-action-recognition/schemas/manifest.json"
Cohesion: 0.29
Nodes (6): actions, automl_enabled, failures, model, network_arch, schema_version

### Community 470 - "train"
Cohesion: 0.29
Nodes (7): train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes, validation_interval

### Community 471 - "tensorrt"
Cohesion: 0.29
Nodes (7): cal_batch_size, cal_batches, tensorrt, calibration, max_batch_size, min_batch_size, opt_batch_size

### Community 472 - "train"
Cohesion: 0.29
Nodes (7): train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes, validation_interval

### Community 473 - "tensorrt"
Cohesion: 0.29
Nodes (7): cal_batch_size, cal_batches, tensorrt, calibration, max_batch_size, min_batch_size, opt_batch_size

### Community 474 - "train"
Cohesion: 0.29
Nodes (7): train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes, validation_interval

### Community 475 - "tao-train-depth-anything-v2/schemas/manifest.json"
Cohesion: 0.29
Nodes (6): actions, automl_enabled, failures, model, network_arch, schema_version

### Community 476 - "gen_trt_engine"
Cohesion: 0.29
Nodes (7): batch_size, gpu_id, tensorrt, gen_trt_engine, max_batch_size, min_batch_size, opt_batch_size

### Community 477 - "train"
Cohesion: 0.29
Nodes (7): train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes, validation_interval

### Community 478 - "DINO Skill Guide"
Cohesion: 0.29
Nodes (7): DINO Actions and Error Patterns, DINO AutoML and SDK Internals, DINO Data and Specs, DINO Tuning and Multi-GPU, DINO Skill Info, TAO Deploy DINO, DINO Skill Guide

### Community 479 - "actions"
Cohesion: 0.29
Nodes (6): actions, automl_enabled, failures, model, network_arch, schema_version

### Community 480 - "train"
Cohesion: 0.29
Nodes (7): train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes, validation_interval

### Community 481 - "FastFoundationStereo Skill Guide"
Cohesion: 0.33
Nodes (7): FFS Error Patterns, FFS Important Parameters, FFS Parent Model Inference, FFS Setup and Run, FFS Skill Info, TAO Deploy Fast Foundation Stereo, FastFoundationStereo Skill Guide

### Community 482 - "tao-train-foundation-stereo/schemas/manifest.json"
Cohesion: 0.29
Nodes (6): actions, automl_enabled, failures, model, network_arch, schema_version

### Community 483 - "gen_trt_engine"
Cohesion: 0.29
Nodes (7): batch_size, gpu_id, tensorrt, gen_trt_engine, max_batch_size, min_batch_size, opt_batch_size

### Community 484 - "train"
Cohesion: 0.29
Nodes (7): train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes, validation_interval

### Community 485 - "gen_trt_engine"
Cohesion: 0.29
Nodes (7): popular, batch_size, gpu_id, tensorrt, gen_trt_engine, min_batch_size, opt_batch_size

### Community 486 - "tensorrt"
Cohesion: 0.29
Nodes (7): cal_batch_size, cal_batches, tensorrt, calibration, max_batch_size, min_batch_size, opt_batch_size

### Community 487 - "gen_trt_engine"
Cohesion: 0.29
Nodes (7): batch_size, gpu_id, tensorrt, gen_trt_engine, max_batch_size, min_batch_size, opt_batch_size

### Community 488 - "train"
Cohesion: 0.29
Nodes (7): train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes, validation_interval

### Community 489 - "gen_trt_engine"
Cohesion: 0.29
Nodes (7): popular, batch_size, gpu_id, tensorrt, gen_trt_engine, min_batch_size, opt_batch_size

### Community 490 - "tensorrt"
Cohesion: 0.29
Nodes (7): cal_batch_size, cal_batches, tensorrt, calibration, max_batch_size, min_batch_size, opt_batch_size

### Community 491 - "transform"
Cohesion: 0.29
Nodes (7): transform, global_crops_scale, global_crops_size, local_crops_scale, local_crops_size, n_global_crops, n_local_crops

### Community 492 - "last_layer_learning_rate"
Cohesion: 0.29
Nodes (7): freeze_steps, max_decay_steps, val_base, val_final, val_start, warm_up_steps, last_layer_learning_rate

### Community 493 - "tao-train-nvpanoptix3d/schemas/manifest.json"
Cohesion: 0.29
Nodes (6): actions, automl_enabled, failures, model, network_arch, schema_version

### Community 494 - "train"
Cohesion: 0.29
Nodes (7): train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes, validation_interval

### Community 495 - "actions"
Cohesion: 0.29
Nodes (6): actions, automl_enabled, failures, model, network_arch, schema_version

### Community 496 - "dataset"
Cohesion: 0.38
Nodes (7): train_dataset, validate_dataset, batch_size, num_workers, dataset, loader, loader

### Community 497 - "train"
Cohesion: 0.29
Nodes (7): train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes, validation_interval

### Community 498 - "tensorrt"
Cohesion: 0.29
Nodes (7): cal_batch_size, cal_batches, tensorrt, calibration, max_batch_size, min_batch_size, opt_batch_size

### Community 499 - "train"
Cohesion: 0.29
Nodes (7): train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes, validation_interval

### Community 500 - "RT-DETR Model Manifest"
Cohesion: 0.29
Nodes (6): actions, automl_enabled, failures, model, network_arch, schema_version

### Community 501 - "Training Hyperparameters"
Cohesion: 0.29
Nodes (7): train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes, validation_interval

### Community 502 - "TensorRT Calibration"
Cohesion: 0.29
Nodes (7): cal_batch_size, cal_batches, tensorrt, calibration, max_batch_size, min_batch_size, opt_batch_size

### Community 503 - "Training Hyperparameters"
Cohesion: 0.29
Nodes (7): train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes, validation_interval

### Community 504 - "Sparse4D Model Manifest"
Cohesion: 0.29
Nodes (6): actions, automl_enabled, failures, model, network_arch, schema_version

### Community 505 - "Dataset Conversion Schema"
Cohesion: 0.29
Nodes (7): dataset_convert, automl_default_parameters, core_module, path, popular, schema_action, spec_template

### Community 506 - "Evaluation Schema"
Cohesion: 0.29
Nodes (7): evaluate, automl_default_parameters, core_module, path, popular, schema_action, spec_template

### Community 507 - "Export Schema"
Cohesion: 0.29
Nodes (7): export, automl_default_parameters, core_module, path, popular, schema_action, spec_template

### Community 508 - "Training Schema"
Cohesion: 0.29
Nodes (7): train, automl_default_parameters, core_module, path, popular, schema_action, spec_template

### Community 509 - "Visual ChangeNet Manifest"
Cohesion: 0.29
Nodes (6): actions, automl_enabled, failures, model, network_arch, schema_version

### Community 510 - "Training Hyperparameters"
Cohesion: 0.29
Nodes (7): train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes, validation_interval

### Community 511 - "Matmul Kernel Implementation"
Cohesion: 0.43
Nodes (6): main(), matmul_kernel(), Constant, kernel, run_matmul(), verify()

### Community 512 - "Softmax CUDA Implementation"
Cohesion: 0.57
Nodes (6): CUDA, main(), ref_softmax(), test_chunked(), test_online(), test_tma()

### Community 513 - "GEMV Kernel Implementation"
Cohesion: 0.29
Nodes (6): cutile_gemv_kernel(), Constant, kernel, Compute matrix-vector multiplication using tiled MMA with persistent scheduling., Compute reference matrix-vector multiplication using torch.matmul., reference_matmul()

### Community 514 - "Environment Configuration Reference"
Cohesion: 0.43
Nodes (7): Caching Reference, Environment Configuration Reference, Transformers.js Code Examples, Supported Model Architectures, ModelRegistry Reference, Pipeline Options Reference, Text Generation Guide

### Community 515 - "update_batch_size.sh"
Cohesion: 0.67
Nodes (6): _apply_tile_grid(), update_batch_size.sh script, update_smartcity_gdino(), update_smartcity_rtdetr(), update_warehouse_2d(), update_warehouse_3d()

### Community 516 - "AMC RTSP Mode"
Cohesion: 0.38
Nodes (7): Shared Calibration Tail, Common Calibration Steps, Deploy Auto-Calibration Service, AMC RTSP Mode, vss-generate-video-calibration Skill, vss-auto-calibration Container, vss-auto-calibration-ui Container

### Community 517 - "Physical AI Defect Image Generation"
Cohesion: 0.33
Nodes (6): Finetune Workflow Config, Good Image Generation Config, Structural Defect Generation Config, Texture Defect Generation Day 0 Config, Texture Defect Generation Day 1 Manual ROI Config, Physical AI Defect Image Generation

### Community 518 - "tao-finetune-cosmos-reason"
Cohesion: 0.33
Nodes (6): Cosmos3-Nano, cosmos-rl-evaluate, cosmos-rl-inference, cosmos-rl-quantize, cosmos-rl, tao-finetune-cosmos-reason

### Community 520 - "IncumbentCallback"
Cohesion: 0.40
Nodes (3): GetSolutionCallback, IncumbentCallback, main()

### Community 521 - "Physical AI Skills"
Cohesion: 0.33
Nodes (6): physical-ai-datasets skill, nurec-fixer skill, asset-harvester skill, ncore skill, nre skill, Physical AI Neural Reconstruction (NuRec) Router

### Community 522 - "Osmo Workflow Orchestration"
Cohesion: 0.53
Nodes (6): osmo data download, osmo workflow logs, osmo workflow query, osmo workflow submit, Physical AI People Attribute Search Workflow Orchestrator, Physical AI Video Data Augmentation Workflow Orchestrator

### Community 523 - "TAO Port HuggingFace Model Skill"
Cohesion: 0.33
Nodes (6): TAO Run on Docker Skill, TAO Run on Local Docker Skill, TAO Setup NVIDIA GPU Host Skill, TAO Port HuggingFace Model Skill, TAO Deploy Base Image, TAO PyTorch Base Image

### Community 524 - "enum"
Cohesion: 0.40
Nodes (6): oav, so, enum, preferred_provider, provider, enum

### Community 526 - "nv_msgbroker"
Cohesion: 0.33
Nodes (6): Gst-nvmsgbroker, nv_msgbroker, nvds_msgapi_connect, nvds_msgapi_do_work, nvds_msgapi_send, nvds_msgapi_send_async

### Community 527 - "DeepStream Profiling Skill"
Cohesion: 0.33
Nodes (6): Boundedness Rules, Config Derivation Rules, Hardware Ceilings, nsys CLI Recipes, NVTX Coverage, DeepStream Profiling Skill

### Community 528 - "earth2studio-create-diagnostic Skill"
Cohesion: 0.33
Nodes (6): earth2studio-create-diagnostic Evaluation Report, Diagnostic PR Body Template, Diagnostic PR Comment Template, Diagnostic Validation Guide, earth2studio-create-diagnostic Skill, earth2studio-create-diagnostic Skill Card

### Community 529 - "earth2studio-create-prognostic Skill"
Cohesion: 0.33
Nodes (6): earth2studio-create-prognostic Evaluation Report, Prognostic PR Body Template, Prognostic PR Comment Template, Prognostic Validation Guide, earth2studio-create-prognostic Skill, earth2studio-create-prognostic Skill Card

### Community 530 - "SageMaker Deployment Planner"
Cohesion: 0.53
Nodes (6): AWS Context Discovery, Python Environment Setup for SageMaker, SageMaker Deployment Planner, SageMaker IAM Preflight, SageMaker Production Defaults, Serving Image Selection

### Community 531 - "run_aws"
Cohesion: 0.67
Nodes (5): aws_bin(), log(), main(), CompletedProcess, run_aws()

### Community 532 - "nemo-mbridge-perf-activation-recompute Skill"
Cohesion: 0.33
Nodes (6): nemo-mbridge-perf-activation-recompute Benchmark, activation_recompute Card, nemo-mbridge-perf-activation-recompute Skill, nemo-mbridge-perf-cuda-graphs Benchmark, cuda_graphs Card, nemo-mbridge-perf-cuda-graphs Skill

### Community 533 - "test_run_ct_from_mask.py"
Cohesion: 0.53
Nodes (5): Path, test_build_command_uses_official_entrypoint(), test_load_request_resolves_mask_path(), test_summarize_mask_accepts_maisi_body_label(), test_validate_mask_summary_rejects_missing_body_label()

### Community 534 - "Omniverse Asset Validation"
Cohesion: 0.33
Nodes (6): Omni Asset Validate Geometry, Omni Asset Validate Physics, CAD to SimReady Preflight, SimReady Conform Profile, SimReady Validate Profile, Validate USD Minimum

### Community 535 - "_write_report"
Cohesion: 0.53
Nodes (5): check_dependencies(), main(), Any, Path, _write_report()

### Community 536 - "Omniverse Streaming Runtime"
Cohesion: 0.33
Nodes (6): Streaming Omniverse Realtime Viewer Recipe, Streaming Client And Protocol, Streaming Interaction Features, Streaming Project Structure, Streaming Server Runtime, Streaming Validation And Build Order

### Community 537 - "RAG Evaluation Framework"
Cohesion: 0.33
Nodes (6): RAG Evaluation Configuration, Benchmark Execution Guide, Dataset and Conversion Guide, Evaluate RAG CLI Reference, Result Analysis Guide, RAG Evaluation Skill

### Community 538 - "FoodSeg Segmentation Training"
Cohesion: 0.53
Nodes (5): build_processor(), compute_metrics(), main(), make_transforms(), Compute mean IoU from logits + masks. Does not assume torchmetrics.

### Community 539 - "HuggingFace Fine-Tune Detailed Workflow Map"
Cohesion: 0.33
Nodes (6): Compatibility Workarounds Registry, Core Rules, Dataset Recommendations Reference, HuggingFace Fine-Tune Detailed Workflow Map, Docker Run Catalog, Error Playbook

### Community 540 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, core_module, path, popular, schema_action, spec_template

### Community 541 - "export"
Cohesion: 0.33
Nodes (6): export, core_module, path, popular, schema_action, spec_template

### Community 542 - "tao-train-centerpose/schemas/manifest.json"
Cohesion: 0.33
Nodes (5): automl_enabled, failures, model, network_arch, schema_version

### Community 543 - "export"
Cohesion: 0.33
Nodes (6): actions, export, core_module, path, schema_action, spec_template

### Community 544 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, core_module, path, popular, schema_action, spec_template

### Community 545 - "gen_trt_engine"
Cohesion: 0.33
Nodes (6): gen_trt_engine, core_module, path, popular, schema_action, spec_template

### Community 546 - "inference"
Cohesion: 0.33
Nodes (6): inference, core_module, path, popular, schema_action, spec_template

### Community 547 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 548 - "tao-train-deformable-detr/schemas/manifest.json"
Cohesion: 0.33
Nodes (5): automl_enabled, failures, model, network_arch, schema_version

### Community 549 - "export"
Cohesion: 0.33
Nodes (6): actions, export, core_module, path, schema_action, spec_template

### Community 550 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, core_module, path, popular, schema_action, spec_template

### Community 551 - "inference"
Cohesion: 0.33
Nodes (6): inference, core_module, path, popular, schema_action, spec_template

### Community 552 - "quantize"
Cohesion: 0.33
Nodes (6): quantize, core_module, path, popular, schema_action, spec_template

### Community 553 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 554 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, core_module, path, popular, schema_action, spec_template

### Community 555 - "export"
Cohesion: 0.33
Nodes (6): export, core_module, path, popular, schema_action, spec_template

### Community 556 - "inference"
Cohesion: 0.33
Nodes (6): inference, core_module, path, popular, schema_action, spec_template

### Community 557 - "quantize"
Cohesion: 0.33
Nodes (6): quantize, core_module, path, popular, schema_action, spec_template

### Community 558 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 559 - "distill"
Cohesion: 0.33
Nodes (6): distill, core_module, path, popular, schema_action, spec_template

### Community 560 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, core_module, path, popular, schema_action, spec_template

### Community 561 - "export"
Cohesion: 0.33
Nodes (6): export, core_module, path, popular, schema_action, spec_template

### Community 562 - "inference"
Cohesion: 0.33
Nodes (6): inference, core_module, path, popular, schema_action, spec_template

### Community 563 - "quantize"
Cohesion: 0.33
Nodes (6): quantize, core_module, path, popular, schema_action, spec_template

### Community 564 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 565 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, core_module, path, popular, schema_action, spec_template

### Community 566 - "export"
Cohesion: 0.33
Nodes (6): export, core_module, path, popular, schema_action, spec_template

### Community 567 - "inference"
Cohesion: 0.33
Nodes (6): inference, core_module, path, popular, schema_action, spec_template

### Community 568 - "quantize"
Cohesion: 0.33
Nodes (6): quantize, core_module, path, popular, schema_action, spec_template

### Community 569 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 570 - "quantize"
Cohesion: 0.33
Nodes (6): quantize, core_module, path, popular, schema_action, spec_template

### Community 571 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 572 - "export"
Cohesion: 0.20
Nodes (10): export, core_module, path, popular, schema_action, spec_template, gpu_ids, num_gpus (+2 more)

### Community 573 - "quantize"
Cohesion: 0.33
Nodes (6): quantize, core_module, path, popular, schema_action, spec_template

### Community 574 - "model"
Cohesion: 0.33
Nodes (6): popular, sem_seg_head, model, convs_dim, mask_dim, transformer_enc_layers

### Community 575 - "tao-train-mask-auto-encoder/schemas/manifest.json"
Cohesion: 0.33
Nodes (5): automl_enabled, failures, model, network_arch, schema_version

### Community 576 - "inference"
Cohesion: 0.40
Nodes (5): inference, core_module, path, schema_action, spec_template

### Community 577 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, core_module, path, popular, schema_action, spec_template

### Community 578 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 579 - "quantize"
Cohesion: 0.33
Nodes (6): quantize, core_module, path, popular, schema_action, spec_template

### Community 580 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 581 - "tao-train-nvdinov2/schemas/manifest.json"
Cohesion: 0.33
Nodes (5): automl_enabled, failures, model, network_arch, schema_version

### Community 582 - "teacher_temperature"
Cohesion: 0.33
Nodes (6): teacher_temperature, max_decay_steps, val_base, val_final, val_start, warm_up_steps

### Community 583 - "weight_decay"
Cohesion: 0.33
Nodes (6): weight_decay, max_decay_steps, val_base, val_final, val_start, warm_up_steps

### Community 584 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, automl_default_parameters, core_module, path, schema_action, spec_template

### Community 585 - "export"
Cohesion: 0.33
Nodes (6): export, automl_default_parameters, core_module, path, schema_action, spec_template

### Community 586 - "inference"
Cohesion: 0.33
Nodes (6): inference, automl_default_parameters, core_module, path, schema_action, spec_template

### Community 587 - "train"
Cohesion: 0.33
Nodes (6): train, automl_default_parameters, core_module, path, schema_action, spec_template

### Community 588 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, core_module, path, popular, schema_action, spec_template

### Community 589 - "inference"
Cohesion: 0.33
Nodes (6): inference, core_module, path, popular, schema_action, spec_template

### Community 590 - "prune"
Cohesion: 0.33
Nodes (6): prune, core_module, path, popular, schema_action, spec_template

### Community 591 - "quantize"
Cohesion: 0.33
Nodes (6): quantize, core_module, path, popular, schema_action, spec_template

### Community 592 - "inference"
Cohesion: 0.20
Nodes (10): dataset_convert, core_module, path, popular, schema_action, spec_template, gpu_ids, num_gpus (+2 more)

### Community 593 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, core_module, path, popular, schema_action, spec_template

### Community 594 - "export"
Cohesion: 0.33
Nodes (6): export, core_module, path, popular, schema_action, spec_template

### Community 595 - "gen_trt_engine"
Cohesion: 0.33
Nodes (6): gen_trt_engine, core_module, path, popular, schema_action, spec_template

### Community 596 - "inference"
Cohesion: 0.33
Nodes (6): inference, core_module, path, popular, schema_action, spec_template

### Community 597 - "evaluate"
Cohesion: 0.20
Nodes (10): retrain, gpu_ids, num_gpus, num_nodes, evaluate, core_module, path, popular (+2 more)

### Community 598 - "tao-train-oneformer/schemas/manifest.json"
Cohesion: 0.33
Nodes (5): automl_enabled, failures, model, network_arch, schema_version

### Community 599 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, core_module, path, popular, schema_action, spec_template

### Community 600 - "gen_trt_engine"
Cohesion: 0.33
Nodes (6): gen_trt_engine, core_module, path, popular, schema_action, spec_template

### Community 601 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 602 - "tao-train-optical-inspection/schemas/manifest.json"
Cohesion: 0.33
Nodes (5): automl_enabled, failures, model, network_arch, schema_version

### Community 603 - "export"
Cohesion: 0.33
Nodes (6): actions, export, core_module, path, schema_action, spec_template

### Community 604 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, core_module, path, popular, schema_action, spec_template

### Community 605 - "gen_trt_engine"
Cohesion: 0.33
Nodes (6): gen_trt_engine, core_module, path, popular, schema_action, spec_template

### Community 606 - "inference"
Cohesion: 0.33
Nodes (6): inference, core_module, path, popular, schema_action, spec_template

### Community 607 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 608 - "gen_trt_engine"
Cohesion: 0.33
Nodes (6): gen_trt_engine, core_module, path, popular, schema_action, spec_template

### Community 609 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 610 - "distill"
Cohesion: 0.33
Nodes (6): distill, core_module, path, popular, schema_action, spec_template

### Community 611 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, core_module, path, popular, schema_action, spec_template

### Community 612 - "export"
Cohesion: 0.33
Nodes (6): export, core_module, path, popular, schema_action, spec_template

### Community 613 - "inference"
Cohesion: 0.33
Nodes (6): inference, core_module, path, popular, schema_action, spec_template

### Community 614 - "quantize"
Cohesion: 0.33
Nodes (6): quantize, core_module, path, popular, schema_action, spec_template

### Community 615 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 616 - "tao-train-segformer/schemas/manifest.json"
Cohesion: 0.33
Nodes (5): automl_enabled, failures, model, network_arch, schema_version

### Community 617 - "export"
Cohesion: 0.33
Nodes (6): actions, export, core_module, path, schema_action, spec_template

### Community 618 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, core_module, path, popular, schema_action, spec_template

### Community 619 - "inference"
Cohesion: 0.33
Nodes (6): inference, core_module, path, popular, schema_action, spec_template

### Community 620 - "quantize"
Cohesion: 0.33
Nodes (6): quantize, core_module, path, popular, schema_action, spec_template

### Community 621 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 622 - "inference"
Cohesion: 0.33
Nodes (6): inference, automl_default_parameters, core_module, path, schema_action, spec_template

### Community 623 - "quantize"
Cohesion: 0.33
Nodes (6): quantize, automl_default_parameters, core_module, path, schema_action, spec_template

### Community 624 - "evaluate"
Cohesion: 0.33
Nodes (6): evaluate, core_module, path, popular, schema_action, spec_template

### Community 625 - "inference"
Cohesion: 0.33
Nodes (6): inference, core_module, path, popular, schema_action, spec_template

### Community 626 - "segment_evaluate"
Cohesion: 0.33
Nodes (6): segment_evaluate, core_module, path, popular, schema_action, spec_template

### Community 627 - "segment_inference"
Cohesion: 0.33
Nodes (6): segment_inference, core_module, path, popular, schema_action, spec_template

### Community 628 - "segment_train"
Cohesion: 0.33
Nodes (6): segment_train, core_module, path, popular, schema_action, spec_template

### Community 629 - "train"
Cohesion: 0.33
Nodes (6): train, core_module, path, popular, schema_action, spec_template

### Community 630 - "fetch_resources.sh"
Cohesion: 0.53
Nodes (5): download_ngc(), downloaded_refs, resolve_local_role(), resolve_ngc_role(), fetch_resources.sh script

### Community 632 - "Texture Defect Generation Day 1 Real Alignment Workflow"
Cohesion: 0.40
Nodes (5): Texture Defect Generation Day 1 Real Alignment Workflow, PCB usd2roi Day 1 Config, usd2roi_crop.py, usd2roi_register.py, usd2roi_render.py

### Community 633 - "enum"
Cohesion: 0.40
Nodes (5): flagged_pairs_only, per_target_or_sample, whole_stage, scope_policy, enum

### Community 634 - "model.dropout_ratio"
Cohesion: 0.40
Nodes (5): model.dropout_ratio, automl_default_parameters, automl_default_parameters, automl_default_parameters, automl_default_parameters

### Community 635 - "SentenceTransformer"
Cohesion: 0.50
Nodes (4): SentenceTransformer, build_parser(), main(), ArgumentParser

### Community 636 - "BufferProvider"
Cohesion: 0.40
Nodes (5): BufferProvider, MultiSourceProvider, QueuedProvider, SafeBufferProvider, SimpleVideoProvider

### Community 637 - "DeepStream Pipeline Builder Skill"
Cohesion: 0.40
Nodes (5): Pipeline Assembly Rules, Output Format Guide, Requirement Extraction Reference, Security and Limitations, DeepStream Pipeline Builder Skill

### Community 639 - "check_router_health.py"
Cohesion: 0.70
Nodes (4): choose_model(), main(), Any, request_json()

### Community 641 - "convert_to_gguf.py"
Cohesion: 0.40
Nodes (4): check_system_dependencies(), Check if required system packages are available., Run a command with error handling., run_command()

### Community 643 - "hf_enrich_models.sh"
Cohesion: 0.70
Nodes (4): emit_error(), process_id(), hf_enrich_models.sh script, show_help()

### Community 644 - "Hugging Face ZeroGPU Skill"
Cohesion: 0.40
Nodes (5): Hugging Face ZeroGPU Skill, Concurrency Safety, CUDA Dependencies on ZeroGPU, How ZeroGPU duration and quota are checked, How ZeroGPU works (mechanism)

### Community 645 - "bench_ollama.sh"
Cohesion: 0.70
Nodes (4): do_request(), parse_timing(), bench_ollama.sh script, usage()

### Community 646 - "nemo-evaluator-plugin Skill"
Cohesion: 0.60
Nodes (5): Evaluator API Auth, nemo-evaluator-plugin Benchmark, LLM Judge Notes, nemo-evaluator-plugin Skill, Evaluation Troubleshooting

### Community 647 - "response_guidance"
Cohesion: 0.40
Nodes (5): ^S[0-4]$, response_guidance, patternProperties, type, type

### Community 648 - "Nemotron Retrieval Recipes Skill Card"
Cohesion: 0.40
Nodes (5): Embedding Recipe Reference, Evaluation Practices, Remote Execution Reference, Rerank Recipe Reference, Nemotron Retrieval Recipes Skill Card

### Community 649 - "_write_report"
Cohesion: 0.50
Nodes (4): main(), Any, Path, _write_report()

### Community 650 - "Omniverse USD Performance Tuning"
Cohesion: 0.40
Nodes (5): Omniverse USD Performance Tuning, Compare Profiles Contract, Output Workspace Contract, Runtime Artifact Token Budget, USD Performance Tuning Skill Map

### Community 651 - "operations/manifest.json"
Cohesion: 0.40
Nodes (4): $comment, operations, schema, source

### Community 652 - "USD Validation Runner"
Cohesion: 0.50
Nodes (5): USD Validation Runner, so-interpret-validators, so-run-validators, Validate USD Asset Validator, Validator Rule Reference

### Community 653 - "Reolink Focus Control"
Cohesion: 0.40
Nodes (5): Reolink Focus Control, Reolink Snapshot Auth & EXIF, Reolink Snapshot Capture, RTSP Metadata Preservation, RTSP vs Still Metadata

### Community 654 - "plugin-app.py"
Cohesion: 0.50
Nodes (4): main(), Sage/Waggle Edge Plugin Template Minimal plugin that reads a sensor and…, Replace with actual sensor reading logic., read_sensor()

### Community 655 - "tests/conftest.py"
Cohesion: 0.40
Nodes (5): tests/conftest.py, tests/test_collator.py, tests/test_dataset.py, tests/test_model.py, tests/test_smoke.py

### Community 656 - "AutoMLRunner"
Cohesion: 0.40
Nodes (5): AutoMLRunner, BrevSDK, DockerSDK, KubernetesSDK, SlurmSDK

### Community 657 - "stage_backbone.py"
Cohesion: 0.70
Nodes (4): main(), parse_args(), Namespace, resolve_dest()

### Community 658 - "inference"
Cohesion: 0.40
Nodes (5): inference, core_module, path, schema_action, spec_template

### Community 659 - "train"
Cohesion: 0.40
Nodes (5): train, core_module, path, schema_action, spec_template

### Community 660 - "export"
Cohesion: 0.33
Nodes (6): actions, export, core_module, path, schema_action, spec_template

### Community 661 - "optim"
Cohesion: 0.40
Nodes (5): backbone_multiplier, layer_decay, momentum, weight_decay, optim

### Community 662 - "evaluate"
Cohesion: 0.40
Nodes (5): evaluate, core_module, path, schema_action, spec_template

### Community 663 - "train"
Cohesion: 0.40
Nodes (5): train, core_module, path, schema_action, spec_template

### Community 664 - "sem_seg_head"
Cohesion: 0.40
Nodes (5): sem_seg_head, convs_dim, depth_dim, mask_dim, transformer_enc_layers

### Community 665 - "quantize"
Cohesion: 0.40
Nodes (5): quantize, core_module, path, schema_action, spec_template

### Community 666 - "train"
Cohesion: 0.40
Nodes (5): train, gpu_ids, num_epochs, num_gpus, num_nodes

### Community 667 - "02_matmul/cutile_julia.jl"
Cohesion: 0.50
Nodes (3): CUDA, main(), verify()

### Community 668 - "Deploy and Use RT-VLM Dense Captioning"
Cohesion: 0.50
Nodes (5): Video QnA using VLM through VSS Agent, RT-VLM 26.05 API Surface Notes, Deploy RT-VLM Service, RTVI VLM Kafka Workflows, Deploy and Use RT-VLM Dense Captioning

### Community 669 - "update_output_sink.sh"
Cohesion: 0.60
Nodes (3): _check(), ensure_encoder_deps(), update_output_sink.sh script

### Community 670 - "write_deployment_log.sh"
Cohesion: 0.70
Nodes (4): _dump(), _hdr(), redact_secrets(), write_deployment_log.sh script

### Community 671 - "normalize"
Cohesion: 0.60
Nodes (4): main(), normalize(), Path, Strip dangling *optional* depends_on entries in resolved compose at *path*.…

### Community 672 - "Setup Task"
Cohesion: 0.67
Nodes (4): Augmentation Worker, Augmented Video Auto-labeling Worker, Original Video Auto-labeling Worker, Setup Task

### Community 673 - "Performance Tuning Guide"
Cohesion: 0.50
Nodes (4): Performance Tuning Guide, Memory Tuning Skill Card, Parallelism Strategies Skill Card, Packed Sequences Long Context Skill Card

### Community 674 - "TAO Train Grounding DINO"
Cohesion: 0.50
Nodes (4): Grounding DINO Deploy, tao-deploy-grounding-dino, grounding_dino CLI, TAO Train Grounding DINO

### Community 675 - "FrameSampler"
Cohesion: 0.50
Nodes (4): FrameSampler, MediaChunk, MediaExtractor, VideoFrame

### Community 676 - "OCRNet Export"
Cohesion: 0.50
Nodes (4): OCRNet Dataset Convert, OCRNet Export, OCRNet Gen TRT Engine, OCRNet Train

### Community 677 - "TransformGizmo"
Cohesion: 0.50
Nodes (4): CameraState, PointerEvent, TransformGizmo, Viewport

### Community 678 - "accelerated-computing-cudf"
Cohesion: 0.50
Nodes (4): accelerated-computing-cudf, cuDF API Patterns, Gaps, and Semantic Differences, cudf.pandas Accelerator Deep Dive, dask-cuDF Patterns

### Community 679 - "Routing: Python API Examples"
Cohesion: 0.50
Nodes (4): Routing: Python API Examples, routing.DataModel, routing.Solve, routing.SolverSettings

### Community 680 - "cuPyNumeric HDF5 I/O Skill"
Cohesion: 0.50
Nodes (4): legate.io.hdf5.from_file, legate.io.hdf5.from_file_batched, legate.io.hdf5.to_file, cuPyNumeric HDF5 I/O Skill

### Community 681 - "Idioms That Block"
Cohesion: 0.83
Nodes (4): Idioms That Block, Idioms That Scale, Partitioning and Load Balance, Refactor Recipes

### Community 682 - "nvmultiurisrcbin"
Cohesion: 0.50
Nodes (4): nvmultiurisrcbin, nvstreammux, nvurisrcbin, SourceManager

### Community 683 - "embed_images"
Cohesion: 0.67
Nodes (3): embed_images(), main(), Replace <img src="file.png"> with base64-embedded data URIs.

### Community 685 - "render-mermaid-for-pdf.py"
Cohesion: 0.67
Nodes (3): main(), Path, render_one()

### Community 686 - "Dynamo Failure Decision Tree"
Cohesion: 0.50
Nodes (4): dynamo-troubleshoot Evaluation Report, Dynamo Failure Decision Tree, dynamo-troubleshoot Skill, dynamo-troubleshoot Skill Card

### Community 687 - "DataSource Validation Guide"
Cohesion: 0.50
Nodes (4): earth2studio-create-datasource Evaluation Report, DataSource Validation Guide, earth2studio-create-datasource Skill, earth2studio-create-datasource Skill Card

### Community 688 - "Deterministic Forecast Troubleshooting"
Cohesion: 0.50
Nodes (4): earth2studio-deterministic-forecast Evaluation Report, Deterministic Forecast Troubleshooting, earth2studio-deterministic-forecast Skill, earth2studio-deterministic-forecast Skill Card

### Community 689 - "jetson-inference-mem-tune"
Cohesion: 0.67
Nodes (4): jetson-headless-mode, jetson-inference-mem-tune, jetson-llm-benchmark, jetson-llm-serve

### Community 691 - "NeMo-RL Auto Research Skill Card"
Cohesion: 0.50
Nodes (4): Experiment Log Template, Exploration Ideas, Git Workflow, NeMo-RL Auto Research Skill Card

### Community 692 - "Viewer Control Patterns"
Cohesion: 0.50
Nodes (4): Viewer Control Patterns, Viewer Feedback And Status, Viewer Layout Patterns, Viewer UX Workflow

### Community 693 - "properties"
Cohesion: 0.08
Nodes (23): type, type, type, properties, type, type, type, properties (+15 more)

### Community 694 - "output"
Cohesion: 0.15
Nodes (13): response_text, text_chars, additionalProperties, properties, required, type, output, response_text (+5 more)

### Community 696 - "RAG Helm Deployment"
Cohesion: 0.50
Nodes (4): RAG Helm Deployment, MIG GPU Deployment, Helm Deployment on OpenShift, Standard Helm Deployment

### Community 697 - "Image Metadata Naming and Eventlog Linking"
Cohesion: 0.50
Nodes (4): Image Metadata Naming and Eventlog Linking, Image Upload Provenance and Linking, Linking Images to Event Log and Uniqueness, Local Cache Ring Buffer

### Community 698 - "query-and-plot-durations.py"
Cohesion: 0.83
Nodes (3): main(), query(), short()

### Community 700 - "main"
Cohesion: 0.83
Nodes (3): main(), Path, validate()

### Community 701 - "TAO Analyze ChangeNet RCA Skill"
Cohesion: 0.50
Nodes (4): Investigation Phases, Report Structure and Output Layout, Parallelization Strategy, TAO Analyze ChangeNet RCA Skill

### Community 702 - "segformer-b0-foodseg103/infer.py"
Cohesion: 0.83
Nodes (3): colorize(), main(), palette()

### Community 703 - "TAO Workflow Consistency Guide"
Cohesion: 0.83
Nodes (4): TAO Workflow Consistency Guide, tao-core, tao-deploy, tao-pytorch

### Community 704 - "tao-run-inference-service"
Cohesion: 0.50
Nodes (4): tao-run-inference-service, tao-run-on-brev, tao-run-on-kubernetes, tao-run-on-local-docker

### Community 705 - "TAO Inference Microservice"
Cohesion: 0.50
Nodes (4): TAO Inference Microservice, Brev Platform, Kubernetes Platform, Local Docker Platform

### Community 706 - "evaluate"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, evaluate

### Community 707 - "gen_trt_engine"
Cohesion: 0.50
Nodes (4): popular, batch_size, gpu_id, gen_trt_engine

### Community 708 - "inference"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, inference

### Community 709 - "Deformable DETR Deploy"
Cohesion: 0.50
Nodes (4): Deformable DETR Skill Info, Deformable DETR Deploy, Deformable DETR Deploy Skill Info, Deformable DETR Skill

### Community 710 - "evaluate"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, evaluate

### Community 711 - "gen_trt_engine"
Cohesion: 0.50
Nodes (4): popular, batch_size, gpu_id, gen_trt_engine

### Community 712 - "inference"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, inference

### Community 713 - "Depth Anything v2 Deploy"
Cohesion: 0.50
Nodes (4): Depth Anything v2 Skill Info, Depth Anything v2 Deploy, Depth Anything v2 Deploy Skill Info, Depth Anything v2 Skill

### Community 714 - "GPU Evaluation Config"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, evaluate

### Community 715 - "GPU Inference Config"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, inference

### Community 716 - "GPU Evaluation Config"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, evaluate

### Community 717 - "GPU Inference Config"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, inference

### Community 718 - "GPU Evaluation Config"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, evaluate

### Community 719 - "GPU Inference Config"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, inference

### Community 720 - "evaluate"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, evaluate

### Community 721 - "tensorrt"
Cohesion: 0.50
Nodes (4): tensorrt, max_batch_size, min_batch_size, opt_batch_size

### Community 722 - "tensorrt"
Cohesion: 0.50
Nodes (4): tensorrt, max_batch_size, min_batch_size, opt_batch_size

### Community 723 - "tensorrt"
Cohesion: 0.50
Nodes (4): tensorrt, max_batch_size, min_batch_size, opt_batch_size

### Community 724 - "evaluate"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, evaluate

### Community 725 - "tensorrt"
Cohesion: 0.50
Nodes (4): tensorrt, max_batch_size, min_batch_size, opt_batch_size

### Community 726 - "sem_seg_head"
Cohesion: 0.50
Nodes (4): sem_seg_head, convs_dim, mask_dim, transformer_enc_layers

### Community 727 - "optim"
Cohesion: 0.50
Nodes (4): backbone_multiplier, momentum, weight_decay, optim

### Community 728 - "Optical Inspection Deploy"
Cohesion: 0.50
Nodes (4): Optical Inspection Deploy, Optical Inspection Deploy Skill Info, Optical Inspection Skill Card, TAO Train Optical Inspection

### Community 729 - "GPU Evaluation Config"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, evaluate

### Community 730 - "TensorRT Engine Generation"
Cohesion: 0.50
Nodes (4): popular, batch_size, gpu_id, gen_trt_engine

### Community 731 - "GPU Inference Config"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, inference

### Community 732 - "PointPillars Train Deploy"
Cohesion: 0.50
Nodes (4): PointPillars Train Skill Info, PointPillars Deploy, PointPillars Deploy Skill Info, PointPillars Train Skill

### Community 733 - "GPU Evaluation Config"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, evaluate

### Community 734 - "GPU Inference Config"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, inference

### Community 735 - "GPU Evaluation Config"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, evaluate

### Community 736 - "TensorRT Engine Generation"
Cohesion: 0.50
Nodes (4): popular, batch_size, gpu_id, gen_trt_engine

### Community 737 - "GPU Inference Config"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, inference

### Community 738 - "GPU Evaluation Config"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, evaluate

### Community 739 - "GPU Inference Config"
Cohesion: 0.50
Nodes (4): gpu_ids, num_gpus, num_nodes, inference

### Community 740 - "CUDA Julia Verification"
Cohesion: 0.67
Nodes (3): CUDA, main(), verify()

### Community 741 - "Platform Reference"
Cohesion: 0.50
Nodes (4): Pipeline Configuration, Platform Reference, Start the Application, Teardown Flow

### Community 743 - "Base Profile Reference"
Cohesion: 0.83
Nodes (4): Base Profile Reference, VSS LVS Profile Reference, VSS Search Profile Reference, Deploy Troubleshooting

### Community 744 - "Workflow D: Alert Subscriptions"
Cohesion: 0.67
Nodes (3): Alert Bridge API, Workflow D: Alert Subscriptions, VST API

### Community 745 - "E2E Workflow Config"
Cohesion: 0.67
Nodes (3): E2E Workflow Config, Qwen2.5-14B NIM, Qwen3-VL NIM

### Community 746 - "Search Strategies"
Cohesion: 0.67
Nodes (3): ct.launch, exhaustive_search, Search Strategies

### Community 747 - "Qwen3-235B PVC"
Cohesion: 0.67
Nodes (3): Qwen3-235B HF Download Job, Qwen3-235B NIMService, Qwen3-235B PVC

### Community 748 - "Standalone Runtime Setup"
Cohesion: 0.67
Nodes (3): Install Asset Validator Standalone, Install Scene Optimizer Standalone, Standalone Runtime Setup

### Community 749 - "Input Controller"
Cohesion: 0.67
Nodes (3): Camera Controller, Input Controller, Selection Controller

### Community 750 - "Render Settings"
Cohesion: 0.67
Nodes (3): Render Settings, Settings Store, Render Settings Panel Widget

### Community 751 - "Scene Manager"
Cohesion: 0.67
Nodes (3): Scene Loader, Scene Manager, Scene Picker Widget

### Community 752 - "Stage Queries"
Cohesion: 0.67
Nodes (3): Stage Queries, Prim Info Panel Widget, Stage Tree Widget

### Community 753 - "nv-reason-cxr"
Cohesion: 0.67
Nodes (3): nv_reason_cxr_quality_v1, nv-reason-cxr, NVIDIA-Medtech/NV-Reason-CXR

### Community 754 - "Nemotron Policy Generator"
Cohesion: 0.67
Nodes (3): Nemotron-3-Content-Safety, Nemotron-Content-Safety-Reasoning-4B, Nemotron Policy Generator

### Community 755 - "OneFormer Export"
Cohesion: 0.67
Nodes (3): OneFormer Export, OneFormer Gen TRT Engine, OneFormer Train

### Community 756 - "Pipeline"
Cohesion: 0.67
Nodes (3): Pipeline, EngineFileMonitor, PerfMonitor

### Community 757 - "Calibrate Sample Dataset Skill"
Cohesion: 1.00
Nodes (3): Calibrate Sample Dataset Skill, Calibrate from Video Files Skill, Launch AutoMagicCalib Release Containers Skill

### Community 763 - "DeepStream Development Skill"
Cohesion: 0.67
Nodes (3): DeepStream Best Practices, Buffer Provider and Retriever APIs, DeepStream Development Skill

### Community 764 - "DeepStream Import Vision Model Skill"
Cohesion: 0.67
Nodes (3): Engine Build Reference, Model Acquire Reference, DeepStream Import Vision Model Skill

### Community 766 - "DeepStream SOP Inference Microservice Skill"
Cohesion: 0.67
Nodes (3): SOP DeepStream Pipeline, SOP Triton DDM Model, DeepStream SOP Inference Microservice Skill

### Community 767 - "Dynamo Recipe Runner"
Cohesion: 0.67
Nodes (3): Dynamo Interconnect Check, Dynamo Recipe Runner, Dynamo Router Starter

### Community 768 - "graphify Skill"
Cohesion: 0.67
Nodes (3): Extraction Specification, Query and Traversal Flow, graphify Skill

### Community 774 - "nemo-mbridge-mlm-bridge-training Skill"
Cohesion: 0.67
Nodes (3): nemo-mbridge-mlm-bridge-training Benchmark, mlm_bridge_training Card, nemo-mbridge-mlm-bridge-training Skill

### Community 775 - "nemo-mbridge-multi-node-slurm Skill"
Cohesion: 0.67
Nodes (3): nemo-mbridge-multi-node-slurm Benchmark, nemo-mbridge-multi-node-slurm Skill, Multi-Node Slurm Templates

### Community 776 - "nemo-mbridge-perf-expert-parallel-overlap Skill"
Cohesion: 0.67
Nodes (3): nemo-mbridge-perf-expert-parallel-overlap Benchmark, expert_parallel_overlap Card, nemo-mbridge-perf-expert-parallel-overlap Skill

### Community 777 - "Retriever Query Workflow"
Cohesion: 0.67
Nodes (3): Retriever Query Workflow, Retriever Setup Workflow, Retriever Troubleshooting

### Community 779 - "nemo-rl-auto-research"
Cohesion: 0.67
Nodes (3): nemo-rl-auto-research, nemo-rl-brev-etiquette, nemo-rl-session-memory

### Community 780 - "Nemotron Policy Generator Skill Card"
Cohesion: 0.67
Nodes (3): Policy Archetypes, Nemotron Policy Generator Skill Card, Content Safety V2 Taxonomy

### Community 781 - "Tauri + Rust OVRTX Omniverse Realtime Viewer"
Cohesion: 0.67
Nodes (3): Streaming vs Local Omniverse Realtime Viewer, Tauri + Rust OVRTX Omniverse Realtime Viewer, Tauri SHM Transform Gizmo

### Community 783 - "Azure OSMO Setup"
Cohesion: 0.67
Nodes (3): Azure Cluster Setup, Azure OSMO Setup, OSMO CLI

### Community 791 - "PhysicsNeMo Search Recipes"
Cohesion: 1.00
Nodes (3): PhysicsNeMo Search Recipes, PhysicsNeMo Taxonomy, PhysicsNeMo Discover Skill

### Community 792 - "Docker Build & Deploy for Sage Edge Plugins"
Cohesion: 0.67
Nodes (3): SES vs pluginctl: Deployment Model & Diagnostics, Direct Node Testing, Docker Build & Deploy for Sage Edge Plugins

### Community 793 - "Job Scheduling and Liveness"
Cohesion: 0.67
Nodes (3): Job Scheduling and Debugging, Job Scheduling and Liveness, Node Control Plane Disconnect Diagnosis

### Community 794 - "Sage Documentation Index"
Cohesion: 0.67
Nodes (3): Sage Documentation Index, Slack Notification for Sage Plugin Detections, Verifying Sage Upload/Storage Health

### Community 799 - "CLIP Fine-tuning Skill"
Cohesion: 0.67
Nodes (3): CLIP Fine-tuning Skill, tao_toolkit.deploy, tao_toolkit.pyt

### Community 800 - "Cosmos-RL Launch Intake and Preflight"
Cohesion: 0.67
Nodes (3): Cosmos-RL Launch Intake and Preflight, check_tao_launch_preflight.py, resolve_tao_image.py

### Community 805 - "train.py"
Cohesion: 0.67
Nodes (3): dataset.py, model.py, train.py

### Community 806 - "Image Grounding Pipeline"
Cohesion: 0.67
Nodes (3): Image Grounding Configuration Reference, vLLM Server Setup for VLMs, Image Grounding Pipeline

### Community 807 - "Video Reasoning Annotation Pipeline"
Cohesion: 0.67
Nodes (3): Video Reasoning Annotation Configuration Reference, Video Reasoning Domain Adaptation Guide, Video Reasoning Annotation Pipeline

### Community 812 - "parse_args"
Cohesion: 0.67
Nodes (3): parse_args(), Namespace, Parse command-line arguments.

### Community 813 - "TAO Train Image Classification"
Cohesion: 0.67
Nodes (3): classification_pyt CLI, Classification PyT Deploy, TAO Train Image Classification

### Community 814 - "TAO Train Mask2Former"
Cohesion: 0.67
Nodes (3): TAO Train Mask2Former, Mask2Former Deploy, Skill Info (Mask2Former)

### Community 815 - "TAO Train Mask Auto Encoder"
Cohesion: 0.67
Nodes (3): MAE Deploy, TAO Train Mask Auto Encoder, TAO Train Mask Auto Label

### Community 816 - "TAO Train Mask Grounding DINO"
Cohesion: 0.67
Nodes (3): TAO Train Mask Grounding DINO, Mask Grounding DINO Deploy, Skill Info (Mask Grounding DINO)

### Community 817 - "tao-train-metric-learning-recognition"
Cohesion: 0.67
Nodes (3): tao-train-metric-learning-recognition, MLRecog Deploy Guide, Skill Info (Metric Learning Recognition)

### Community 818 - "tao-train-nvdinov2"
Cohesion: 0.67
Nodes (3): tao-train-nvdinov2, NvDINOv2 Deploy Guide, Skill Info (NVDINOv2)

### Community 819 - "TAO Train OCDNet"
Cohesion: 0.67
Nodes (3): OCDNet Deploy Skill, Skill Info (OCDNet), TAO Train OCDNet

### Community 820 - "TAO Train OCRNet"
Cohesion: 0.67
Nodes (3): OCRNet Skill Card, OCRNet Deploy Skill, TAO Train OCRNet

### Community 821 - "TAO Train OneFormer"
Cohesion: 0.67
Nodes (3): OneFormer Skill Card, OneFormer Deploy Skill, TAO Train OneFormer

### Community 822 - "Visual ChangeNet Deploy"
Cohesion: 0.67
Nodes (3): Visual ChangeNet Deploy, Export Action, Generate TRT Engine

### Community 824 - "CuTile Autotuning Skill"
Cohesion: 0.67
Nodes (3): exhaustive_search API Reference, Hardware Constraints, CuTile Autotuning Skill

### Community 828 - "VSS Prerequisites Check"
Cohesion: 0.67
Nodes (3): Edge Deployment Reference, NGC CLI Reference, VSS Prerequisites Check

### Community 830 - "VSS Agent /generate Endpoint"
Cohesion: 0.67
Nodes (3): Workflow B: VLM Real-time Monitoring, Workflow C: Query/List Alerts, VSS Agent /generate Endpoint

### Community 831 - "vss-setup-behavior-analytics"
Cohesion: 0.67
Nodes (3): vss-setup-behavior-analytics, Behavior Analytics Config, Dynamic Configuration

### Community 1337 - "enum"
Cohesion: 0.17
Nodes (12): approved_full_sweep, full, masked_stage_spot_check, minimum_openability, no_op, targeted, structural_only, workflow_mode (+4 more)

### Community 1338 - "apply-restructure-manifest.schema.json"
Cohesion: 0.20
Nodes (9): phase4_targets, allOf, $comment, description, mode, required, $schema, title (+1 more)

### Community 1339 - "properties"
Cohesion: 0.22
Nodes (9): type, type, type, defaultPrim, identifier, openedWith, rootLayer, type (+1 more)

### Community 1340 - "properties"
Cohesion: 0.22
Nodes (9): properties, type, type, type, type, gates, mutationPolicy, postValidation (+1 more)

### Community 1341 - "enum"
Cohesion: 0.33
Nodes (6): cheap, expensive, medium, stage_dependent, enum, cost_class

## Knowledge Gaps
- **4625 isolated node(s):** `benchmark-ds.sh script`, `ds-kitti-dump.sh script`, `ds-perf-run.sh script`, `ds-single-stream.sh script`, `ds-sweep.sh script` (+4620 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **505 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `Evaluate` connect `Evaluate` to `gen_trt_engine.tensorrt.calibration`, `gen_trt_engine`, `AutoML Augmentation Params`, `automl_disabled_parameters`, `automl_disabled_parameters`, `automl_disabled_parameters`, `automl_disabled_parameters`, `Image Classification Training`, `automl_disabled_parameters`, `automl_disabled_parameters`, `Mask2Former Deploy Skill`, `automl_disabled_parameters`?**
  _High betweenness centrality (0.122) - this node is a cross-community bridge._
- **Why does `automl_disabled_parameters` connect `automl_disabled_parameters` to `required`, `train`, `required`?**
  _High betweenness centrality (0.120) - this node is a cross-community bridge._
- **Why does `train` connect `train` to `inference`, `automl_disabled_parameters`?**
  _High betweenness centrality (0.120) - this node is a cross-community bridge._
- **What connects `benchmark-ds.sh script`, `ds-kitti-dump.sh script`, `ds-perf-run.sh script` to the rest of the system?**
  _4625 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Evaluate` be split into smaller, more focused modules?**
  _Cohesion score 0.08027184083522111 - nodes in this community are weakly interconnected._
- **Should `train.optim.lr` be split into smaller, more focused modules?**
  _Cohesion score 0.10196078431372549 - nodes in this community are weakly interconnected._
- **Should `properties` be split into smaller, more focused modules?**
  _Cohesion score 0.026557711950970377 - nodes in this community are weakly interconnected._