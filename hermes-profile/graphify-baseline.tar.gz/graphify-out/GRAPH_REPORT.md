# Graph Report - .  (2026-07-18)

## Corpus Check
- Large corpus: 3036 files · ~3,187,329 words. Semantic extraction will be expensive (many Claude tokens). Consider running on a subfolder.

## Summary
- 16977 nodes · 28547 edges · 1522 communities (988 shown, 534 thin omitted)
- Extraction: 96% EXTRACTED · 4% INFERRED · 0% AMBIGUOUS · INFERRED: 1059 edges (avg confidence: 0.78)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- TAO Dataset Spec
- TAO Manifest Actions
- TAO Augmentation Config
- TAO Classify Augmentation
- AIQ Python Client
- Sensor Calibration Config
- Manifest Validator
- Train Eval Config
- TAO Action Pipeline
- Augmentation Dimensions
- Normalization Config
- TAO CLI Entry Points
- Classify Augmentation
- Script Entry Points
- TAO Spec Manifest
- Distributed Training Config
- Inference Config
- Training Hyperparameters
- DT Generator Scripts
- TAO Run Logic
- CUDA/GPU Config
- Docker Container Build
- Model Export Config
- API Client
- Jetson BSP Config
- Plugin Management
- DeepStream Config
- HuggingFace Skills
- Data Processing
- ML Training Pipeline
- Community 30
- Community 31
- Community 32
- Community 33
- Community 34
- Community 35
- Community 36
- Community 37
- Community 38
- Community 39
- Community 40
- Community 41
- Community 42
- Community 43
- Community 44
- Community 45
- Community 46
- Community 47
- Community 48
- Community 49
- Community 50
- Community 51
- Community 52
- Community 53
- Community 54
- Community 55
- Community 56
- Community 57
- Community 58
- Community 59
- Community 60
- Community 61
- Community 62
- Community 63
- Community 64
- Community 65
- Community 66
- Community 67
- Community 68
- Community 69
- Community 70
- Community 71
- Community 72
- Community 73
- Community 74
- Community 75
- Community 76
- Community 77
- Community 78
- Community 79
- Community 80
- Community 81
- Community 82
- Community 83
- Community 84
- Community 85
- Community 86
- Community 87
- Community 88
- Community 89
- Community 90
- Community 91
- Community 92
- Community 93
- Community 94
- Community 95
- Community 96
- Community 97
- Community 98
- Community 99
- Community 100
- Community 101
- Community 102
- Community 103
- Community 104
- Community 105
- Community 106
- Community 107
- Community 108
- Community 109
- Community 110
- Community 111
- Community 112
- Community 113
- Community 114
- Community 115
- Community 116
- Community 117
- Community 118
- Community 119
- Community 120
- Community 121
- Community 122
- Community 123
- Community 124
- Community 125
- Community 126
- Community 127
- Community 128
- Community 129
- Community 130
- Community 131
- Community 132
- Community 133
- Community 134
- Community 135
- Community 136
- Community 137
- Community 138
- Community 139
- Community 140
- Community 141
- Community 142
- Community 143
- Community 144
- Community 145
- Community 146
- Community 147
- Community 148
- Community 149
- Community 150
- Community 151
- Community 152
- Community 153
- Community 154
- Community 155
- Community 156
- Community 157
- Community 158
- Community 159
- Community 160
- Community 161
- Community 162
- Community 163
- Community 164
- Community 165
- Community 166
- Community 167
- Community 168
- Community 169
- Community 170
- Community 171
- Community 172
- Community 173
- Community 174
- Community 175
- Community 176
- Community 177
- Community 178
- Community 179
- Community 180
- Community 181
- Community 182
- Community 183
- Community 184
- Community 185
- Community 186
- Community 187
- Community 188
- Community 189
- Community 190
- Community 191
- Community 192
- Community 193
- Community 194
- Community 195
- Community 196
- Community 197
- Community 198
- Community 199
- Community 200
- Community 201
- Community 202
- Community 203
- Community 204
- Community 205
- Community 206
- Community 207
- Community 208
- Community 209
- Community 210
- Community 211
- Community 212
- Community 213
- Community 214
- Community 215
- Community 216
- Community 217
- Community 218
- Community 219
- Community 220
- Community 221
- Community 222
- Community 223
- Community 224
- Community 225
- Community 226
- Community 227
- Community 228
- Community 229
- Community 230
- Community 231
- Community 232
- Community 233
- Community 234
- Community 235
- Community 236
- Community 237
- Community 238
- Community 239
- Community 240
- Community 241
- Community 242
- Community 243
- Community 244
- Community 245
- Community 246
- Community 247
- Community 248
- Community 249
- Community 250
- Community 251
- Community 252
- Community 253
- Community 254
- Community 255
- Community 256
- Community 257
- Community 258
- Community 259
- Community 260
- Community 261
- Community 262
- Community 263
- Community 264
- Community 265
- Community 266
- Community 267
- Community 268
- Community 269
- Community 270
- Community 271
- Community 272
- Community 273
- Community 274
- Community 275
- Community 276
- Community 277
- Community 278
- Community 279
- Community 280
- Community 281
- Community 282
- Community 283
- Community 284
- Community 285
- Community 286
- Community 287
- Community 288
- Community 289
- Community 290
- Community 291
- Community 292
- Community 293
- Community 294
- Community 295
- Community 296
- Community 297
- Community 298
- Community 299
- Community 300
- Community 301
- Community 302
- Community 303
- Community 304
- Community 305
- Community 306
- Community 307
- Community 308
- Community 309
- Community 310
- Community 311
- Community 312
- Community 313
- Community 314
- Community 315
- Community 316
- Community 317
- Community 318
- Community 319
- Community 320
- Community 321
- Community 322
- Community 323
- Community 324
- Community 325
- Community 326
- Community 327
- Community 328
- Community 329
- Community 330
- Community 331
- Community 332
- Community 333
- Community 334
- Community 335
- Community 336
- Community 337
- Community 338
- Community 339
- Community 340
- Community 341
- Community 342
- Community 343
- Community 344
- Community 345
- Community 346
- Community 347
- Community 348
- Community 349
- Community 350
- Community 351
- Community 352
- Community 353
- Community 354
- Community 355
- Community 356
- Community 357
- Community 358
- Community 359
- Community 360
- Community 361
- Community 362
- Community 363
- Community 364
- Community 365
- Community 366
- Community 367
- Community 368
- Community 369
- Community 370
- Community 371
- Community 372
- Community 373
- Community 374
- Community 375
- Community 376
- Community 377
- Community 378
- Community 379
- Community 380
- Community 381
- Community 382
- Community 383
- Community 384
- Community 385
- Community 386
- Community 387
- Community 388
- Community 389
- Community 390
- Community 391
- Community 393
- Community 394
- Community 395
- Community 396
- Community 397
- Community 398
- Community 399
- Community 400
- Community 401
- Community 402
- Community 403
- Community 404
- Community 405
- Community 406
- Community 407
- Community 408
- Community 409
- Community 410
- Community 411
- Community 412
- Community 413
- Community 414
- Community 415
- Community 416
- Community 417
- Community 418
- Community 419
- Community 420
- Community 421
- Community 422
- Community 423
- Community 424
- Community 425
- Community 426
- Community 427
- Community 428
- Community 429
- Community 430
- Community 431
- Community 432
- Community 433
- Community 434
- Community 435
- Community 436
- Community 437
- Community 438
- Community 439
- Community 440
- Community 441
- Community 442
- Community 443
- Community 444
- Community 445
- Community 446
- Community 447
- Community 448
- Community 449
- Community 450
- Community 451
- Community 452
- Community 453
- Community 454
- Community 455
- Community 456
- Community 457
- Community 458
- Community 459
- Community 460
- Community 461
- Community 462
- Community 463
- Community 464
- Community 465
- Community 466
- Community 467
- Community 468
- Community 469
- Community 470
- Community 471
- Community 472
- Community 473
- Community 474
- Community 475
- Community 476
- Community 477
- Community 478
- Community 479
- Community 480
- Community 481
- Community 482
- Community 483
- Community 484
- Community 485
- Community 486
- Community 487
- Community 488
- Community 489
- Community 490
- Community 491
- Community 492
- Community 493
- Community 494
- Community 495
- Community 496
- Community 497
- Community 498
- Community 499
- Community 500
- Community 501
- Community 502
- Community 503
- Community 504
- Community 505
- Community 506
- Community 507
- Community 508
- Community 509
- Community 510
- Community 511
- Community 512
- Community 513
- Community 514
- Community 515
- Community 516
- Community 517
- Community 518
- Community 519
- Community 520
- Community 521
- Community 522
- Community 523
- Community 524
- Community 525
- Community 526
- Community 527
- Community 528
- Community 529
- Community 530
- Community 531
- Community 532
- Community 533
- Community 534
- Community 535
- Community 536
- Community 537
- Community 538
- Community 539
- Community 540
- Community 541
- Community 542
- Community 543
- Community 544
- Community 545
- Community 546
- Community 547
- Community 548
- Community 549
- Community 550
- Community 551
- Community 552
- Community 553
- Community 554
- Community 555
- Community 556
- Community 557
- Community 558
- Community 559
- Community 560
- Community 561
- Community 562
- Community 563
- Community 564
- Community 565
- Community 566
- Community 567
- Community 568
- Community 569
- Community 570
- Community 571
- Community 572
- Community 573
- Community 574
- Community 575
- Community 576
- Community 577
- Community 578
- Community 579
- Community 580
- Community 581
- Community 582
- Community 583
- Community 584
- Community 585
- Community 586
- Community 587
- Community 588
- Community 589
- Community 590
- Community 591
- Community 592
- Community 593
- Community 594
- Community 595
- Community 596
- Community 597
- Community 598
- Community 599
- Community 600
- Community 601
- Community 602
- Community 603
- Community 604
- Community 605
- Community 606
- Community 607
- Community 608
- Community 609
- Community 610
- Community 611
- Community 612
- Community 613
- Community 614
- Community 615
- Community 616
- Community 617
- Community 618
- Community 619
- Community 620
- Community 621
- Community 622
- Community 623
- Community 624
- Community 625
- Community 626
- Community 627
- Community 628
- Community 629
- Community 630
- Community 631
- Community 632
- Community 633
- Community 634
- Community 635
- Community 636
- Community 637
- Community 638
- Community 639
- Community 640
- Community 641
- Community 642
- Community 643
- Community 644
- Community 645
- Community 646
- Community 647
- Community 648
- Community 649
- Community 650
- Community 651
- Community 652
- Community 653
- Community 654
- Community 655
- Community 656
- Community 657
- Community 658
- Community 659
- Community 660
- Community 661
- Community 662
- Community 663
- Community 664
- Community 665
- Community 666
- Community 667
- Community 668
- Community 669
- Community 670
- Community 671
- Community 672
- Community 673
- Community 674
- Community 675
- Community 676
- Community 677
- Community 678
- Community 679
- Community 680
- Community 681
- Community 682
- Community 683
- Community 684
- Community 685
- Community 686
- Community 687
- Community 688
- Community 689
- Community 690
- Community 691
- Community 692
- Community 693
- Community 694
- Community 695
- Community 696
- Community 697
- Community 698
- Community 699
- Community 700
- Community 701
- Community 702
- Community 703
- Community 704
- Community 705
- Community 706
- Community 707
- Community 708
- Community 709
- Community 710
- Community 711
- Community 712
- Community 713
- Community 714
- Community 715
- Community 716
- Community 717
- Community 718
- Community 719
- Community 720
- Community 721
- Community 722
- Community 723
- Community 724
- Community 725
- Community 726
- Community 727
- Community 728
- Community 729
- Community 730
- Community 731
- Community 732
- Community 733
- Community 734
- Community 735
- Community 736
- Community 737
- Community 738
- Community 739
- Community 740
- Community 741
- Community 742
- Community 743
- Community 744
- Community 745
- Community 746
- Community 747
- Community 748
- Community 749
- Community 750
- Community 751
- Community 752
- Community 753
- Community 754
- Community 755
- Community 756
- Community 757
- Community 758
- Community 759
- Community 760
- Community 761
- Community 762
- Community 763
- Community 764
- Community 765
- Community 766
- Community 767
- Community 768
- Community 769
- Community 770
- Community 771
- Community 772
- Community 773
- Community 774
- Community 775
- Community 776
- Community 777
- Community 778
- Community 779
- Community 780
- Community 781
- Community 782
- Community 783
- Community 784
- Community 785
- Community 786
- Community 787
- Community 788
- Community 789
- Community 790
- Community 791
- Community 792
- Community 793
- Community 794
- Community 795
- Community 796
- Community 797
- Community 798
- Community 799
- Community 800
- Community 801
- Community 802
- Community 803
- Community 804
- Community 805
- Community 806
- Community 807
- Community 808
- Community 809
- Community 810
- Community 811
- Community 812
- Community 813
- Community 814
- Community 815
- Community 816
- Community 817
- Community 818
- Community 819
- Community 820
- Community 821
- Community 822
- Community 823
- Community 824
- Community 825
- Community 826
- Community 827
- Community 828
- Community 829
- Community 830
- Community 831
- Community 832
- Community 833
- Community 834
- Community 835
- Community 836
- Community 837
- Community 838
- Community 839
- Community 840
- Community 841
- Community 842
- Community 843
- Community 844
- Community 845
- Community 846
- Community 847
- Community 848
- Community 849
- Community 850
- Community 851
- Community 852
- Community 853
- Community 854
- Community 855
- Community 856
- Community 857
- Community 858
- Community 859
- Community 860
- Community 861
- Community 862
- Community 863
- Community 864
- Community 865
- Community 866
- Community 867
- Community 868
- Community 869
- Community 870
- Community 871
- Community 872
- Community 873
- Community 874
- Community 875
- Community 876
- Community 877
- Community 878
- Community 879
- Community 880
- Community 881
- Community 882
- Community 883
- Community 884
- Community 885
- Community 886
- Community 887
- Community 889
- Community 890
- Community 891
- Community 892
- Community 893
- Community 894
- Community 895
- Community 896
- Community 897
- Community 898
- Community 899
- Community 900
- Community 901
- Community 902
- Community 903
- Community 904
- Community 905
- Community 906
- Community 907
- Community 908
- Community 909
- Community 910
- Community 911
- Community 912
- Community 913
- Community 914
- Community 915
- Community 916
- Community 917
- Community 918
- Community 919
- Community 920
- Community 921
- Community 922
- Community 923
- Community 924
- Community 925
- Community 926
- Community 927
- Community 928
- Community 929
- Community 930
- Community 931
- Community 932
- Community 933
- Community 934
- Community 935
- Community 936
- Community 937
- Community 938
- Community 939
- Community 940
- Community 941
- Community 942
- Community 943
- Community 944
- Community 945
- Community 946
- Community 947
- Community 948
- Community 949
- Community 950
- Community 951
- Community 952
- Community 953
- Community 954
- Community 955
- Community 956
- Community 957
- Community 958
- Community 959
- Community 960
- Community 961
- Community 962
- Community 963
- Community 964
- Community 965
- Community 966
- Community 967
- Community 968
- Community 969
- Community 970
- Community 971
- Community 972
- Community 973
- Community 974
- Community 975
- Community 976
- Community 977
- Community 978
- Community 979
- Community 980
- Community 981
- Community 982
- Community 983
- Community 984
- Community 985
- Community 986
- Community 987
- Community 988
- Community 989
- Community 990
- Community 991
- Community 992
- Community 993
- Community 994
- Community 995
- Community 996
- Community 997
- Community 998
- Community 999
- Community 1000
- Community 1001
- Community 1002
- Community 1003
- Community 1004
- Community 1005
- Community 1006
- Community 1007
- Community 1008
- Community 1009
- Community 1022
- Community 1023
- Community 1025
- Community 1026
- Community 1027
- Community 1028
- Community 1029
- Community 1030
- Community 1031
- Community 1032
- Community 1033
- Community 1034
- Community 1035
- Community 1036
- Community 1037
- Community 1038
- Community 1039
- Community 1040
- Community 1042
- Community 1043
- Community 1045
- Community 1046
- Community 1049
- Community 1050
- Community 1054
- Community 1055
- Community 1056
- Community 1057
- Community 1058
- Community 1059
- Community 1060
- Community 1061
- Community 1062
- Community 1063
- Community 1064
- Community 1065
- Community 1066
- Community 1067
- Community 1068
- Community 1069
- Community 1070
- Community 1071
- Community 1072
- Community 1073
- Community 1074
- Community 1075
- Community 1076
- Community 1078
- Community 1079
- Community 1080
- Community 1081
- Community 1082
- Community 1083
- Community 1085
- Community 1086
- Community 1087
- Community 1088
- Community 1089
- Community 1090
- Community 1091
- Community 1092
- Community 1093
- Community 1094
- Community 1095
- Community 1106
- Community 1107
- Community 1108
- Community 1109
- Community 1110
- Community 1111
- Community 1112
- Community 1113
- Community 1114
- Community 1115
- Community 1116
- Community 1117
- Community 1118
- Community 1119
- Community 1120
- Community 1121
- Community 1122
- Community 1123
- Community 1124
- Community 1125
- Community 1126
- Community 1127
- Community 1128
- Community 1129
- Community 1130
- Community 1131
- Community 1132
- Community 1133
- Community 1134
- Community 1135
- Community 1136
- Community 1137
- Community 1138
- Community 1139
- Community 1140
- Community 1141
- Community 1142
- Community 1143
- Community 1144
- Community 1145
- Community 1146
- Community 1147
- Community 1148
- Community 1149
- Community 1150
- Community 1151
- Community 1152
- Community 1153
- Community 1154
- Community 1155
- Community 1156
- Community 1157
- Community 1158
- Community 1159
- Community 1160
- Community 1161
- Community 1162
- Community 1163
- Community 1164
- Community 1165
- Community 1166
- Community 1167
- Community 1168
- Community 1169
- Community 1170
- Community 1171
- Community 1172
- Community 1173
- Community 1174
- Community 1175
- Community 1176
- Community 1177
- Community 1178
- Community 1179
- Community 1180
- Community 1181
- Community 1182
- Community 1183
- Community 1187
- Community 1188
- Community 1191
- Community 1192
- Community 1193
- Community 1194
- Community 1195
- Community 1196
- Community 1197
- Community 1198
- Community 1199
- Community 1200
- Community 1201
- Community 1202
- Community 1203
- Community 1204
- Community 1205
- Community 1206
- Community 1207
- Community 1208
- Community 1209
- Community 1210
- Community 1211
- Community 1212
- Community 1213
- Community 1214
- Community 1216
- Community 1219
- Community 1221
- Community 1223
- Community 1224
- Community 1226
- Community 1227
- Community 1228
- Community 1229
- Community 1230
- Community 1231
- Community 1232
- Community 1233
- Community 1234
- Community 1235
- Community 1236
- Community 1237
- Community 1238
- Community 1239
- Community 1240
- Community 1241
- Community 1242
- Community 1243
- Community 1244
- Community 1245
- Community 1246
- Community 1247
- Community 1252
- Community 1253
- Community 1254
- Community 1255
- Community 1256
- Community 1257
- Community 1258
- Community 1259
- Community 1260
- Community 1261
- Community 1262
- Community 1263
- Community 1264
- Community 1265
- Community 1266
- Community 1267
- Community 1268
- Community 1269
- Community 1270
- Community 1271
- Community 1272
- Community 1273
- Community 1274
- Community 1275
- Community 1276
- Community 1277
- Community 1278
- Community 1279
- Community 1280
- Community 1281
- Community 1282
- Community 1283
- Community 1284
- Community 1285
- Community 1286
- Community 1287
- Community 1288
- Community 1289
- Community 1290
- Community 1291
- Community 1292
- Community 1293
- Community 1294
- Community 1295
- Community 1296
- Community 1297
- Community 1298
- Community 1299
- Community 1300
- Community 1301
- Community 1302
- Community 1303
- Community 1304
- Community 1305
- Community 1306
- Community 1307
- Community 1308
- Community 1309
- Community 1310
- Community 1311
- Community 1312
- Community 1313
- Community 1314
- Community 1315
- Community 1316
- Community 1317
- Community 1318
- Community 1319
- Community 1320
- Community 1322
- Community 1323
- Community 1324
- Community 1325
- Community 1326
- Community 1327
- Community 1328
- Community 1329
- Community 1330
- Community 1331
- Community 1332
- Community 1333
- Community 1334
- Community 1335
- Community 1336
- Community 1337
- Community 1338
- Community 1339
- Community 1340
- Community 1341
- Community 1342
- Community 1343
- Community 1344
- Community 1345
- Community 1346
- Community 1347
- Community 1348
- Community 1349
- Community 1350
- Community 1351
- Community 1352
- Community 1353
- Community 1354
- Community 1355
- Community 1356
- Community 1357
- Community 1358
- Community 1359
- Community 1360
- Community 1361
- Community 1362
- Community 1363
- Community 1364
- Community 1365
- Community 1366
- Community 1367
- Community 1368
- Community 1369
- Community 1370
- Community 1371
- Community 1372
- Community 1373
- Community 1374
- Community 1375
- Community 1376
- Community 1377
- Community 1378
- Community 1379
- Community 1380
- Community 1381
- Community 1382
- Community 1383
- Community 1384
- Community 1385
- Community 1386
- Community 1387
- Community 1388
- Community 1389
- Community 1390
- Community 1391
- Community 1392
- Community 1393
- Community 1394
- Community 1395
- Community 1396
- Community 1397
- Community 1398
- Community 1399
- Community 1400
- Community 1401
- Community 1402
- Community 1403
- Community 1404
- Community 1405
- Community 1406
- Community 1407
- Community 1408
- Community 1409
- Community 1410
- Community 1411
- Community 1412
- Community 1413
- Community 1414
- Community 1415
- Community 1416
- Community 1417
- Community 1418
- Community 1419
- Community 1420
- Community 1421
- Community 1422
- Community 1423
- Community 1424
- Community 1425
- Community 1426
- Community 1427
- Community 1428
- Community 1429
- Community 1430
- Community 1431
- Community 1432
- Community 1433
- Community 1434
- Community 1435
- Community 1436
- Community 1437
- Community 1438
- Community 1439
- Community 1440
- Community 1441
- Community 1442
- Community 1443
- Community 1444
- Community 1445
- Community 1446
- Community 1447
- Community 1448
- Community 1449
- Community 1450
- Community 1451
- Community 1452
- Community 1453
- Community 1454
- Community 1455
- Community 1456
- Community 1457
- Community 1458
- Community 1459
- Community 1460
- Community 1461
- Community 1462
- Community 1463
- Community 1464
- Community 1465
- Community 1466
- Community 1467
- Community 1468
- Community 1469
- Community 1470
- Community 1471
- Community 1472
- Community 1473
- Community 1474
- Community 1475
- Community 1476
- Community 1477
- Community 1478
- Community 1479
- Community 1480
- Community 1481
- Community 1482
- Community 1483
- Community 1484
- Community 1485
- Community 1486
- Community 1487
- Community 1488
- Community 1489
- Community 1490
- Community 1491
- Community 1492
- Community 1493
- Community 1494
- Community 1495
- Community 1496
- Community 1497
- Community 1498
- Community 1499
- Community 1500
- Community 1501
- Community 1502
- Community 1503
- Community 1504
- Community 1505
- Community 1506
- Community 1507
- Community 1508
- Community 1509
- Community 1510
- Community 1511
- Community 1512
- Community 1513
- Community 1514
- Community 1515
- Community 1516
- Community 1517
- Community 1518
- Community 1519
- Community 1520
- Community 1521

## God Nodes (most connected - your core abstractions)
1. `automl_disabled_parameters` - 86 edges
2. `automl_disabled_parameters` - 86 edges
3. `automl_disabled_parameters` - 86 edges
4. `automl_disabled_parameters` - 73 edges
5. `automl_disabled_parameters` - 73 edges
6. `automl_disabled_parameters` - 73 edges
7. `automl_disabled_parameters` - 73 edges
8. `automl_disabled_parameters` - 73 edges
9. `automl_disabled_parameters` - 64 edges
10. `automl_disabled_parameters` - 64 edges

## Surprising Connections (you probably didn't know these)
- `Sage MCP Server` --semantically_similar_to--> `Sage MCP Server`  [INFERRED] [semantically similar]
  SOUL.md → mcp.json
- `sage Distribution` --semantically_similar_to--> `Hermes Profile Distribution`  [INFERRED] [semantically similar]
  distribution.yaml → README.md
- `Ollama Inference` --semantically_similar_to--> `Ollama Provider`  [INFERRED] [semantically similar]
  SOUL.md → config.yaml
- `Sage MCP Server` --references--> `Sage MCP Server`  [EXTRACTED]
  README.md → mcp.json
- `Milvus SDK Code Helper` --references--> `Milvus SDK Code Helper`  [EXTRACTED]
  README.md → mcp.json

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Sage Profile Core Components** — SOUL_md, AGENTS_md, config_yaml, distribution_yaml, mcp_json [EXTRACTED 1.00]
- **Graphify Discovery Ecosystem** — AGENTS_md_graphify, AGENTS_md_graphify_skill, AGENTS_md_setup_graphify_sh, AGENTS_md_graphify_out_graph_json, AGENTS_md_graphify_venv [EXTRACTED 1.00]
- **NVIDIA Taxonomy Routing Lanes** — skills_nvidia_skill_finder_Agentic_AI, skills_nvidia_skill_finder_Physical_AI, skills_nvidia_skill_finder_Robotics, skills_nvidia_skill_finder_Vision_AI, skills_nvidia_skill_finder_Conversational_AI, skills_nvidia_skill_finder_Simulation_Modeling, skills_nvidia_skill_finder_Data_Science, skills_nvidia_skill_finder_Training_AI, skills_nvidia_skill_finder_Inference_AI, skills_nvidia_skill_finder_Decision_Optimization, skills_nvidia_skill_finder_GPU_Development, skills_nvidia_skill_finder_Quantum_Computing, skills_nvidia_skill_finder_Infrastructure, skills_nvidia_skill_finder_Networking [EXTRACTED 1.00]
- **cuOpt Solver Interfaces** — skills_cuopt_numerical_optimization_api_assets_c, skills_cuopt_numerical_optimization_api_assets_cli, skills_cuopt_numerical_optimization_api_assets_python [EXTRACTED 1.00]
- **LP Examples Across Interfaces** — skills_cuopt_numerical_optimization_api_assets_python_lp_basic, skills_cuopt_numerical_optimization_api_assets_c_lp_basic, skills_cuopt_numerical_optimization_api_assets_cli_lp_simple [EXTRACTED 1.00]
- **MILP Examples Across Interfaces** — skills_cuopt_numerical_optimization_api_assets_python_milp_basic, skills_cuopt_numerical_optimization_api_assets_c_milp_basic, skills_cuopt_numerical_optimization_api_assets_cli_milp_facility [EXTRACTED 1.00]
- **cuOpt Numerical Optimization API Ecosystem** — skills_cuopt_numerical_optimization_api_references_c_api, skills_cuopt_numerical_optimization_api_references_cli_api, skills_cuopt_numerical_optimization_api_references_python_api, skills_cuopt_numerical_optimization_api_assets_python_mps_solver_readme, skills_cuopt_numerical_optimization_api_assets_python_portfolio_readme [EXTRACTED 0.85]
- **cuOpt Routing API Ecosystem** — skills_cuopt_routing_api_python_skill, skills_cuopt_routing_api_python_references_examples, skills_cuopt_routing_api_python_references_server_examples, skills_cuopt_routing_api_python_assets_vrp_basic_readme, skills_cuopt_routing_api_python_assets_pdp_basic_readme [EXTRACTED 0.85]
- **Optimization Problem Types** — linear_programming, mixed_integer_linear_programming, quadratic_programming [INFERRED 0.75]
- **cuOpt REST API Optimization Problem Types** — skills_cuopt_server_api_python_assets_vrp_simple_readme, skills_cuopt_server_api_python_assets_vrp_basic_readme, skills_cuopt_server_api_python_assets_pdp_basic_readme, skills_cuopt_server_api_python_assets_lp_basic_readme, skills_cuopt_server_api_python_assets_milp_basic_readme [EXTRACTED 1.00]
- **cuPyNumeric Skills Ecosystem** — skills_cupynumeric_hdf5_skill, skills_cupynumeric_install_skill, skills_cupynumeric_migration_readiness_skill [EXTRACTED 1.00]
- **Migration Readiness Reference Documentation** — skills_cupynumeric_migration_readiness_references_getting_started, skills_cupynumeric_migration_readiness_references_decision_framework, skills_cupynumeric_migration_readiness_references_execution_model, skills_cupynumeric_migration_readiness_references_case_studies [EXTRACTED 0.95]
- **GPU Stack Architecture** — skills_cupynumeric_migration_readiness_references_gpu_stack_memory_hierarchy, skills_cupynumeric_migration_readiness_references_gpu_stack_sm_utilization, skills_cupynumeric_migration_readiness_references_gpu_stack_communication_fabric, skills_cupynumeric_migration_readiness_references_gpu_stack_task_dispatch [EXTRACTED 1.00]
- **Python Loop Blocking Patterns** — skills_cupynumeric_migration_readiness_references_idioms_that_block_r101, skills_cupynumeric_migration_readiness_references_idioms_that_block_r102, skills_cupynumeric_migration_readiness_references_idioms_that_block_r103, skills_cupynumeric_migration_readiness_references_idioms_that_block_r110 [EXTRACTED 1.00]
- **Refactor Recipe Coverage** — skills_cupynumeric_migration_readiness_references_refactor_recipes_rr_loop, skills_cupynumeric_migration_readiness_references_refactor_recipes_rr_where, skills_cupynumeric_migration_readiness_references_refactor_recipes_rr_sync, skills_cupynumeric_migration_readiness_references_refactor_recipes_rr_alloc, skills_cupynumeric_migration_readiness_references_refactor_recipes_rr_inplace, skills_cupynumeric_migration_readiness_references_refactor_recipes_rr_stack, skills_cupynumeric_migration_readiness_references_refactor_recipes_rr_mask [EXTRACTED 1.00]
- **DeepStream Video Analytics Stack** — pyservicemaker, nvstreammux, nvinfer, nvtracker, nvosdbin, nvmultiurisrcbin [EXTRACTED 1.00]
- **Pipeline Builder Components** — gst_launch_1_0, bm25_retriever, pipeline_validation, deepstream_generate_pipeline_assembly_rules, deepstream_generate_pipeline_requirement_extraction [EXTRACTED 1.00]
- **Source Ingestion and Extraction APIs** — buffer_provider_feeder, buffer_retriever_receiver, media_extractor, nvurisrcbin [EXTRACTED 1.00]
- **DeepStream Import Vision Model End-to-End Workflow** — skills_deepstream_import_vision_model_skill, skills_deepstream_import_vision_model_references_model_acquire_pipeline, trtexec_engine_build, custom_bbox_parser, deepstream_benchmark, benchmark_report_generation [EXTRACTED 1.00]
- **DeepStream Profile Pipeline Six-Stage Flow** — skills_deepstream_profile_pipeline_skill, six_stage_profiling_flow, hw_ceiling_discovery, boundedness_classification, skills_deepstream_profile_pipeline_references_config_derivation_rules, capacity_report [EXTRACTED 1.00]
- **Pipeline Boundedness Analysis Concepts** — decode_bound, compute_bound, memory_bandwidth_bound, nvdc_f_tracker, microbench_scaling, nvidia_smi_dmon [EXTRACTED 0.85]
- **DeepStream SOP 4-Stage Pipeline Architecture** — stage1_deepstream_gebd, stage2_clip_post_process, stage3_vlm_inference, stage4_sop_checker [EXTRACTED 1.00]
- **SOP Process Manager Components** — nvds_action_detector_sop_process_manager, nvds_action_detector_model_initializer, nvds_action_detector_vllm_inference, thread_pool_architecture [EXTRACTED 1.00]
- **DDM Configuration System** — nvdspreprocess_config, nvinferserver_config, sliding_window_size, frames_per_side, sequence_batch [EXTRACTED 1.00]
- **DICOM Pipeline Workflow (Metadata -> Preflight -> Volume)** — skills_dicom_metadata_extract_skill, skills_dicom_series_preflight_skill, skills_dicom_series_to_volume_skill [EXTRACTED 1.00]
- **DeepStream SOP Latency Measurement Tools** — concept_ttfc, concept_c2c, concept_chunk_e2e, skills_deepstream_sop_references_skill_15_latency_measurement, skills_deepstream_sop_references_skill_17_camera_latency_measurement [EXTRACTED 1.00]
- **DICOM Skills Shared Dependencies** — concept_pydicom, concept_nibabel, skills_dicom_metadata_extract_skill_manifest, skills_dicom_series_preflight_skill_manifest, skills_dicom_series_to_volume_skill_manifest [EXTRACTED 1.00]
- **VSS Video Embedding Deployment Stack** — rtvi_embed_microservice, cosmos_embed1_448p_model, triton_inference_server, docker_compose_deployment [EXTRACTED 1.00]
- **VSS Camera Calibration Integration Surface** — automagic_calib_amc, skills_vss_generate_video_calibration_references_rtsp_capture, vios_video_io_storage, calibration_alignment_data, calibration_layout_image [EXTRACTED 1.00]
- **VSS Video Embedding Peer Service Integrations** — rtvi_embed_microservice, kafka_broker, redis_cache, opentelemetry_monitoring [EXTRACTED 1.00]
- **VSS Video Report Generation Workflow** — vss_generate_video_report, vss_manage_video_io_storage, vss_query_analytics, vss_deploy_profile, vss_generate_video_report_video_analysis_report_template, vss_generate_video_report_incident_range_report_template [EXTRACTED 1.00]
- **VSS Alert Pipeline** — vss_manage_alerts, vss_manage_video_io_storage, vss_query_analytics, alert_bridge, rtvi_vlm, vss_agent, vss_manage_alerts_alert_notify, vss_manage_alerts_alert_subscriptions [EXTRACTED 1.00]
- **VIOS Service Ecosystem** — vios, sdr_controller, vss_manage_video_io_storage, vss_manage_video_io_storage_api_reference, vss_manage_video_io_storage_deploy_vios_service, vss_manage_video_io_storage_integrate_vios_service, vss_manage_video_io_storage_nvstreamer_api_reference, nvstreamer [EXTRACTED 1.00]
- **VSS Analytics Stack Components** — vss_behavior_analytics_service, vss_video_analytics_api_service, va_mcp_server [EXTRACTED 1.00]
- **Dynamic Runtime Updates via Kafka** — skills_vss_setup_behavior_analytics_references_dynamic_config, skills_vss_setup_behavior_analytics_references_dynamic_calibration, kafka [EXTRACTED 1.00]
- **Behavior Analytics Configuration and Calibration** — app_config, calibration_base, vss_setup_behavior_analytics_configuration [EXTRACTED 0.85]
- **VSS Video Summarization Skill Ecosystem** — skills_vss_summarize_video_skill, lvs_microservice, hitl_human_in_the_loop, vlm_fallback, vss_deploy_profile, vss_manage_video_io_storage [EXTRACTED 0.95]
- **LVS Database Backend Options** — elasticsearch_db_backend, neo4j_graph_backend, arangodb_graph_backend, lvs_microservice [EXTRACTED 0.95]
- **HF Paper Publishing Workflow** — skills_huggingface_papers_skill, hf_papers_api, arxiv_id, paper_manager_py, huggingface_paper_publisher_templates_arxiv [EXTRACTED 0.95]
- **Clinical ASR Flywheel Four-Stage Pipeline** — skills_digital_health_clinical_asr_setup_skill, skills_digital_health_clinical_asr_build_skill, skills_digital_health_clinical_asr_eval_skill, skills_digital_health_clinical_asr_finetune_skill [EXTRACTED 1.00]
- **Clinical ASR Evaluation Metrics** — ker [EXTRACTED 1.00]
- **Disaggregated Serving Fabric Stack** — nixl_ucx_transport, nccl_collective, disaggregated_serving [EXTRACTED 1.00]
- **Dynamo Deployment Workflow** — skills_dynamo_recipe_runner_skill, skills_dynamo_router_starter_skill, skills_dynamo_troubleshoot_skill [EXTRACTED 0.95]
- **Earth2Studio Create Workflow** — skills_earth2studio_create_datasource_skill, skills_earth2studio_create_diagnostic_skill, earth2studio_create_datasource_validation_guide [EXTRACTED 0.95]
- **Dynamo Skills Ecosystem** — skills_dynamo_recipe_runner_skill, skills_dynamo_router_starter_skill, skills_dynamo_troubleshoot_skill, skills_dynamo_interconnect_check_skill_card, recipe_tool_py, check_router_health_py, collect_dynamo_debug_bundle_py [INFERRED 0.85]
- **Earth2Studio Skill Workflow Chain** — skills_earth2studio_install_skill, skills_earth2studio_discover_skill, skills_earth2studio_data_fetch_skill, skills_earth2studio_create_prognostic_skill, skills_earth2studio_deterministic_forecast_skill, skills_earth2studio_create_diagnostic_skill_card [EXTRACTED 0.85]
- **Skill Documentation Bundle Pattern** — skills_earth2studio_create_prognostic_skill, skills_earth2studio_create_prognostic_skill_card, skills_earth2studio_create_prognostic_benchmark [EXTRACTED 1.00]
- **NVSkills-Eval Framework Application** — skills_earth2studio_create_prognostic_benchmark, skills_earth2studio_data_fetch_benchmark, skills_earth2studio_deterministic_forecast_benchmark, skills_earth2studio_discover_benchmark, skills_earth2studio_install_benchmark, nskills_eval [EXTRACTED 1.00]
- **SageMaker Deployment Workflow** — skills_hf_cloud_sagemaker_deployment_planner_skill, skills_hf_cloud_aws_context_discovery_skill, skills_hf_cloud_python_env_setup_skill, skills_hf_cloud_sagemaker_iam_preflight_skill, skills_hf_cloud_serving_image_selection_skill, skills_hf_cloud_sagemaker_production_defaults_skill [EXTRACTED 1.00]
- **HuggingFace Hub Tools** — skills_hf_cli_skill, skills_hf_mcp_skill, skills_hf_mem_skill [INFERRED 0.85]
- **Graphify Reference Documentation** — skills_graphify_references_exports, skills_graphify_references_extraction_spec, skills_graphify_references_github_and_merge, skills_graphify_references_hooks, skills_graphify_references_query, skills_graphify_references_transcribe, skills_graphify_references_update [EXTRACTED 1.00]
- **Holoscan SDK Installation Methods** — skills_holoscan_install_container_skill_md, skills_holoscan_install_debian_skill_md, skills_holoscan_install_source_skill_md, skills_holoscan_install_wheel_skill_md [EXTRACTED 1.00]
- **HSB FPGA Board Types** — hsb_lattice_board, hsb_vb1940_board, lattice_cpnx100_fpga [EXTRACTED 1.00]
- **NVSkills-Eval Evaluated Holoscan Skills** — skills_holoscan_install_container_benchmark_md, skills_holoscan_install_debian_benchmark_md, skills_holoscan_install_source_benchmark_md, skills_holoscan_install_wheel_benchmark_md, skills_holoscan_setup_benchmark_md, skills_hsb_app_benchmark_md, skills_hsb_flash_benchmark_md [EXTRACTED 1.00]
- **HSB Flash Phases 0-6** — hsb_flash_references_phase_details, token_budget_preflight, hololink_enumerate, hsb_lattice_board, vb1940_camera [EXTRACTED 0.85]
- **HSB Setup Phases 0-6** — skills_hsb_setup_skill, hsb_setup_references_phase_details, token_budget_preflight, hololink_demo_container, igx_orin, agx_orin, agx_thor, dgx_spark [EXTRACTED 0.85]
- **HSB Test Phases 0-4** — skills_hsb_test_skill, hsb_test_references_phase_details, skills_hsb_setup_skill, hololink_enumerate, hololink_demo_container, hsb_lattice_board, vb1940_camera [EXTRACTED 0.85]
- **LLM Training and Deployment Workflow** — skills_huggingface_llm_trainer_skill, skills_huggingface_llm_trainer_references_training_methods, skills_huggingface_llm_trainer_references_gguf_conversion, skills_huggingface_local_models_skill, concept_gguf, concept_llama_cpp [EXTRACTED 0.85]
- **Model Evaluation Ecosystem** — skills_huggingface_community_evals_skill, concept_inspect_ai, concept_lighteval, concept_vllm [EXTRACTED 0.85]
- **LoRA Space Deployment Pipeline** — skills_huggingface_lora_space_builder_skill, skills_huggingface_gradio_skill, concept_zero_gpu, concept_gradio [EXTRACTED 0.85]
- **ZeroGPU deployment ecosystem for Spaces** — concept_zerogpu, concept_grado, skills_huggingface_spaces_references_zerogpu, skills_huggingface_spaces_references_requirements, skills_huggingface_spaces_references_known_errors, skills_huggingface_spaces_references_debugging [EXTRACTED 0.85]
- **LoRA Space Builder model pipeline references** — skills_huggingface_lora_space_builder_skill, skills_huggingface_lora_space_builder_references_base_models_krea_2, skills_huggingface_lora_space_builder_references_base_models_ltx, skills_huggingface_lora_space_builder_references_base_models_qwen_image [EXTRACTED 0.85]
- **HF Spaces publishing and management workflow** — skills_huggingface_spaces_skill, skills_huggingface_paper_publisher_skill, skills_huggingface_tool_builder_skill, concept_hf_api [INFERRED 0.75]
- **Trackio API and TRL Workflow** — huggingface_trackio_references_logging_metrics_trackio, huggingface_trackio_references_logging_metrics_trackio_init, huggingface_trackio_references_logging_metrics_trackio_log, huggingface_trackio_references_logging_metrics_trackio_finish, huggingface_vision_trainer_trl_trainer [EXTRACTED 1.00]
- **Jetson Build Workflow Pipeline** — jetson_build_source, jetson_build_source_jetson_init_source, jetson_build_source_jetson_promote_image, jetson_build_source_jetson_flash_image, jetson_build_source_customize_skills [EXTRACTED 1.00]
- **ZeroGPU Deployment Model** — huggingface_zerogpu_spaces_gpu, huggingface_zerogpu_process_isolation, huggingface_zerogpu_cuda_monkey_patch, huggingface_zerogpu_module_scope, huggingface_zerogpu_gradio [EXTRACTED 1.00]
- **BSP carrier customization workflow (5 skills share deploy chain)** — skills_jetson_customize_camera_skill, skills_jetson_customize_mgbe_skill, skills_jetson_customize_clocks_skill, skills_jetson_customize_fan_skill, jetson_promote_image [EXTRACTED 1.00]
- **Pinmux auto-invocation (camera and MGBE share pin_verifier.py + pinmux skill)** — skills_jetson_customize_camera_skill, skills_jetson_customize_mgbe_skill, jetson_customize_pinmux, pin_verifier_py [EXTRACTED 1.00]
- **NVSkills-Eval benchmarks across 4 jetson-customize skills** — skills_jetson_customize_camera_benchmark, skills_jetson_customize_clocks_benchmark, skills_jetson_customize_fan_benchmark, skills_jetson_customize_mgbe_benchmark, nvidia_skills_eval [EXTRACTED 1.00]
- **jetson-customize-uphy per-controller ecosystem** — skills_jetson_customize_uphy_skill, skills_jetson_customize_pcie_skill, skills_jetson_customize_usb_skill, skills_jetson_customize_pinmux_skill [EXTRACTED 1.00]
- **Three-place lockstep pattern (lane + port + host xHCI)** — skills_jetson_customize_usb_skill, concept_kernel_dt_overlay, concept_usb_three_place_lockstep [EXTRACTED 1.00]
- **Two-surface UPHY BSP customization (ODMDATA + kernel-DT overlay)** — concept_uphy_lane_allocation, concept_odmdata_token, concept_kernel_dt_overlay [EXTRACTED 1.00]
- **Jetson BSP Setup Workflow Handoff Chain** — skills_jetson_download_bsp [EXTRACTED 1.00]
- **Jetson Flash Preflight Check Pipeline** — apply_binaries_sh, rcm_mode, eeprom, l4t_create_default_user_sh [EXTRACTED 1.00]
- **Jetson Diagnostic Telemetry Stack** — tegrastats, nvidia_smi, nvmap, nvpmodel [INFERRED 0.85]
- **Jetson BSP Setup Workflow** — skills_jetson_init_target_skill, skills_jetson_init_image_skill, skills_jetson_init_source_skill, skills_jetson_generate_kb_skill [EXTRACTED 1.00]
- **Jetson LLM Inference Runtimes** — concept_vllm, concept_sglang, concept_llama_cpp [EXTRACTED 1.00]
- **Jetson Memory Optimization Skills** — skills_jetson_headless_mode_skill, skills_jetson_inference_mem_tune_skill [INFERRED 0.85]
- **Jetson LLM Serve → Benchmark → Memory Tune Chain** — skills_jetson_package_skill, skills_jetson_llm_serve_skill, skills_jetson_llm_benchmark_skill, jetson_inference_mem_tune [EXTRACTED 1.00]
- **Jetson Memory Management Stack** — skills_jetson_memory_audit_skill, skills_jetson_optimize_memory_skill, jetson_headless_mode, drop_caches [EXTRACTED 1.00]
- **NVSkills-Eval Evaluation Coverage** — nvskills_eval, skills_jetson_llm_benchmark_benchmark, skills_jetson_llm_serve_benchmark, skills_jetson_memory_audit_benchmark, skills_jetson_optimize_memory_benchmark, skills_jetson_package_benchmark, skills_jetson_print_bsp_info_benchmark [EXTRACTED 1.00]
- **Jetson Deploy Pipeline** — skills_jetson_promote_image_skill, module_shadowing, vermagic_skew, kernel_image_mirror, initramfs_refresh [EXTRACTED 1.00]
- **Jetson Validate Image Tooling** — skills_jetson_validate_image_skill, uart_session, skills_jetson_validate_image_references_dut_access [EXTRACTED 1.00]
- **NVSkills-Eval Framework** — nvskills_eval, skills_jetson_print_device_info_benchmark, skills_jetson_promote_image_benchmark, skills_jetson_quick_start_benchmark, skills_jetson_set_target_benchmark, skills_jetson_speculative_decoding_benchmark, skills_jetson_validate_image_benchmark [EXTRACTED 1.00]
- **Megatron-LM Development Workflow Skills** — skills_mcore_create_issue_skill, skills_mcore_linting_and_formatting_skill, skills_mcore_run_on_slurm_skill, skills_mcore_split_pr_skill, skills_mcore_testing_skill [EXTRACTED 1.00]
- **NeMo AutoModel Distributed Training Components** — fsdp2, megatron_fsdp, ddp, tensor_parallelism, pipeline_parallelism, context_parallelism, expert_parallelism [EXTRACTED 1.00]
- **NeMo-RL Infrastructure Stack** — nrl_k8s_cli, kuberay, rayjob_mode, long_lived_mode, nemo_rl_recipes [EXTRACTED 1.00]
- **Model Onboarding Skill Ecosystem** — skills_nemo_automodel_model_onboarding_skill, skills_nemo_automodel_model_onboarding_llm_patterns, skills_nemo_automodel_model_onboarding_moe_patterns, skills_nemo_automodel_model_onboarding_vlm_patterns, skills_nemo_automodel_model_onboarding_capabilities_and_precision [EXTRACTED 1.00]
- **Data Designer Workflow Ecosystem** — skills_nemo_data_designer_plugin_skill, skills_nemo_data_designer_plugin_workflows_autopilot, skills_nemo_data_designer_plugin_workflows_interactive [EXTRACTED 1.00]
- **NeMo AutoModel Skill Suite** — skills_nemo_automodel_launcher_config_skill, skills_nemo_automodel_model_onboarding_skill, skills_nemo_automodel_recipe_development_skill [EXTRACTED 1.00]
- **Evaluator Plugin Workflow Components** — nemo_evaluator_plugin_nemo_evaluator_cli, nemo_evaluator_plugin_evaluation_spec, nemo_evaluator_plugin_llm_as_judge, nemo_evaluator_plugin_plugin_sdk_interface [EXTRACTED 1.00]
- **MLM vs Bridge Training Pair** — nemo_mbridge_mlm_bridge_training_megatron_lm, nemo_mbridge_mlm_bridge_training_megatron_bridge, nemo_mbridge_mlm_bridge_training_loss_correlation_testing [EXTRACTED 1.00]
- **GPU Memory Optimization: Recompute vs CPU Offload** — nemo_mbridge_perf_activation_recompute_cpu_offloading, nemo_mbridge_perf_cpu_offloading_activation_offloading, nemo_mbridge_perf_cpu_offloading_optimizer_offloading [INFERRED 0.85]
- **CUDA Graph Performance Skill Ecosystem** — skills_nemo_mbridge_perf_cuda_graphs_skill, skills_nemo_mbridge_perf_cuda_graphs_card, config_cuda_graph_impl, config_cuda_graph_scope, concept_cuda_graph_capture [EXTRACTED 1.00]
- **MoE Communication Overlap Skill Ecosystem** — skills_nemo_mbridge_perf_expert_parallel_overlap_skill, skills_nemo_mbridge_perf_moe_comm_overlap_skill, config_overlap_moe_expert_parallel_comm, config_delay_wgrad_compute, concept_ep_overlap, concept_flex_dispatcher [EXTRACTED 1.00]
- **Memory Optimization Skill Ecosystem** — skills_nemo_mbridge_perf_memory_tuning_skill, skills_nemo_mbridge_perf_memory_tuning_card, config_expandable_segments, concept_memory_fragmentation, config_use_megatron_fsdp [EXTRACTED 1.00]
- **MoE Dispatcher-Hardware Compatibility Matrix** — concept_moe_dispatcher_deepep, concept_moe_dispatcher_hybridep, concept_h100, concept_b200, concept_gb200, concept_gb300, concept_nvl72 [EXTRACTED 1.00]
- **MoE Three Walls Optimization Framework** — concept_moe_three_walls, concept_memory_wall, concept_communication_wall, concept_compute_wall, concept_moe_optimization_workflow [EXTRACTED 1.00]
- **MoE VLM Training Strategy Comparison** — concept_vlm_moe, concept_fsdp_moe, concept_3d_parallel_moe, concept_moe_dispatcher_hybridep, concept_cuda_graphs_moe [EXTRACTED 1.00]
- **Megatron Bridge Performance Training Infrastructure** — skills_nemo_mbridge_perf_parallelism_strategies_skill, skills_nemo_mbridge_perf_sequence_packing_skill, skills_nemo_mbridge_perf_tp_dp_comm_overlap_skill [INFERRED 0.85]
- **Megatron Bridge Skill Card Bundle** — skills_nemo_mbridge_perf_parallelism_strategies_card, skills_nemo_mbridge_perf_parallelism_strategies_skill_card, skills_nemo_mbridge_perf_sequence_packing_card, skills_nemo_mbridge_perf_sequence_packing_skill_card, skills_nemo_mbridge_perf_tp_dp_comm_overlap_card, skills_nemo_mbridge_perf_tp_dp_comm_overlap_skill_card, skills_nemo_mbridge_resiliency_card, skills_nemo_mbridge_resiliency_skill_card [EXTRACTED 1.00]
- **Megatron Bridge Parallelism and Communication Optimization** — tensor_model_parallel, sequence_parallel, context_parallel, tp_comm_overlap, dp_comm_overlap, pp_comm_overlap [INFERRED 0.85]
- **NeMo RL Experiment Infrastructure** — experiment_campaign, hypothesis_testing, tsv_ledger, nemo_rl_auto_research_workflow [EXTRACTED 0.85]
- **NeMo RL Session Management** — session_memory, handoff, checkpoint, nemo_rl_session_memory_skill [EXTRACTED 0.85]
- **Brev Instance Management** — brev_etiquette, ephemeral_storage, env_secrets, cache_management [EXTRACTED 0.85]
- **Nemotron Training Pipeline Composition** — concept_curation_pipeline, concept_translation_pipeline, concept_sft_peft, concept_pretraining, concept_rl_alignment [EXTRACTED 0.85]
- **Nemotron Customize References Ecosystem** — skills_nemotron_customize_references_catalog, skills_nemotron_customize_references_artifacts, skills_nemotron_customize_references_commands, skills_nemotron_customize_references_hardware, skills_nemotron_customize_references_patterns, skills_nemotron_customize_references_workflow [EXTRACTED 1.00]
- **Context Pack Coverage** — skills_nemotron_customize_references_context_automodel_launcher_executor_modes, skills_nemotron_customize_references_context_automodel_pretrain, skills_nemotron_customize_references_context_automodel_sft_peft_core, skills_nemotron_customize_references_context_byob_benchmark_curator_translation, skills_nemotron_customize_references_context_checkpoint_conversion, skills_nemotron_customize_references_context_curator_data_acquisition, skills_nemotron_customize_references_context_curator_processing_language_quality, skills_nemotron_customize_references_context_curator_translation_faith, skills_nemotron_customize_references_context_data_designer_sdg, skills_nemotron_customize_references_context_eval_deploy_formats [EXTRACTED 1.00]
- **Nemotron Policy Generation Pipeline** — skills_nemotron_policy_generator_skill, skills_nemotron_policy_generator_references_content_safety_taxonomy, skills_nemotron_policy_generator_assets_policy_md_template, skills_nemotron_policy_generator_assets_nemotron_system_prompt_template [EXTRACTED 1.00]
- **Nemotron Model Training Pipeline** — pretrain_prep, sft_packing, rl_prep, skills_nemotron_customize_references_context_mbridge_pretrain, skills_nemotron_customize_references_context_mbridge_sft, skills_nemotron_customize_references_context_nemo_rl_alignment [EXTRACTED 0.95]
- **Megatron-Bridge Parallelism Strategies** — tensor_parallelism, pipeline_parallelism, context_parallelism, expert_parallelism [EXTRACTED 1.00]
- **Nemotron Retrieval Recipe Components** — skills_nemotron_retrieval_recipes_skill_card, evaluation_reference, remote_execution_reference, embed_recipe_reference [EXTRACTED 1.00]
- **Nemotron Speech Skill Workflow** — skills_nemotron_speech_skill, nemotron_speech_references_asr, nemotron_speech_references_tts, nemotron_speech_references_nmt, nemotron_speech_references_setup, nemotron_speech_references_model_selection, nemotron_speech_references_pipelines, riva_nim, build_nvidia_com [EXTRACTED 1.00]
- **NV-Generate-CT Ecosystem** — skills_nv_generate_ct_rflow_skill, nv_generate_ctmr, rflow_ct, ct_volume_generation, ct_mask_generation, synthetic_ct_volumes, maisi_labels, ct_controlnet, controllable_mask_generation [EXTRACTED 1.00]
- **MRI generation skill family** — skills_nv_generate_mr_brain_skill, skills_nv_generate_mr_skill, skills_nv_generate_mr_brain_finetune_skill [EXTRACTED 1.00]
- **NV-Generate-CTMR skill ecosystem** — skills_nv_generate_ct_rflow_skill_manifest, skills_nv_generate_mr_brain_skill_manifest, skills_nv_generate_mr_skill_manifest, skills_nv_generate_mr_brain_finetune_skill_manifest, skills_nv_generate_vae_finetune_skill_manifest, nvidia_medtech_nv_generate_ctmr [EXTRACTED 1.00]
- **NVSkills-Eval benchmark corpus** — skills_nv_generate_mr_brain_finetune_benchmark, skills_nv_generate_mr_brain_benchmark, skills_nv_generate_mr_benchmark, skills_nv_generate_vae_finetune_benchmark, nvsys_eval [EXTRACTED 1.00]
- **NV Segmentation Skills Family** — skills_nv_segment_ct_skill, skills_nv_segment_ct_finetune_skill, skills_nv_segment_ctmr_skill, nvidia_nv_segment_ct, nvidia_nv_segment_ctmr [EXTRACTED 1.00]
- **CAD to SimReady Pipeline Stages** — preflight, skills_omniverse_cad_to_simready_references_convert_to_usd, content_agents, simready_conform_profile, skills_omniverse_cad_to_simready_references_assemble_package_source [EXTRACTED 1.00]
- **Content Agents Ecosystem** — material_agent, physics_agent, texture_agent, ovrtx_renderer, skills_omniverse_cad_to_simready_references_deploy_content_agents [EXTRACTED 1.00]
- **USD Converter Format Support** — urdf_usd_converter, mujoco_usd_converter, usd_convert_cad, usd_convert_gsplat [EXTRACTED 1.00]
- **CAD-to-SimReady Validation Pipeline Stages** — skills_omniverse_cad_to_simready_references_omni_asset_validate, skills_omniverse_cad_to_simready_references_omni_asset_validate_geometry, skills_omniverse_cad_to_simready_references_omni_asset_validate_physics, skills_omniverse_cad_to_simready_references_simready_conform_profile, simready_validate [EXTRACTED 1.00]
- **Content Agents Deployment Skills** — skills_omniverse_cad_to_simready_references_deploy_content_agents_references_deploy_ovrtx_docker, skills_omniverse_cad_to_simready_references_deploy_content_agents_references_deploy_physics_agent_docker, skills_omniverse_cad_to_simready_references_deploy_content_agents_references_deploy_texture_agent_docker [EXTRACTED 1.00]
- **SimReady Conformance FET Routing** — skills_omniverse_cad_to_simready_references_simready_conform_profile, skills_omniverse_cad_to_simready_references_simready_conform_profile_references_fet_000_core, skills_omniverse_cad_to_simready_references_simready_conform_profile_references_fet_001_minimal, skills_omniverse_cad_to_simready_references_simready_conform_profile_references_fet_004_simulate_multi_body_physics, upstream_simready_foundation [EXTRACTED 1.00]
- **AOV Display Pipeline** — aov_switching_ovrtx, aov_switching_warp, aov_switching_ovstream, aov_switching_ldrcutor [EXTRACTED 1.00]
- **C++ Native Viewer Architecture** — cpp_native_viewer_imgui, cpp_native_viewer_glfw, cpp_native_viewer_opengl, cpp_native_ovrtx_c_api [EXTRACTED 1.00]
- **Cloud Deployment Stack** — cloud_deployment_brev, cloud_deployment_docker, cloud_deployment_caddy, cloud_deployment_webrtc [EXTRACTED 0.85]
- **Electron SHM Core Components** — python_server_runtime, shm_server, message_router, shm_client, n_api_addon, webgl_blit [EXTRACTED 1.00]
- **GL Overlay Architecture Layers** — ovui_interaction_library, gl_overlay_renderer, ovrtx_renderer, skills_omniverse_realtime_viewer_references_gl_viewport_overlay_projection_alignment [EXTRACTED 1.00]
- **Viewer Backend Interface Contract** — viewer_backend_interface, frame_data, streaming_messages, native_picking, selection_groups [EXTRACTED 1.00]
- **Local Viewer Recipe Subsystem** — skills_omniverse_realtime_viewer_references_ovui_local_viewer_recipe_interaction_features, skills_omniverse_realtime_viewer_references_ovui_local_viewer_recipe_project_structure, skills_omniverse_realtime_viewer_references_ovui_local_viewer_recipe_setup_shell_renderer, skills_omniverse_realtime_viewer_references_ovui_local_viewer_recipe_validation_build_order [EXTRACTED 0.95]
- **Selection Feedback Stack** — selection_picking, skills_omniverse_realtime_viewer_references_selection_feedback_readme, skills_omniverse_realtime_viewer_references_selection_animation_readme, skills_omniverse_realtime_viewer_references_prim_pick_effects_readme [EXTRACTED 0.85]
- **Stage Query Stack** — skills_omniverse_realtime_viewer_references_stage_hierarchy_readme, skills_omniverse_realtime_viewer_references_stage_queries_readme, skills_omniverse_realtime_viewer_references_stage_attribute_reads_readme, skills_omniverse_realtime_viewer_references_stage_loading_readme [EXTRACTED 0.85]
- **Streaming Omniverse Realtime Viewer Architecture** — streaming_server_runtime, ovstream, ovrtx, webrtc, streaming_message_handler, frame_loop, rgba_bgra_conversion, camera_controls, selection_controller, input_router [EXTRACTED 1.00]
- **Local Viewer Alternatives** — tauri_viewer, electron_shm_viewer, viewer_backend, native_picking [EXTRACTED 1.00]
- **Transform Interaction System** — transform_gizmo, prim_transform_safety, omni_xform, camera_controls, selection_controller [EXTRACTED 0.95]
- **Viewport Input Handling Pattern** — omniverse_realtime_viewer_references_viewer_input_routing_readme, omniverse_realtime_viewer_references_viewport_overlays_readme, omniverse_realtime_viewer_references_viewport_resize_readme, input_router, viewport_input_active, resize_viewport, camera_aspect_ratio [INFERRED 0.75]
- **Scene Optimizer Operation Workflow** — omniverse_usd_performance_tuning_references_operations_readme, omniverse_usd_performance_tuning_references_operations_classification_md, omniverse_usd_performance_tuning_references_operations_execution_md, operation_classification, batch_mode_orchestration, scene_optimizer_execution_context [EXTRACTED 1.00]
- **USD Performance Tuning Workflow Phases** — skills_omniverse_usd_performance_tuning_skill, runtime_context_gate, profile_stage, usd_structure_assessment, optimization_report [EXTRACTED 1.00]
- **Phase 4 Occlusion Removal Operation Chain** — skills_omniverse_usd_performance_tuning_references_operations_findoccludedmeshes, skills_omniverse_usd_performance_tuning_references_operations_deleteprims, skills_omniverse_usd_performance_tuning_references_operations_meshcleanup, skills_omniverse_usd_performance_tuning_references_operations_deduplicategeometry, skills_omniverse_usd_performance_tuning_references_operations_decimatemeshes [EXTRACTED 1.00]
- **Deduplication Operations Group** — skills_omniverse_usd_performance_tuning_references_operations_deduplicategeometry, skills_omniverse_usd_performance_tuning_references_operations_deduplicatehierarchies, skills_omniverse_usd_performance_tuning_references_operations_optimizematerials [EXTRACTED 0.85]
- **UV Generation Operations Group** — skills_omniverse_usd_performance_tuning_references_operations_generateatlasuvs, skills_omniverse_usd_performance_tuning_references_operations_generateprojectionuvs [INFERRED 0.85]
- **Geometry Mesh Operations** — skills_omniverse_usd_performance_tuning_references_operations_primitivestomeshes_primitivestomeshes, skills_omniverse_usd_performance_tuning_references_operations_remeshmeshes_remeshmeshes, skills_omniverse_usd_performance_tuning_references_operations_sparsemeshes_sparsemeshes, skills_omniverse_usd_performance_tuning_references_operations_splitmeshes_splitmeshes, skills_omniverse_usd_performance_tuning_references_operations_subdividemeshes_subdividemeshes, skills_omniverse_usd_performance_tuning_references_operations_triangulatemeshes_triangulatemeshes, skills_omniverse_usd_performance_tuning_references_operations_removesmallgeometry_removesmallgeometry, skills_omniverse_usd_performance_tuning_references_operations_shrinkwrap_shrinkwrap [EXTRACTED 1.00]
- **Hierarchy Cleanup Operations** — skills_omniverse_usd_performance_tuning_references_operations_organizeprototypes_organizeprototypes, skills_omniverse_usd_performance_tuning_references_operations_pruneleaves_pruneleaves, skills_omniverse_usd_performance_tuning_references_operations_removeprims_removeprims, skills_omniverse_usd_performance_tuning_references_operations_removeuntypedprims_removeuntypedprims [EXTRACTED 1.00]
- **High Risk Operations Requiring Confirmation** — skills_omniverse_usd_performance_tuning_references_operations_pythonscript_pythonscript, skills_omniverse_usd_performance_tuning_references_operations_remeshmeshes_remeshmeshes, skills_omniverse_usd_performance_tuning_references_operations_removeprims_removeprims, skills_omniverse_usd_performance_tuning_references_operations_shrinkwrap_shrinkwrap [EXTRACTED 1.00]
- **USD Performance Tuning Workflow Components** — omniverse_usd_performance_tuning_references_optimization_report_readme, omniverse_usd_performance_tuning_references_profile_stage_readme, omniverse_usd_performance_tuning_references_setup_usd_performance_tuning_readme, omniverse_usd_performance_tuning_references_so_run_operations_readme, omniverse_usd_performance_tuning_references_skill_map [INFERRED 0.85]
- **Runtime Installation Paths** — skills_omniverse_usd_performance_tuning_references_setup_usd_performance_tuning_references_standalone_runtime, kit, scene_optimizer, asset_validator [INFERRED 0.85]
- **USD Stage Profiling Modes** — quick_mode_profiling, full_mode_profiling [EXTRACTED 1.00]
- **so-create-proxy Upstream Handoffs** — skills_omniverse_usd_performance_tuning_references_so_run_operations_references_so_create_proxy_readme, skills_omniverse_usd_performance_tuning_references_so_run_operations_references_so_create_proxy_references_bounding_box_proxy_modes, skills_omniverse_usd_performance_tuning_references_so_run_operations_references_so_create_proxy_references_decimate_step_recipes, skills_omniverse_usd_performance_tuning_references_so_run_operations_references_so_create_proxy_references_decimation_tuning, skills_omniverse_usd_performance_tuning_references_upstreams_usd_optimize [EXTRACTED 1.00]
- **apply-restructure Reference Tree** — skills_omniverse_usd_performance_tuning_references_usd_structure_assessment_references_apply_restructure_readme, skills_omniverse_usd_performance_tuning_references_usd_structure_assessment_references_apply_restructure_references_restructure_mode, skills_omniverse_usd_performance_tuning_references_usd_structure_assessment_references_apply_restructure_references_ref_remap_mode, skills_omniverse_usd_performance_tuning_references_usd_structure_assessment_references_apply_restructure_references_hierarchy_dedupe_rewrite_tool_spec [EXTRACTED 1.00]
- **Hierarchy Dedupe Pipeline** — skills_omniverse_usd_performance_tuning_references_usd_structure_assessment_readme, skills_omniverse_usd_performance_tuning_references_usd_structure_assessment_references_usd_hierarchy_dedupe_candidates_readme, skills_omniverse_usd_performance_tuning_references_usd_structure_assessment_references_usd_hierarchy_dedupe_candidates_references_instance_candidate_finder_spec, skills_omniverse_usd_performance_tuning_references_usd_structure_assessment_references_apply_restructure_references_hierarchy_dedupe_rewrite_tool_spec [EXTRACTED 1.00]
- **USD Validation Pipeline** — concept_usd_validation_runner, concept_scene_optimizer_validators, concept_asset_validator, omniverse_usd_performance_tuning_references_usd_validation_runner_readme [EXTRACTED 1.00]
- **DIG Asset Setup Workflows** — physical_ai_defect_image_generation_assets_configs_setup_setup_pretrained, physical_ai_defect_image_generation_assets_configs_setup_setup_pcb, physical_ai_defect_image_generation_assets_configs_setup_setup_metal, physical_ai_defect_image_generation_assets_configs_setup_setup_glass [EXTRACTED 1.00]
- **Defect Image Generation Pipeline** — concept_usd2roi, concept_cosmos_anomalygen, concept_osmo_workflow, concept_aoi_inspection [INFERRED 0.85]
- **Full Defect Image Generation Pipeline (Structural + Texture)** — assets_configs_structural_defect_generation, assets_configs_texture_defect_generation_day0, assets_configs_texture_defect_generation_day1_real_alignment, concept_structural_defect_types, concept_texture_defect_types [INFERRED 0.85]
- **Per-Board PCB Cookbook Set (0603_H100 + 1152819000)** — assets_cookbooks_pcb_0603_h100_day0_crop, assets_cookbooks_pcb_0603_h100_day0_image, assets_cookbooks_pcb_0603_h100_defect_image, assets_cookbooks_pcb_0603_h100_pcba_target, assets_cookbooks_pcb_0603_h100_usd2roi_nvpcb, assets_cookbooks_pcb_1152819000_day0_crop, assets_cookbooks_pcb_1152819000_day0_image, assets_cookbooks_pcb_1152819000_defect_image, assets_cookbooks_pcb_1152819000_pcba_target, assets_cookbooks_pcb_1152819000_usd2roi_nvpcb [EXTRACTED 1.00]
- **AnomalyGen Training Stack (NVDINOV2 + T5 + defect types per usecase)** — assets_cookbooks_glass_ag_config, assets_cookbooks_metal_surface_ag_config, concept_nvdinov2_mask_encoder, concept_t5_anomaly_embedding, concept_texture_defect_types [EXTRACTED 1.00]
- **DIG Workflow Flows Orchestration** — skills_physical_ai_defect_image_generation_references_flows_good_image_generation, skills_physical_ai_defect_image_generation_references_flows_structural_defect_generation, skills_physical_ai_defect_image_generation_references_flows_texture_defect_generation_day0, skills_physical_ai_defect_image_generation_references_flows_texture_defect_generation_day1_manual_roi, skills_physical_ai_defect_image_generation_references_flows_texture_defect_generation_day1_real_alignment, skills_physical_ai_defect_image_generation_references_flows_finetune [EXTRACTED 1.00]
- **OSMO Infrastructure Prerequisites** — skills_physical_ai_defect_image_generation_references_preconditions_hf_token, skills_physical_ai_defect_image_generation_references_preconditions_pod_template, skills_physical_ai_defect_image_generation_references_preconditions_nvoptix, skills_physical_ai_defect_image_generation_references_preconditions_dshm [EXTRACTED 1.00]
- **Azure Cluster Infrastructure Stack** — skills_physical_ai_infrastructure_setup_and_resilient_scaling_components_azure_access_reference, skills_physical_ai_infrastructure_setup_and_resilient_scaling_components_cluster_azure_reference, skills_physical_ai_infrastructure_setup_and_resilient_scaling_components_cluster_azure_scripts_helmfile, skills_physical_ai_infrastructure_setup_and_resilient_scaling_skill_azure [EXTRACTED 1.00]
- **NIM Operator All NIMServices Pattern** — nim_operator, nim_service_kind, read_write_many_storage, ngc_api_secret [EXTRACTED 1.00]
- **Cosmos NIM Family** — nvidia_cosmos_predict1_7b_video2world, nvidia_cosmos_reason2_8b, nvidia_cosmos_transfer2_5_2b [INFERRED 0.85]
- **Physical AI Infrastructure Stack Components** — infrastructure_stack, microk8s, nim_operator, azure_ai_foundry, nvidia_osmo [EXTRACTED 1.00]
- **OSMO Workflow System Architecture** — physical_ai_infrastructure_setup_and_resilient_scaling_osmo_cli, physical_ai_infrastructure_setup_and_resilient_scaling_workflow_yaml, physical_ai_infrastructure_setup_and_resilient_scaling_resource_pools, physical_ai_infrastructure_setup_and_resilient_scaling_credentials, physical_ai_infrastructure_setup_and_resilient_scaling_phase_split_pattern [EXTRACTED 1.00]
- **OSMO Workflow Patterns Suite** — physical_ai_infrastructure_setup_and_resilient_scaling_parallel_tasks, physical_ai_infrastructure_setup_and_resilient_scaling_serial_tasks, physical_ai_infrastructure_setup_and_resilient_scaling_synchronized_groups, physical_ai_infrastructure_setup_and_resilient_scaling_combination_pipelines, physical_ai_infrastructure_setup_and_resilient_scaling_jinja_templating [EXTRACTED 1.00]
- **OSMO Advanced Workflow Patterns** — physical_ai_infrastructure_setup_and_resilient_scaling_checkpointing, physical_ai_infrastructure_setup_and_resilient_scaling_exit_actions, physical_ai_infrastructure_setup_and_resilient_scaling_node_exclusion [EXTRACTED 1.00]
- **PAS OSMO Workflow Infrastructure** — pas_workflow_augmentation, pas_workflow_auto_labeling, pas_workflow_e2e, nvidia_osmo, skills_physical_ai_people_attribute_search_skill [EXTRACTED 1.00]
- **VDA OSMO Workflow Infrastructure** — vda_workflow_augmentation_and_al, vda_workflow_auto_labeling, vda_workflow_e2e, vda_workflow_e2e_super_resolution, nvidia_osmo, skills_physical_ai_video_data_augmentation_skill [EXTRACTED 1.00]
- **Physical AI Data Augmentation Suite** — skills_physical_ai_people_attribute_search_skill, skills_physical_ai_video_data_augmentation_skill, skills_physical_ai_defect_image_generation_skill, nvidia_osmo, qwen3_vl_nim, qwen25_14b_nim [INFERRED 0.85]
- **VDA Augmentation and Auto-labeling Pipeline** — augmentation_pipeline_concept, auto_labeling_pipeline_concept, cosmos_transfer_2_5_model, qwen3_vl_30b_a3b_instruct_model, qwen2_5_14b_instruct_model [EXTRACTED 1.00]
- **Cookbook Scene Structure Sharing** — city_traffic_scene, piazza_scene, robot_assembly_scene, shared_cookbook_layout_concept, augmentation_pipeline_concept, auto_labeling_pipeline_concept [EXTRACTED 1.00]
- **Detection and Tracking System** — rfdetr_model, boosttrack_tracker, vehicle_clip_reid_model, city_traffic_auto_labeling_config, piazza_auto_labeling_config [EXTRACTED 1.00]
- **Robot Assembly Augmentation Pipeline** — assets_cookbooks_robot_assembly_augmentation, assets_cookbooks_robot_assembly_augmentation_prompts_template_generation_system_prompt, lighting, augmentation_worker [EXTRACTED 1.00]
- **Trailer Dashcam Augmentation Pipeline** — assets_cookbooks_trailer_dashcam_augmentation_config, vlm_captioning, llm_prompt_refinement, cosmos_transfer_25, hallucination_check, attribute_verification [EXTRACTED 1.00]
- **Three Dataset Event Taxonomy** — collision_category, near_miss_category, anomaly_category, normal_traffic_category, vlm_json [EXTRACTED 1.00]
- **VDA Workflow Pipeline Components** — setup_group, auto_labeling_original, augmentation_group, auto_labeling_augmented [EXTRACTED 1.00]
- **RAG Blueprint Deployment Modes** — docker_deploy, helm_deploy, library_mode [EXTRACTED 1.00]
- **RAG Model Infrastructure** — llm_model, embedding_model, reranking_model, milvus, elasticsearch [EXTRACTED 0.95]
- **RAG Blueprint Deployment Modes** — skills_rag_blueprint_references_deploy_docker_nvidia_hosted, skills_rag_blueprint_references_deploy_docker_self_hosted, skills_rag_blueprint_references_deploy_docker_retrieval_only, skills_rag_blueprint_references_deploy_helm_standard, skills_rag_blueprint_references_deploy_helm_mig, skills_rag_blueprint_references_deploy_helm_openshift, skills_rag_blueprint_references_deploy_library_full, skills_rag_blueprint_references_deploy_library_lite [EXTRACTED 1.00]
- **RAG Blueprint Configuration Categories** — skills_rag_blueprint_references_configure_notebooks, skills_rag_blueprint_references_configure_observability, skills_rag_blueprint_references_configure_query_and_conversation, skills_rag_blueprint_references_configure_reasoning_and_generation, skills_rag_blueprint_references_configure_search_and_retrieval, skills_rag_blueprint_references_configure_summarization, skills_rag_blueprint_references_configure_user_interface, skills_rag_blueprint_references_configure_vlm [EXTRACTED 1.00]
- **RAG Blueprint Operational Lifecycle** — skills_rag_blueprint_references_deploy, skills_rag_blueprint_references_shutdown, skills_rag_blueprint_references_troubleshoot [EXTRACTED 1.00]
- **RAG Evaluation Pipeline** — skills_rag_eval_skill, ragas, corpus_directory, train_json, evaluate_rag_py [EXTRACTED 1.00]
- **RAG Performance Benchmarking** — skills_rag_perf_skill, rag_perf_cli, yaml_config, aiperf, synthetic_query_generation [EXTRACTED 1.00]
- **Sage Platform Architecture** — edge_nodes, beehive, beekeeper, waggle_edge_stack, edge_scheduler, sage_plugins, pywaggle [EXTRACTED 1.00]
- **BirdNET Audio Debugging and Deployment** — skills_sage_waggle_references_birdnet_audio_debugging_and_geofilter, skills_sage_waggle_references_camera_audio_capabilities, birdnet_species, pywaggle, birdnet_geo_filtering [EXTRACTED 0.95]
- **Camera Image Acquisition Patterns** — skills_sage_waggle_references_camera_metadata_and_native_still_acquisition, skills_sage_waggle_references_camera_rtsp_patterns, camera_vendor_interface, native_still_acquisition, rtsp_stream [EXTRACTED 0.95]
- **ECR Build Failure and Deploy Workarounds** — skills_sage_waggle_references_ecr_build_proc_acpi_failure, skills_sage_waggle_references_ecr_builder_proc_acpi_runc_bug, skills_sage_waggle_references_ecr_arm64_thor_deployment, runc_proc_acpi_bug, k3s_sideload, qemu_cross_build [EXTRACTED 1.00]
- **Sage Job Scheduling and Deployment Ecosystem** — skills_sage_waggle_references_job_scheduling_and_debugging, skills_sage_waggle_references_job_scheduling_and_liveness, skills_sage_waggle_references_sesctl_ecr_validation, skills_sage_waggle_references_sesctl_queue_and_job_persistence, skills_sage_waggle_references_sesctl_reference_and_quirks [INFERRED 0.85]
- **Image Provenance and Timestamps** — skills_sage_waggle_references_image_metadata_naming_and_eventlog_linking, skills_sage_waggle_references_image_upload_provenance_and_linking, skills_sage_waggle_references_linking_images_to_event_log_and_uniqueness, skills_sage_waggle_references_frame_anchored_batch_consumers_and_watchers [INFERRED 0.85]
- **MCP Server Tooling** — skills_sage_waggle_references_github_mcp_server, skills_sage_waggle_references_huggingface_mcp_server, skills_sage_waggle_references_huggingface_skills_index, skills_sage_waggle_references_graphify_guide [INFERRED 0.85]
- **Publish-save decoupling pattern documented across multiple reference files** — skills_sage_waggle_references_publish_vs_save_and_portal_media_rendering, skills_sage_waggle_references_publish_vs_save_and_save_match_design, skills_sage_waggle_references_publish_vs_save_decoupling_pattern, skills_sage_waggle_references_publish_vs_save_decoupling_save_match [EXTRACTED 1.00]
- **Node SSH access and diagnostics documents share k3s/kubectl/k8s concepts** — skills_sage_waggle_references_node_access_and_job_ownership, skills_sage_waggle_references_node_control_plane_disconnect_diagnosis, skills_sage_waggle_references_node_stopped_reporting_diagnosis, skills_sage_waggle_references_node_ssh_access_and_gpsd_probe [EXTRACTED 1.00]
- **pluginctl development and deployment workflow documented in camp guides** — skills_sage_waggle_references_pluginctl_camp_guide, skills_sage_waggle_references_pluginctl_sideload_and_node_build, skills_sage_waggle_references_plugin_deploy_pluginctl_vs_ses, skills_sage_waggle_references_on_node_verification_recipe [EXTRACTED 1.00]
- **Save-match publish-vs-save decoupling across inference plugins** — skills_sage_waggle_references_publish_vs_save_decoupling, skills_sage_waggle_references_save_match_publish_vs_save_pattern, two_knob_model, save_match, heartbeat_invariant, bioclip, birdnet, yolo [EXTRACTED 1.00]
- **Reolink RLC-811A camera integration for Sage inference plugins** — reolink_rlc_811a, skills_sage_waggle_references_reolink_http_snapshot, skills_sage_waggle_references_reolink_audio_capture, skills_sage_waggle_references_reolink_focus_control, skills_sage_waggle_references_reolink_snapshot_capture, reolink_cgi_snap, reolink_snapshot_auth_exif, yolo, birdnet [EXTRACTED 1.00]
- **Image acquisition ladder: RTSP vs HTTP still metadata** — rtsp_stream, http_still_endpoint, skills_sage_waggle_references_rtsp_metadata_preservation, skills_sage_waggle_references_rtsp_vs_still_metadata_acquisition, acquisition_ladder, reolink_cgi_snap [EXTRACTED 1.00]
- **Sage Vision Pipeline Components** — yolo, bioclip, detect_then_classify, zero_shot_classifier, biochip_confidence [EXTRACTED 0.95]
- **Sage Stack Architecture** — wes_platform_layer, user_plugin_layer, pywaggle2, image_sampler2, yolo, bioclip, producer_consumer_pattern, shared_cache, two_layer_cache, wes_local_cache_manager [EXTRACTED 0.95]
- **TAO ChangeNet RCA Investigation Framework** — score_analysis, deep_image_investigation, cross_dimensional_analysis, counterfactual_analysis, changenet_model, golden_image, test_image, visual_evidence, siamese_network [EXTRACTED 0.95]
- **RCA Analysis Framework** — tao_analyze_changenet_rca, tao_analyze_gaps_visual_changenet, tao_analyze_gaps_vlm_bcq, gap_analysis, root_cause_analysis, nvidia_nvskills_eval [EXTRACTED 1.00]
- **TAO Training and Inference Pipeline** — tao_finetune_clip, tao_convert_dataset_format, tao_finetune_clip_references_error_patterns, tao_finetune_clip_references_spec_param_inference, clip_model, onnx_export, tensorrt_deployment [EXTRACTED 1.00]
- **VCN Gap Analysis Workflow** — tao_analyze_gaps_visual_changenet, tao_data_services_container, threshold_sweep, weakness_ranking, gap_analysis, vcn_classify [EXTRACTED 1.00]
- **CLIP Deploy Workflow** — skills_tao_finetune_clip_train_action, skills_tao_finetune_clip_export_action, skills_tao_finetune_clip_gen_trt_engine_action, skills_tao_finetune_clip_evaluate_action, skills_tao_finetune_clip_inference_action [EXTRACTED 1.00]
- **Cosmos-Embed All Actions** — skills_tao_finetune_cosmos_embed_train_action, skills_tao_finetune_cosmos_embed_evaluate_action, skills_tao_finetune_cosmos_embed_inference_action, skills_tao_finetune_cosmos_embed_export_action [EXTRACTED 1.00]
- **Cosmos-RL All Actions** — skills_tao_finetune_cosmos_reason_train_action, skills_tao_finetune_cosmos_reason_evaluate_action, skills_tao_finetune_cosmos_reason_inference_action, skills_tao_finetune_cosmos_reason_quantize_action [EXTRACTED 1.00]
- **Cosmos-RL Training Infrastructure Components** — cosmos3_nano, cosmos_rl_sft, fsdp_parallelism, lora_adapter [EXTRACTED 0.85]
- **Cosmos-RL Skill Actions** — cosmos_rl_sft, quantization [EXTRACTED 0.90]
- **HuggingFace Fine-tuning Workflow Infrastructure** — skills_tao_finetune_huggingface_model_skill, six_step_workflow, ngc_container, hf_trainer [EXTRACTED 0.90]
- **Six Step Workflow Phases 0 to 10** — skills_tao_finetune_huggingface_model_references_core_rules, skills_tao_finetune_huggingface_model_references_detailed_workflow, skills_tao_finetune_huggingface_model_references_model_discovery, skills_tao_finetune_huggingface_model_references_hardware_container, skills_tao_finetune_huggingface_model_references_dataset_patterns, skills_tao_finetune_huggingface_model_references_dataset_sources, skills_tao_finetune_huggingface_model_references_dataset_recommendations, skills_tao_finetune_huggingface_model_references_progress_tracking, skills_tao_finetune_huggingface_model_references_hub_push, skills_tao_finetune_huggingface_model_references_pipeline_skill_template [EXTRACTED 1.00]
- **Docker Runtime Infrastructure** — skills_tao_finetune_huggingface_model_references_docker_runs, skills_tao_finetune_huggingface_model_references_deliverables, skills_tao_finetune_huggingface_model_references_hardware_container, entrypoint_workaround, shm_size_16g, user_flag_convention [EXTRACTED 1.00]
- **Compatibility Workaround System** — skills_tao_finetune_huggingface_model_references_compat_workarounds, skills_tao_finetune_huggingface_model_references_error_playbook, idefics3_llama_generate, pytorch_2_5_sdpa_gqa, hf_hub_xet_hang, vlm_heterogeneous_pixel_values, phase_0_5_runner, phase_4_3_dockerfile_injection, compat_registry_invariants [EXTRACTED 1.00]
- **VLM-based Auto-Labeling Skills** — tao_generate_image_grounding, tao_generate_referring_expressions, tao_generate_video_reasoning_annotations [INFERRED 0.85]
- **TAO Toolkit Training Skills** — tao_finetune_huggingface_model, vlm_pipeline, unit_testing, smoke_testing [INFERRED 0.80]
- **auto_label CLI Pipelines** — image_grounding_pipeline, referring_expression_pipeline, video_reasoning_pipeline [EXTRACTED 1.00]
- **Video Annotation and Mining Workflow** — tao_generate_video_reasoning_annotations, tao_mine_aoi_images, tao_toolkit_data_services [INFERRED 0.85]
- **TAO Workflow Launch and Execution** — tao_launch_workflow, tao_port_huggingface_model, local_docker_platform [INFERRED 0.75]
- **7-Phase HF Model Porting Pipeline** — phase_0_prereqs, phase_1_hf_inspection, phase_2_codebase_exploration, phase_3_tao_core_implementation, phase_4_onnx_trt_export, phase_5_packaging_l0, phase_6_container_testing [EXTRACTED 1.00]
- **AutoML + DEFT Three-Phase Training Pipeline** — concept_automl_phase1, concept_deft_loop, concept_automl_phase3 [EXTRACTED 1.00]
- **TAO Model Porting Seven-Phase Workflow** — skills_tao_port_huggingface_model_references_phase_2_codebase, skills_tao_port_huggingface_model_references_phase_3_implementation, skills_tao_port_huggingface_model_references_phase_4_deploy, skills_tao_port_huggingface_model_references_phase_5_packaging, skills_tao_port_huggingface_model_references_phase_6_container_tests, skills_tao_port_huggingface_model_references_phase_7_optimization [EXTRACTED 1.00]
- **VCN Augmentation Module Routing** — concept_knn_mining, concept_anomalygen [EXTRACTED 0.95]
- **AutoML Algorithm Ecosystem** — concept_bayesian, concept_hyperband, concept_asha, concept_llm_guided, concept_autoresearch [EXTRACTED 0.95]
- **DEFT Augmentation Sources** — concept_anomalygen, concept_knn_mining, concept_synthetic_defects, concept_sdg [EXTRACTED 0.95]
- **DEFT Pipeline Stage Reference** — concept_rca, concept_sdg, concept_knn_mining, concept_visual_changenet, concept_far [EXTRACTED 0.85]
- **DEFT AOI Pipeline Stage Reference** — skills_tao_run_deft_aoi_references_visual_changenet, skills_tao_run_deft_aoi_references_tao_analyze_gaps_visual_changenet, skills_tao_run_deft_aoi_references_tao_route_visual_changenet_samples, skills_tao_run_deft_aoi_references_tao_mine_aoi_images [EXTRACTED 1.00]
- **TAO Platform Abstraction** — skills_tao_run_on_brev_skill, skills_tao_run_on_kubernetes_skill, skills_tao_run_inference_service_skill [EXTRACTED 1.00]
- **Cosmos Model Architectures** — cosmos_rl, cosmos_predict2_5, tao_dataservices [EXTRACTED 1.00]
- **TAO Platform SDK Ecosystem** — tao_sdk_python_library, docker_sdk, slurm_sdk, skills_tao_run_platform_skill [EXTRACTED 0.95]
- **SLURM Container Execution Stack** — slurm_scheduler, pyxis_enroot_runtime, lustre_storage, multi_node_training [EXTRACTED 1.00]
- **GPU Host Prerequisites** — nvidia_driver_branch_580, cuda_toolkit_13_0, nvidia_container_toolkit, docker_runtime, kubernetes_gpu_operator [EXTRACTED 1.00]
- **TAO Model Training Pipeline** — skills_tao_train_action_recognition_skill, skills_tao_train_bevfusion_skill, skills_tao_train_centerpose_skill [EXTRACTED 1.00]
- **AutoML-Enabled TAO Models** — skills_tao_train_action_recognition_skill, skills_tao_train_bevfusion_skill, skills_tao_train_centerpose_skill, concept_automl [EXTRACTED 1.00]
- **TAO Skill Bank Training Models** — skills_tao_train_action_recognition_skill, skills_tao_train_bevfusion_skill, skills_tao_train_centerpose_skill [EXTRACTED 1.00]
- **CenterPose TensorRT Deploy Workflow** — tao_train_centerpose_tao_deploy_centerpose, tao_train_centerpose_skill_info, tao_train_centerpose_spec_template_deploy_inference [EXTRACTED 1.00]
- **Deformable DETR Training Pipeline** — skills_tao_train_deformable_detr_skill_md, tao_train_deformable_detr_skill_info, tao_train_deformable_detr_spec_template_train, tao_train_deformable_detr_spec_template_evaluate, tao_train_deformable_detr_spec_template_export [EXTRACTED 1.00]
- **Deformable DETR TensorRT Deploy Workflow** — skills_tao_train_deformable_detr_skill_md, tao_train_deformable_detr_skill_info, tao_train_deformable_detr_spec_template_deploy_gen_trt_engine, tao_train_deformable_detr_spec_template_deploy_evaluate, tao_train_deformable_detr_spec_template_deploy_inference [EXTRACTED 1.00]
- **Depth Anything V2 Training Workflow** — skills_tao_train_depth_anything_v2_skill, skills_tao_train_depth_anything_v2_references_spec_overrides, skills_tao_train_depth_anything_v2_references_finetuning_recipes, skills_tao_train_depth_anything_v2_references_tao_deploy_depth_anything_v2 [EXTRACTED 1.00]
- **DepthNet Mono/Stereo Family** — metric_depth_anything, relative_depth_anything, depth_net_cli [EXTRACTED 1.00]
- **TAO Train Model Skills** — skills_tao_train_depth_anything_v2_skill, skills_tao_train_dino_skill, skills_tao_train_deformable_detr_skill_card [INFERRED 0.85]
- **DINO Training Pipeline Components** — tao_train_dino_dino_model, tao_train_dino_transformer_detection, tao_train_dino_automl, tao_train_dino_distillation, tao_train_dino_quantization [EXTRACTED 1.00]
- **DINO Deploy TensorRT Workflow** — tao_train_dino_dino_model, tao_train_dino_onnx_export, tao_train_dino_tensorrt, tao_train_dino_map50_metric [EXTRACTED 1.00]
- **FastFoundationStereo Depth Estimation Workflow** — tao_train_fast_foundation_stereo_ffs_model, tao_train_fast_foundation_stereo_stereo_depth, tao_train_fast_foundation_stereo_disparity_maps, tao_train_fast_foundation_stereo_edgenext_encoder, tao_train_fast_foundation_stereo_epe_metric [EXTRACTED 1.00]
- **FastFoundationStereo Deploy Pipeline** — action_export, action_gen_trt_engine, action_evaluate, format_onnx, tensorrt_engine [EXTRACTED 1.00]
- **Stereo Evaluation Metrics** — stereo_depth_evaluator, metric_epe, metric_bp1_bp2_bp3, metric_d1, metric_rmse [EXTRACTED 1.00]
- **FFS bp2 Critical Parameters** — model_fastfoundationstereo, param_max_disparity, param_volume_dim, param_gwc_feature_normalize, param_hidden_dims, param_n_gru_layers, checkpoint_bp2 [EXTRACTED 1.00]
- **FoundationStereo stereo inference pipeline** — foundation_stereo, stereo_dataset, generic_dataset, disparity_map, depth_anything_v2 [EXTRACTED 1.00]
- **Grounding DINO training and inference pipeline** — grounding_dino, dino_style_detection, language_guided_detection, bert_base_uncased, swin_tiny_backbone, open_set_object_detection [EXTRACTED 1.00]
- **TensorRT deployment pipeline** — gen_trt_engine, trt_fp16_deploy, torchao_quantization, depth_net, grounding_dino [EXTRACTED 1.00]
- **Classification PyT Actions** — tao_classification_pyt, onnx_export, gen_trt_engine, tensorrt_deployment [EXTRACTED 1.00]
- **MAE Deployment Pipeline** — tao_masked_auto_encoder, onnx_export, gen_trt_engine, tensorrt_deployment [EXTRACTED 1.00]
- **TAO Skills AutoML and Evaluation** — automl_enabled, nskills_eval, external_eval_profile, astra_sandbox [EXTRACTED 0.95]
- **MAE Training and Export Pipeline** — mae_model, tao_train_mask_auto_encoder_references_spec_template_train, tao_train_mask_auto_encoder_references_spec_template_export, tao_train_mask_auto_encoder_references_spec_template_gen_trt_engine, tensorrt_deployment [EXTRACTED 1.00]
- **MAL Training and Evaluation Workflow** — mal_model, vit_mae_backbone, skills_tao_train_mask_auto_label_skill, automl_hyperparameter_optimization, tao_train_mask_auto_label_references_spec_template_train, tao_train_mask_auto_label_references_spec_template_evaluate [EXTRACTED 1.00]
- **Mask Grounding DINO Full Pipeline** — mask_grounding_dino_model, grounding_dino_model, mask_prediction_head, swin_backbone, bert_text_encoder, tao_train_mask_grounding_dino_references_spec_template_train, tao_train_mask_grounding_dino_references_spec_template_export, tao_train_mask_grounding_dino_references_spec_template_quantize, tensorrt_deployment, automl_hyperparameter_optimization [EXTRACTED 1.00]
- **Mask Grounding DINO TAO Deploy workflow** — onnx_export, tensorrt_inference, skills_tao_train_mask_grounding_dino_references_tao_deploy_mask_grounding_dino [EXTRACTED 1.00]
- **Mask2Former TAO Deploy workflow** — onnx_export, tensorrt_inference, skills_tao_train_mask2former_references_tao_deploy_mask2former [EXTRACTED 1.00]
- **Mask2Former training pipeline** — skills_tao_train_mask2former_references_spec_template_evaluate, skills_tao_train_mask2former_references_spec_template_export, skills_tao_train_mask2former_references_spec_template_quantize, skills_tao_train_mask2former_references_skill_info [EXTRACTED 1.00]
- **TAO ML Recog Workflow** — skills_tao_train_metric_learning_recognition_skill_md, skills_tao_train_metric_learning_recognition_spec_template_train_yaml, skills_tao_train_metric_learning_recognition_spec_template_export_yaml, skills_tao_train_metric_learning_recognition_tao_deploy_metric_learning_recognition_md [EXTRACTED 1.00]
- **TAO NVDINOv2 Workflow** — skills_tao_train_nvdinov2_skill_md, skills_tao_train_nvdinov2_spec_template_train_yaml, skills_tao_train_nvdinov2_spec_template_export_yaml, skills_tao_train_nvdinov2_spec_template_deploy_gen_trt_engine_yaml [EXTRACTED 1.00]
- **AutoML-enabled TAO Skills** — skills_tao_train_metric_learning_recognition_skill_md, skills_tao_train_nvdinov2_skill_md, automl [EXTRACTED 1.00]
- **NVPanoptix3D Training Pipeline** — nvpanoptix3d, tao_train_action, automl, ddp_strategy, train_loss [EXTRACTED 0.85]
- **OCDNet Optimization Workflow** — ocdnet, prune_action, quantize_action, retrain_action, tao_train_action [EXTRACTED 0.85]
- **TAO Text Detection Pipeline** — ocdnet, deformable_resnet18, dbhead, differentiable_binarization, scene_text_detection [EXTRACTED 0.85]
- **TAO Text Processing Pipeline** — concept_ocdnet, concept_ocrnet, concept_tensorrt_deployment [INFERRED 0.75]
- **OneFormer Training Pipeline Components** — skills_tao_train_oneformer_skill, skills_tao_train_oneformer_skill_info, skills_tao_train_oneformer_spec_template_train, coco_panoptic_dataset, swin_transformer_backbone [EXTRACTED 1.00]
- **OneFormer TensorRT Deployment Pipeline** — skills_tao_train_oneformer_tao_deploy_oneformer, skills_tao_train_oneformer_deploy_skill_info, tensorrt_engine_generation, tao_deploy_workflow, oneformer_model [EXTRACTED 1.00]
- **TAO AutoML Training Pattern Across Models** — automl_enabled, skills_tao_train_oneformer_skill_info, skills_tao_train_optical_inspection_skill_info, skills_tao_train_pointpillars_skill_info [EXTRACTED 1.00]
- **Optical Inspection Complete Workflow** — skills_tao_train_optical_inspection_skill_card, tao_train_optical_inspection_references_spec_template_train, tao_train_optical_inspection_references_tao_deploy_optical_inspection, concept_tensorrt_deployment, concept_siamese_network_defect_detection [EXTRACTED 1.00]
- **PointPillars Complete ML Pipeline** — skills_tao_train_pointpillars_skill, tao_train_pointpillars_references_spec_template_dataset_convert, tao_train_pointpillars_references_spec_template_train, tao_train_pointpillars_references_spec_template_export, tao_train_pointpillars_references_tao_deploy_pointpillars, concept_3d_object_detection, concept_lidar_point_clouds, concept_tensorrt_deployment [EXTRACTED 1.00]
- **PointPillars TensorRT Deploy Actions** — tao_train_pointpillars_references_spec_template_deploy_gen_trt_engine, tao_train_pointpillars_references_spec_template_deploy_evaluate, tao_train_pointpillars_references_spec_template_deploy_inference, concept_tao_deploy_pointpillars [EXTRACTED 1.00]
- **TAO Model Training Pipeline** — skills_tao_train_pose_classification_skill, skills_tao_train_reid_skill, skills_tao_train_rtdetr_skill [EXTRACTED 1.00]
- **AutoML-Enabled TAO Models** — skills_tao_train_pose_classification_skill, skills_tao_train_reid_skill, skills_tao_train_rtdetr_skill [EXTRACTED 1.00]
- **NVSkills-Eval Evaluated Skills** — skills_tao_train_pose_classification_benchmark, skills_tao_train_reid_benchmark, skills_tao_train_rtdetr_benchmark [EXTRACTED 1.00]
- **RT-DETR and SegFormer TensorRT Deployment Patterns** — tensorrt_deployment, skills_tao_train_rtdetr_action_gen_trt_engine, skills_tao_train_segformer_action_gen_trt_engine [INFERRED 0.85]
- **TAO Toolkit Computer Vision Workflows** — object_detection, semantic_segmentation, skills_tao_train_rtdetr_rtdetr_model, skills_tao_train_segformer_model_arch [INFERRED 0.85]
- **TAO Model Training Pipeline Actions** — skills_tao_train_segformer_action_train, skills_tao_train_segformer_action_evaluate, skills_tao_train_segformer_action_export, skills_tao_train_segformer_action_quantize [EXTRACTED 1.00]
- **TAO Train/Eval/Export Workflow Pattern** — tao_train_single_step_workflow, skills_tao_train_single_step_skill, skills_tao_train_sparse4d_skill, skills_tao_train_visual_changenet_skill [EXTRACTED 1.00]
- **AutoML-Enabled TAO Models** — skills_tao_train_sparse4d_references_skill_info, skills_tao_train_sparse4d_skill, automl_policy [EXTRACTED 1.00]
- **Visual ChangeNet Task Modes** — visual_changenet, visual_changenet_classify, visual_changenet_segment, c_radio_v2_backbone [EXTRACTED 1.00]
- **Visual ChangeNet Training Pipeline** — c_radio_v2_b, adamw_optimizer, cross_entropy_loss, wandb [EXTRACTED 0.95]
- **Visual ChangeNet Deployment Pipeline** — onnx_export, tensorrt_engine, weight_only_ptq [EXTRACTED 0.95]
- **Visual ChangeNet Segmentation Stack** — vit_large_nvdinov2, cn_dataset, levir_cd [EXTRACTED 0.95]
- **TileGym cuTile Kernel Ecosystem** — concept_tilegym_library, concept_cutile_gpu_kernel, concept_cutil_jl, concept_triton_jit [EXTRACTED 0.95]
- **TileGym cuTile Conversion Skills** — skills_tilegym_adding_cutile_kernel_skill, skills_tilegym_converting_cutile_to_julia_skill, skills_tilegym_converting_cutile_to_triton_skill [EXTRACTED 0.95]
- **Julia Conversion Reference Documentation** — skills_tilegym_converting_cutile_to_julia_references_api_mapping, skills_tilegym_converting_cutile_to_julia_references_critical_rules, skills_tilegym_converting_cutile_to_julia_translations_workflow, skills_tilegym_converting_cutile_to_julia_references_testing [EXTRACTED 0.90]
- **CuTile Autotuning Reference Documents** — tilegym_cutile_autotuning_references_api_reference, tilegym_cutile_autotuning_references_workflow, tilegym_cutile_autotuning_references_pitfalls, tilegym_cutile_autotuning_references_parameter_space_design, tilegym_cutile_autotuning_references_search_strategies, tilegym_cutile_autotuning_references_kernel_type_templates, tilegym_cutile_autotuning_references_hardware_constraints [EXTRACTED 1.00]
- **cuTile Python Example Categories** — tilegym_cutile_python_examples_convolution_readme, tilegym_cutile_python_examples_matmul_readme, tilegym_cutile_python_examples_normalization_readme, tilegym_cutile_python_examples_pooling_readme, tilegym_cutile_python_examples_scan_readme [EXTRACTED 1.00]
- **NVIDIA GPU Architecture Generations** — sm80_sm86, sm90, sm100, sm103, sm120 [EXTRACTED 1.00]
- **Deep Agent Orchestration Pipeline** — tilegym_cutile_python_orchestration_analyzer_agent, tilegym_cutile_python_orchestration_kernel_agent, tilegym_cutile_python_orchestration_composer_agent, tilegym_cutile_python_torch_learner_tracing_workflow [EXTRACTED 1.00]
- **PyTorch Tracing Reference Set** — tilegym_cutile_python_torch_learner_references_1_pytorch_codebase_map, tilegym_cutile_python_torch_learner_references_2_dispatch_mechanism, tilegym_cutile_python_torch_learner_references_3_tracing_strategies, tilegym_cutile_python_torch_learner_references_4_language_layers [EXTRACTED 1.00]
- **cuTile Kernel Performance Optimization Ecosystem** — tilegym_improve_cutile_kernel_perf_references_cutile_api_reference, tilegym_improve_cutile_kernel_perf_references_cutile_patterns_reference, tilegym_improve_cutile_kernel_perf_references_ir_dump_guide, skills_tilegym_improve_cutile_kernel_perf_skill [EXTRACTED 1.00]
- **cuTile Kernel Optimization Ecosystem** — tilegym_improve_cutile_kernel_perf_references_optimization_playbook, tilegym_improve_cutile_kernel_perf_references_perf_knobs_catalog, tilegym_improve_cutile_kernel_perf_references_performance_model, skills_tilegym_improve_cutile_kernel_perf_skill_card, concept_tma_tensor_memory_accelerator, concept_persistent_scheduling, concept_autotune, concept_tile_size_tuning [EXTRACTED 0.95]
- **Sentence-Transformers Training Types** — concept_sentence_transformer_bi_encoder, concept_cross_encoder, concept_sparse_encoder, skills_train_sentence_transformers_skill, train_sentence_transformers_references_evaluators_sentence_transformer, train_sentence_transformers_references_evaluators_cross_encoder, train_sentence_transformers_references_evaluators_sparse_encoder [EXTRACTED 0.95]
- **TileGym Transformers Integration Workflow** — skills_tilegym_monkey_patch_kernels_to_transformers_skill, tilegym_monkey_patch_kernels_to_transformers_references_environment_setup, tilegym_monkey_patch_kernels_to_transformers_references_kernel_integration, tilegym_monkey_patch_kernels_to_transformers_references_auto_kernelize, tilegym_monkey_patch_kernels_to_transformers_references_kernel_inventory_schema, concept_monkey_patch, concept_flashinfer_schema, concept_cutile_kernel_coverage [EXTRACTED 0.95]
- **SentenceTransformer Training Ecosystem** — skills_train_sentence_transformers_references_model_architectures, skills_train_sentence_transformers_references_training_args, skills_train_sentence_transformers_references_prompts_and_instructions, skills_train_sentence_transformers_references_troubleshooting [EXTRACTED 1.00]
- **Transformers.js Inference Stack** — skills_transformers_js_skill, skills_transformers_js_references_pipeline_options, skills_transformers_js_references_configuration, skills_transformers_js_references_cache [EXTRACTED 1.00]
- **VSS RT-VLM Deployment Stack** — skills_vss_deploy_dense_captioning_skill, skills_vss_deploy_dense_captioning_references_deploy_service, skills_vss_deploy_dense_captioning_references_api_surface, skills_vss_deploy_dense_captioning_references_kafka_workflows [EXTRACTED 1.00]
- **vss-deploy-detection-tracking-2d skill structure** — vss_deploy_detection_tracking_2d, skills_vss_deploy_detection_tracking_2d_assets_deploy_defaults, skills_vss_deploy_detection_tracking_2d_references_deploy_vss_detection_tracking_2d, skills_vss_deploy_detection_tracking_2d_references_usage, skills_vss_deploy_detection_tracking_2d_references_task_list, skills_vss_deploy_detection_tracking_2d_references_teardown_flow, skills_vss_deploy_detection_tracking_2d_references_workflow_reference [EXTRACTED 1.00]
- **DEPLOY workflow steps 1-6** — skills_vss_deploy_detection_tracking_2d_references_resource_plan, skills_vss_deploy_detection_tracking_2d_references_pipeline_config, skills_vss_deploy_detection_tracking_2d_references_container_reuse, skills_vss_deploy_detection_tracking_2d_references_apply_config, skills_vss_deploy_detection_tracking_2d_references_start_app, skills_vss_deploy_detection_tracking_2d_references_next_steps [EXTRACTED 1.00]
- **Four inference engines supported by RTVI-CV** — nvinfer_engine, videotemplate_plugin, nvinferserver_triton, usecase_warehouse_2d, usecase_warehouse_3d, usecase_smartcity_rtdetr, usecase_smartcity_gdino [EXTRACTED 1.00]
- **MV3DT Deploy Workflow Components** — skills_vss_deploy_detection_tracking_3d_skill, skills_vss_deploy_detection_tracking_3d_references_calibration_workflow, skills_vss_deploy_detection_tracking_3d_references_configure_cameras, skills_vss_deploy_detection_tracking_3d_references_deploy_rtvi_cv_3d_stack, skills_vss_deploy_detection_tracking_3d_references_verify_and_view [EXTRACTED 1.00]
- **VSS Profile Types** — base_profile, lvs_profile, alerts_profile, skills_vss_deploy_profile_references_warehouse_profile, skills_vss_deploy_profile_references_edge_deployment [EXTRACTED 1.00]
- **MV3DT Calibration and Camera Setup** — skills_vss_deploy_detection_tracking_3d_references_calibration_workflow, camera_name_normalization, num_streams_sync, automagiccalib_amc [EXTRACTED 0.85]

## Communities (1522 total, 534 thin omitted)

### Community 0 - "TAO Dataset Spec"
Cohesion: 0.06
Nodes (113): dataset.class_names, dataset.data_augmentor, dataset.data_augmentor.aug_config_list, dataset.data_augmentor.disable_aug_list, dataset.data_processor, dataset.data_split, dataset.info_path, dataset.point_cloud_range (+105 more)

### Community 1 - "TAO Manifest Actions"
Cohesion: 0.05
Nodes (108): actions, evaluate, export, inference, quantize, train, automl_enabled, automl_default_parameters (+100 more)

### Community 2 - "TAO Augmentation Config"
Cohesion: 0.05
Nodes (105): dataset.augmentation.random_aug.enable, dataset.augmentation.random_color.brightness, dataset.augmentation.random_color.color_probability, dataset.augmentation.random_color.contrast, dataset.augmentation.random_color.enable, dataset.augmentation.random_color.hue, dataset.augmentation.random_color.saturation, dataset.augmentation.random_erase.enable (+97 more)

### Community 3 - "TAO Classify Augmentation"
Cohesion: 0.05
Nodes (105): dataset.classify.augmentation_config.augment, dataset.classify.augmentation_config.random_color.brightness, dataset.classify.augmentation_config.random_color.color_probability, dataset.classify.augmentation_config.random_color.contrast, dataset.classify.augmentation_config.random_color.enable, dataset.classify.augmentation_config.random_color.hue, dataset.classify.augmentation_config.random_color.saturation, dataset.classify.augmentation_config.random_flip.enable (+97 more)

### Community 4 - "AIQ Python Client"
Cohesion: 0.05
Nodes (89): _api_request(), _binary_request(), cancel_job(), chat_request(), _checked_job_status(), _command_agents(), _command_artifacts(), _command_cancel() (+81 more)

### Community 5 - "Sensor Calibration Config"
Cohesion: 0.07
Nodes (88): dataset.cam2img, dataset.lidar2cam, dataset.origin, dataset.test_dataset.data_prefix, dataset.train_dataset.data_prefix, dataset.val_dataset.data_prefix, default_hooks, input_modality (+80 more)

### Community 6 - "Manifest Validator"
Cohesion: 0.08
Nodes (83): build_manifest(), _check_asset_validator(), _check_content_agents(), _check_content_agents_deployment_host(), _check_git_lfs(), _check_openusd_python(), _check_repo_python(), _check_request_inputs() (+75 more)

### Community 7 - "Train Eval Config"
Cohesion: 0.05
Nodes (81): dataset.window_size, evaluate.test_dataset, inference.test_dataset, model.dropout, train.grad_clip, train.optim.patience, actions, evaluate (+73 more)

### Community 8 - "TAO Action Pipeline"
Cohesion: 0.04
Nodes (81): actions, evaluate, export, inference, prune, train, box_thresh, max_candidates (+73 more)

### Community 9 - "Augmentation Dimensions"
Cohesion: 0.12
Nodes (77): dataset.augmentation.bot_pct_lim, dataset.augmentation.final_dim, dataset.augmentation.image_size, dataset.augmentation.resize_lim, dataset.augmentation.rot3d_range, dataset.augmentation.rot_lim, dataset.normalize, dataset.normalize.mean (+69 more)

### Community 10 - "Normalization Config"
Cohesion: 0.05
Nodes (76): dataset.augmentation_config.of_input_mean, dataset.augmentation_config.of_input_std, dataset.augmentation_config.scales, model.dropout_ratio, actions, evaluate, export, inference (+68 more)

### Community 11 - "TAO CLI Entry Points"
Cohesion: 0.09
Nodes (68): _apply_material_auto_optimizer(), _apply_physics_auto_optimizer(), _attempt_summary(), _base_report(), _command(), _convert_physics_output_to_usd(), _download_artifact(), _emit_report() (+60 more)

### Community 12 - "Classify Augmentation"
Cohesion: 0.16
Nodes (69): dataset.classify, dataset.classify.augmentation_config, dataset.classify.augmentation_config.random_color, dataset.classify.augmentation_config.random_flip, dataset.classify.augmentation_config.random_rotate, dataset.classify.augmentation_config.random_rotate.angle_list, dataset.classify.augmentation_config.rgb_input_mean, dataset.classify.augmentation_config.rgb_input_std (+61 more)

### Community 13 - "Script Entry Points"
Cohesion: 0.05
Nodes (56): check_dependencies(), main(), Any, Path, _write_report(), check_dependencies(), main(), Any (+48 more)

### Community 14 - "TAO Spec Manifest"
Cohesion: 0.04
Nodes (68): actions, dataset_convert, evaluate, gen_trt_engine, inference, prune, quantize, retrain (+60 more)

### Community 15 - "Distributed Training Config"
Cohesion: 0.14
Nodes (67): automl_disabled_parameters, automl_disabled_parameters, automl_disabled_parameters, dataset, dataset.infer_dataset, dataset.infer_dataset.augmentation, dataset.infer_dataset.augmentation.color_aug_hue_range, dataset.infer_dataset.augmentation.color_aug_saturation (+59 more)

### Community 16 - "Inference Config"
Cohesion: 0.14
Nodes (67): automl_disabled_parameters, automl_disabled_parameters, automl_disabled_parameters, dataset, dataset.infer_dataset, dataset.infer_dataset.augmentation, dataset.infer_dataset.augmentation.color_aug_hue_range, dataset.infer_dataset.augmentation.color_aug_saturation (+59 more)

### Community 17 - "Training Hyperparameters"
Cohesion: 0.05
Nodes (63): model.frozen_stages, train.margin_rate, train.mask_thres, train.test_margin_rate, train.wd, actions, evaluate, inference (+55 more)

### Community 18 - "DT Generator Scripts"
Cohesion: 0.06
Nodes (60): _apply_direction_state(), _apply_electrical(), _apply_one_edit(), apply_pin_edits(), build_pinmap_records(), _build_pinrow(), _collect_gpio_buckets(), _detect_data_sheet() (+52 more)

### Community 19 - "TAO Run Logic"
Cohesion: 0.08
Nodes (58): _collect_stage_stats(), _decode_png(), _emit(), _endpoint_host(), _endpoint_kind(), _endpoint_requires_token(), _env_first(), _env_first_named() (+50 more)

### Community 20 - "CUDA/GPU Config"
Cohesion: 0.04
Nodes (60): actions, distill, evaluate, export, inference, quantize, train, automl_enabled (+52 more)

### Community 21 - "Docker Container Build"
Cohesion: 0.21
Nodes (60): dataset.augmentation.random_aug, dataset.augmentation.random_color, dataset.augmentation.random_erase, dataset.augmentation.random_flip, dataset.augmentation.random_rotate, dataset.augmentation.random_rotate.angle_list, dataset.augmentation.with_scale_random_crop, dataset.augmentation.with_scale_random_crop.scale_range (+52 more)

### Community 22 - "Model Export Config"
Cohesion: 0.18
Nodes (60): dataset.train_dataset.args, dataset.train_dataset.args.filter_keys, dataset.train_dataset.args.ignore_tags, dataset.train_dataset.args.pre_processes, dataset.train_dataset.data_path, dataset.train_dataset.loader, dataset.train_dataset.loader.batch_size, dataset.validate_dataset (+52 more)

### Community 23 - "API Client"
Cohesion: 0.04
Nodes (58): actions, evaluate, export, inference, quantize, train, automl_enabled, core_module (+50 more)

### Community 24 - "Jetson BSP Config"
Cohesion: 0.19
Nodes (58): dataset.task_prob_train, dataset.task_prob_val, inference.image_size, model.backbone.radio, model.backbone.radio.out_features, model.backbone.radio.resolution, model.backbone.radio.summary_idxs, model.one_former (+50 more)

### Community 25 - "Plugin Management"
Cohesion: 0.05
Nodes (55): actions, distill, evaluate, export, quantize, train, automl_enabled, core_module (+47 more)

### Community 26 - "DeepStream Config"
Cohesion: 0.05
Nodes (55): actions, evaluate, export, inference, quantize, train, automl_enabled, automl_default_parameters (+47 more)

### Community 27 - "HuggingFace Skills"
Cohesion: 0.06
Nodes (28): print_log(), Test metadata endpoint, Test Prometheus metrics endpoint, Test file management endpoints, Full workflow: upload → list → chat → download → delete → verify 404, Test chat completion endpoint, Non-streaming chat completion with base64 video, Streaming chat completion returns SSE chunks (+20 more)

### Community 28 - "Data Processing"
Cohesion: 0.06
Nodes (55): type, type, type, type, type, type, type, type (+47 more)

### Community 29 - "ML Training Pipeline"
Cohesion: 0.05
Nodes (54): Batched Inference, BufferProvider and Feeder API, BufferRetriever and Receiver API, Custom Protocol Adapter, DeepSORT Tracker, DeepStream Development Skill, Best Practices and Design Patterns, Buffer Provider and Retriever APIs (+46 more)

### Community 30 - "Community 30"
Cohesion: 0.05
Nodes (54): build.nvidia.com, Canary Model, Clinical ASR Flywheel, gRPC Protocol, HTTP Protocol, Keyword Error Rate, Language Model Integration, Magpie TTS (+46 more)

### Community 31 - "Community 31"
Cohesion: 0.08
Nodes (53): audit_existing_datalist(), _audit_volume(), build_override(), compare_checkpoint_weights(), _config_arg(), _copy_if_missing_or_broken(), _copy_upstream_config(), detect_env() (+45 more)

### Community 32 - "Community 32"
Cohesion: 0.21
Nodes (52): dataset.augmentation.eval_spatial_size, dataset.augmentation.multi_scales, dataset.augmentation.train_spatial_size, model.feat_channels, model.feat_strides, model.frozen_fm, model.use_encoder_idx, train.ema (+44 more)

### Community 33 - "Community 33"
Cohesion: 0.18
Nodes (51): dataset.test.target_size, dataset.train.target_size, dataset.val.target_size, model.backbone.efficientvit, model.backbone.efficientvit.out_features, model.backbone.efficientvit.out_indices, automl_disabled_parameters, automl_disabled_parameters (+43 more)

### Community 34 - "Community 34"
Cohesion: 0.18
Nodes (50): automl_default_parameters, automl_default_parameters, automl_default_parameters, dataset.infer_dataset.augmentation.color_aug_prob, dataset.infer_dataset.augmentation.crop_min_valid_disp_ratio, dataset.infer_dataset.augmentation.eraser_aug_prob, dataset.infer_dataset.augmentation.h_flip_prob, dataset.infer_dataset.augmentation.hshift_prob (+42 more)

### Community 35 - "Community 35"
Cohesion: 0.08
Nodes (49): AGX Orin Platform, AGX Thor Platform, DGX Spark Platform, FPGA Version 2407, FPGA Version 2412, FPGA Version 2507, FPGA Version 2510, FPGA Flash Procedure (+41 more)

### Community 36 - "Community 36"
Cohesion: 0.24
Nodes (49): dataset.augmentation.gaussian_radius_list, dataset.train_dataset_dir, prune.prune_setting, export, train, automl_disabled_parameters, automl_disabled_parameters, automl_disabled_parameters (+41 more)

### Community 37 - "Community 37"
Cohesion: 0.10
Nodes (40): check_dependencies(), _env_first(), _env_or_file_first(), main(), Any, Path, _skill_name(), _write_report() (+32 more)

### Community 38 - "Community 38"
Cohesion: 0.22
Nodes (49): automl_disabled_parameters, automl_disabled_parameters, automl_disabled_parameters, automl_disabled_parameters, dataset, dataset.augmentation, dataset.augmentation.input_mean, dataset.augmentation.input_std (+41 more)

### Community 39 - "Community 39"
Cohesion: 0.19
Nodes (48): dataset.segment.palette, automl_disabled_parameters, automl_disabled_parameters, automl_disabled_parameters, dataset, dataset.segment, dataset.segment.augmentation, dataset.segment.augmentation.mean (+40 more)

### Community 40 - "Community 40"
Cohesion: 0.05
Nodes (47): type, items, type, items, type, properties, required, type (+39 more)

### Community 41 - "Community 41"
Cohesion: 0.19
Nodes (47): automl_disabled_parameters, automl_disabled_parameters, automl_disabled_parameters, dataset, dataset.augmentation, dataset.augmentation.input_mean, dataset.augmentation.input_std, dataset.augmentation.scales (+39 more)

### Community 42 - "Community 42"
Cohesion: 0.19
Nodes (47): automl_disabled_parameters, automl_disabled_parameters, automl_disabled_parameters, dataset, dataset.augmentation, dataset.augmentation.input_mean, dataset.augmentation.input_std, dataset.augmentation.scales (+39 more)

### Community 43 - "Community 43"
Cohesion: 0.05
Nodes (45): component_body_candidates, rigid_body_roots_after, type, items, type, items, type, type (+37 more)

### Community 44 - "Community 44"
Cohesion: 0.09
Nodes (45): build_best_f1_missed_no_pass_rows(), build_candidate_thresholds(), build_histogram_bins(), clean_label(), compute_all_metrics(), compute_f1(), compute_metrics_for_threshold(), format_far_percentage() (+37 more)

### Community 45 - "Community 45"
Cohesion: 0.06
Nodes (46): export, quantize, gpu_ids, num_gpus, num_nodes, popular, core_module, path (+38 more)

### Community 46 - "Community 46"
Cohesion: 0.06
Nodes (46): export, quantize, gpu_ids, num_gpus, num_nodes, popular, core_module, path (+38 more)

### Community 47 - "Community 47"
Cohesion: 0.06
Nodes (46): evaluate, gen_trt_engine, inference, core_module, gpu_ids, num_gpus, num_nodes, path (+38 more)

### Community 48 - "Community 48"
Cohesion: 0.20
Nodes (45): automl_disabled_parameters, automl_disabled_parameters, automl_disabled_parameters, dataset, dataset.augmentation, dataset.augmentation.input_mean, dataset.augmentation.input_std, dataset.augmentation.scales (+37 more)

### Community 49 - "Community 49"
Cohesion: 0.16
Nodes (41): _base_report(), _build_bom(), _compute_content_hash(), _compute_package_hash(), _content_files(), create_package(), _emit(), _errors_from_checks() (+33 more)

### Community 50 - "Community 50"
Cohesion: 0.06
Nodes (43): 3D Parallelism (TP+PP+DP), 4D Parallelism (TP+PP+CP+DP), CommOverlapConfig, Context Parallelism (CP), Data Parallelism (DP), DeepSeek Recipes, Dense Models, Distributed Optimizer (+35 more)

### Community 51 - "Community 51"
Cohesion: 0.06
Nodes (43): Alert Bridge, AutoMagicCalib, CLIP_STORAGE_PATH, CV Verification Mode, Incident Range, NvStreamer, RT-VLM, SDR Controller (SDRC) (+35 more)

### Community 52 - "Community 52"
Cohesion: 0.06
Nodes (43): Finetune Flow, AnomalyGen Phase 1, Cookbook (ag_config.yaml), DIG URL Root, predict2_anomaly_gen_ddp_2b, prep_testcase.sh, Use Case (pcb/metal_surface/glass), validate_dataset.py (+35 more)

### Community 53 - "Community 53"
Cohesion: 0.18
Nodes (42): dataset.augmentation.crop_size, dataset.depth_size, dataset.occ_truncation_lvl, dataset.reduced_target_size, dataset.target_size, dataset.truncation_range, model.frustum3d, model.frustum3d.completion_weights (+34 more)

### Community 54 - "Community 54"
Cohesion: 0.07
Nodes (40): Augmentation Group, Auto Labeling Augmented, Auto Labeling Original, MicroK8s Cluster Reference, Image Edit Augmentation, LLM Endpoint URL, MCQ Verification, NVIDIA Hosted (+32 more)

### Community 55 - "Community 55"
Cohesion: 0.06
Nodes (14): Future, Support for context manager (with statement), Support for context manager (with statement), Get elapsed time since start or last reset, Reset the timer to current time, Get execution time since start or last reset, Get execution time since start or last reset, SafeThreadEventLoop (+6 more)

### Community 56 - "Community 56"
Cohesion: 0.06
Nodes (39): additionalProperties, type, type, type, type, type, type, agent (+31 more)

### Community 57 - "Community 57"
Cohesion: 0.06
Nodes (39): additionalProperties, type, type, type, type, type, type, agent (+31 more)

### Community 58 - "Community 58"
Cohesion: 0.06
Nodes (39): additionalProperties, type, type, type, type, type, type, agent (+31 more)

### Community 59 - "Community 59"
Cohesion: 0.06
Nodes (39): additionalProperties, type, type, type, type, type, type, agent (+31 more)

### Community 60 - "Community 60"
Cohesion: 0.05
Nodes (39): additionalProperties, type, type, type, backend, checks, errors, next_step (+31 more)

### Community 61 - "Community 61"
Cohesion: 0.05
Nodes (39): additionalProperties, type, type, type, backend, checks, errors, next_step (+31 more)

### Community 62 - "Community 62"
Cohesion: 0.05
Nodes (39): additionalProperties, type, type, type, backend, checks, errors, next_step (+31 more)

### Community 63 - "Community 63"
Cohesion: 0.06
Nodes (39): HdrColor AOV, LdrColor AOV, NormalSD AOV, ovrtx Renderer, ovstream Library, Warp GPU Library, omni:xform Attribute, Orbit Camera (+31 more)

### Community 64 - "Community 64"
Cohesion: 0.11
Nodes (38): Deploy Workflow, Engine Cache, Grounding DINO Model, metropolis_perception_app, NGC Credentials, NVIDIA NGC, nvinfer Inference Engine, Triton nvinferserver (+30 more)

### Community 65 - "Community 65"
Cohesion: 0.06
Nodes (38): Astra Sandbox Environment, Validation Guide, PR Body Template, PR Comment Template, Earth2Studio Data Source, Earth2Studio Diagnostic Model, earth2studio.run.deterministic, External Evaluation Profile (+30 more)

### Community 66 - "Community 66"
Cohesion: 0.06
Nodes (38): Blackwell Optimization Patterns, tilegym-cutile-autotuning Skill, tilegym-converting-cutile-to-triton Skill, Dual Layout Flag Pattern, exhaustive_search API, Kernel Hints (occupancy, num_ctas), Kernel Type Template, num_ctas (CTA per CGA) (+30 more)

### Community 67 - "Community 67"
Cohesion: 0.09
Nodes (38): Analysis Only (No Modification), Bounded Loss Optimization, Lossless Optimization, omni.scene.optimizer.core Extension, Pipeline: Load Time Reduction, Pipeline: Memory Reduction, Pipeline: Mesh Count Reduction, Pipeline: Safe Cleanup (+30 more)

### Community 68 - "Community 68"
Cohesion: 0.07
Nodes (38): Object Detection, Semantic Segmentation, RT-DETR Distill Action, RT-DETR Evaluate Action, RT-DETR Export Action, RT-DETR TensorRT Engine Generation, RT-DETR Inference Action, RT-DETR Quantize Action (+30 more)

### Community 69 - "Community 69"
Cohesion: 0.23
Nodes (38): dataset.augmentation_config.random_color, dataset.augmentation_config.random_flip, dataset.augmentation_config.random_rotate, dataset.augmentation_config.random_rotate.angle_list, dataset.grid_map, dataset.input_map, dataset.validation_dataset, automl_disabled_parameters (+30 more)

### Community 70 - "Community 70"
Cohesion: 0.12
Nodes (37): _aggregate(), _detect_cuda(), _effective_anatomy_names(), _estimate_cost(), _expected_output_label_mapping(), _failure_reasons(), _load_config_override(), main() (+29 more)

### Community 71 - "Community 71"
Cohesion: 0.16
Nodes (36): _apply_single_component_rbmb001_policy(), _blocked_report(), _build_command(), _cli_help(), _dedupe_requirements(), emit(), _empty_counts(), _empty_topology() (+28 more)

### Community 72 - "Community 72"
Cohesion: 0.11
Nodes (37): ConceptResolutionError, coverage_complete(), _expand_target(), get_rule_registry(), get_validation_engine_cls(), _iter_execution_units(), iter_registered_rules(), load_registry() (+29 more)

### Community 73 - "Community 73"
Cohesion: 0.12
Nodes (37): categorize_skill_dir(), collect_repo_signals(), count_arguments_usage(), emit_read_next_guidance(), emit_signal_summary(), extract_repo_contents(), extract_skill_contents(), find_agents() (+29 more)

### Community 74 - "Community 74"
Cohesion: 0.06
Nodes (37): API Test Suite, AsyncLLMEngine for Concurrent Requests, Basler Camera Support, BufferRetriever Static Base Requirement, Camera Emulation Mode, Chat Completion Endpoint, Chunking Options Union, Cosmos Reason VLM (+29 more)

### Community 75 - "Community 75"
Cohesion: 0.05
Nodes (36): file_name, local_identifiers, recommended_web_queries, suffix, additionalProperties, type, type, type (+28 more)

### Community 76 - "Community 76"
Cohesion: 0.08
Nodes (34): SimpleNamespace, benchmark_rmsnorm(), Constant, Tensor, RMSNorm kernel.  Occupancy is supplied at runtime via replace_hints.      Steps, Occupancy-only search: try 1, 2, 4, 8 CTAs per SM., Host wrapper: RMSNorm with exhaustive_search + cache (occupancy-only search)., _ref_rmsnorm() (+26 more)

### Community 77 - "Community 77"
Cohesion: 0.08
Nodes (37): evaluate, core_module, gpu_ids, num_gpus, num_nodes, path, popular, schema_action (+29 more)

### Community 78 - "Community 78"
Cohesion: 0.10
Nodes (36): OSMO Checkpointing Pattern, OSMO Combination Pipelines Pattern, OSMO Credentials System, OSMO Data Credentials, Azure Device Code Login, OSMO Exit Action Error Handling, OSMO Generic Credentials, NVCF Inference Component (+28 more)

### Community 79 - "Community 79"
Cohesion: 0.06
Nodes (35): key, requires_extension, since_version, $comment, description, properties, required, type (+27 more)

### Community 80 - "Community 80"
Cohesion: 0.06
Nodes (35): kit_application, operations_available, so_build_date, so_extension_version, $comment, description, type, probed_at (+27 more)

### Community 81 - "Community 81"
Cohesion: 0.06
Nodes (36): type, type, properties, type, type, type, type, type (+28 more)

### Community 82 - "Community 82"
Cohesion: 0.06
Nodes (36): CLIP Evaluate Action, CLIP Export Action (ONNX), CLIP TensorRT Engine Generation, CLIP Inference Action, CLIP Model (ViT-L-14-SigLIP-CLIPA-224), CLIP Export Spec Template, CLIP Train Spec Template, CLIP Deploy Workflow Guide (+28 more)

### Community 83 - "Community 83"
Cohesion: 0.08
Nodes (35): Binary Variables, Continuous Variables, Dual Values, Infeasible Problem, Integer Variables, Linear Programming (LP), Mixed Integer Linear Programming (MILP), MPS File Format (+27 more)

### Community 84 - "Community 84"
Cohesion: 0.07
Nodes (35): before, change_pct, disposition, id, method, order, result, score (+27 more)

### Community 85 - "Community 85"
Cohesion: 0.06
Nodes (34): output_image_path, renderer_skill, additionalProperties, type, type, type, type, asset_path (+26 more)

### Community 86 - "Community 86"
Cohesion: 0.11
Nodes (32): build_tags(), create_model(), log(), make_endpoint_name(), parse_env(), Any, Shared helpers for the deployment scripts (deploy.py, deploy_async.py).  Anythin, Poll DescribeEndpoint until InService, or raise on Failed/timeout. (+24 more)

### Community 87 - "Community 87"
Cohesion: 0.15
Nodes (34): _build_parser(), _call_hf_space_endpoint(), _cuda_report(), _hf_space_chat_fn_index(), _hf_space_image_payload(), _http_fetch(), _image_info(), ImageInfo (+26 more)

### Community 88 - "Community 88"
Cohesion: 0.08
Nodes (14): Path, classify_bound applies the boundedness-rules.md decision tree., compute_capacity treats the measured peak as authoritative., _arch_bucket_from_compute_cap chooses the right NVDEC throughput bucket., _nvdec_count_for_gpu matches by substring., parse_microbench handles current + legacy schema and skips garbage., parse_dmon extracts max(SM/mem/dec) from a `nvidia-smi dmon -s mu` log., TestArchBucketLookup (+6 more)

### Community 89 - "Community 89"
Cohesion: 0.09
Nodes (17): BaseMessageConsumer, BaseMessageProducer, convert_to_vision_llm(), create_consumer(), create_producer(), _delivery_report(), JSONMessageConsumer, JSONMessageProducer (+9 more)

### Community 90 - "Community 90"
Cohesion: 0.07
Nodes (24): Package, PrognosticModel, Default pre-trained model package on HuggingFace/NGC/S3.          Returns, Load prognostic model from package.          Parameters         ----------, PhooModelName, Tensor, Create a dummy model package for testing.      This fixture creates a temporary, # TODO: Add additional files if needed (+16 more)

### Community 91 - "Community 91"
Cohesion: 0.06
Nodes (34): type, type, type, type, type, type, items, type (+26 more)

### Community 92 - "Community 92"
Cohesion: 0.18
Nodes (33): _build_command_plan(), build_parser(), _config_sources(), _create_embedding_sidecars(), _emit(), _empty_output(), _git_commit(), _load_json() (+25 more)

### Community 93 - "Community 93"
Cohesion: 0.06
Nodes (33): type, items, type, type, type, checks, errors, input_usd_path (+25 more)

### Community 94 - "Community 94"
Cohesion: 0.11
Nodes (33): AutoML / Hyperparameter Optimization, COCO Dataset Format, Cosmos-RL Supervised Fine-Tuning, Knowledge Distillation, Pose Classification Task, Model Quantization, Person Re-Identification Task, Real-Time Object Detection (+25 more)

### Community 95 - "Community 95"
Cohesion: 0.07
Nodes (33): CLIP AutoML, CLIP Vision-Language Model, DAFT Dataset Format Conversion, FP/FN Extraction, Gap Analysis, NVSkills-Eval Evaluation Framework, TAO VCN Gap Analysis Benchmark, TAO VLM BCQ Benchmark (+25 more)

### Community 96 - "Community 96"
Cohesion: 0.12
Nodes (13): OrderedDict, AutoModelDiagnostic, GenerativeDiagnostic, AutoModelMixin, CoordSystem, DiagnosticModel, Module, Package (+5 more)

### Community 97 - "Community 97"
Cohesion: 0.06
Nodes (33): higher_is_better, lower_is_better, type, type, type, enum, type, type (+25 more)

### Community 98 - "Community 98"
Cohesion: 0.14
Nodes (14): GoldenTestBase, _meta(), Assert at least one of the top-N results contains all expected_in strings., TestColorConversion, TestCrop, TestDewarp, TestFlipRotate, TestMultiStream (+6 more)

### Community 99 - "Community 99"
Cohesion: 0.06
Nodes (33): properties, affine_match, affine_max_abs_diff, anatomy, image_affine, image_bytes, image_error, image_hu_bone_present (+25 more)

### Community 100 - "Community 100"
Cohesion: 0.06
Nodes (33): minimum, type, maximum, minimum, type, type, type, type (+25 more)

### Community 101 - "Community 101"
Cohesion: 0.07
Nodes (33): Agentic AI Taxonomy Lane, CUDA, Conversational AI Taxonomy Lane, Data Science Taxonomy Lane, Decision Optimization Taxonomy Lane, DeepStream, GPU Development Taxonomy Lane, Inference AI Taxonomy Lane (+25 more)

### Community 102 - "Community 102"
Cohesion: 0.20
Nodes (28): already_usd_report(), ambiguous_directory_report(), append_selection_warnings(), ConversionReport, convert_to_usd(), directory_inspection_report(), emit_report(), is_existing_usd() (+20 more)

### Community 103 - "Community 103"
Cohesion: 0.08
Nodes (33): evaluate, train, core_module, gpu_ids, num_gpus, num_nodes, path, popular (+25 more)

### Community 104 - "Community 104"
Cohesion: 0.08
Nodes (33): inference, quantize, gpu_ids, num_gpus, num_nodes, popular, popular, batch_size (+25 more)

### Community 105 - "Community 105"
Cohesion: 0.08
Nodes (33): evaluate, gen_trt_engine, core_module, gpu_ids, num_gpus, num_nodes, path, popular (+25 more)

### Community 106 - "Community 106"
Cohesion: 0.08
Nodes (33): export, quantize, gpu_ids, num_gpus, num_nodes, popular, core_module, path (+25 more)

### Community 107 - "Community 107"
Cohesion: 0.07
Nodes (32): AGENTS.md — Graphify Discovery Rules, Graphify Knowledge Graph, graphify-out/graph.json, graphify Skill, .venv-graphify Virtual Environment, scripts/setup-graphify.sh, README.md — Sage Profile Installation Guide, graphify-baseline.tar.gz (+24 more)

### Community 108 - "Community 108"
Cohesion: 0.09
Nodes (32): Analytics2DApp, Analytics3DApp, AppConfig, Calibration Base, Calibration Listener, Config Listener, Docker Containers Reference, Docker Compose (+24 more)

### Community 109 - "Community 109"
Cohesion: 0.07
Nodes (32): App Shell Hierarchy (Header/Body/Footer), BGRA/RGBA Color Conversion, Camera Aspect Ratio, Camera Button Convention, Cross-Origin Isolation (COOP/COEP), Detail Surface Types (Panel/Drawer/Inspector/Dialog), DRAG_THRESHOLD_PX Constant, Headless Vulkan Mode (+24 more)

### Community 110 - "Community 110"
Cohesion: 0.09
Nodes (32): AutoML Hyperparameter Optimization, ConvNeXtV2 Base Backbone, Grounded Instance Segmentation, MAE Model, MAL Model, Mask Grounding DINO Model, Mask Prediction Head, Open-Vocabulary Segmentation (+24 more)

### Community 111 - "Community 111"
Cohesion: 0.07
Nodes (32): Boundedness Classification, Capacity Report, Compute Bound, Decode Bound, Boundedness Rules, Config Derivation Rules, Hardware Ceiling Formulas, Nsys CLI Recipes (+24 more)

### Community 112 - "Community 112"
Cohesion: 0.07
Nodes (32): CAD to SimReady Workflow, Content Agents Services, deploy-content-agents, MuJoCo to USD Converter, OpenUSD, OpenUSD Python APIs, Preflight Reference, Property Assignment (+24 more)

### Community 113 - "Community 113"
Cohesion: 0.23
Nodes (32): dataset.color_augmentation, dataset.gaussian_blur, dataset.gaussian_blur.kernel, dataset.gaussian_blur.sigma, train.optim.embedder, train.optim.trunk, automl_disabled_parameters, automl_disabled_parameters (+24 more)

### Community 114 - "Community 114"
Cohesion: 0.06
Nodes (32): stage_optimization, description, type, description, type, description, type, description (+24 more)

### Community 115 - "Community 115"
Cohesion: 0.15
Nodes (29): auth_headers(), benchmark_catalog(), build_parser(), collect_prefixed_tags(), dataset_search_blob(), dataset_search_fields(), expand_aliases(), first_text() (+21 more)

### Community 116 - "Community 116"
Cohesion: 0.07
Nodes (31): actions, evaluate, export, inference, train, automl_enabled, automl_default_parameters, core_module (+23 more)

### Community 117 - "Community 117"
Cohesion: 0.10
Nodes (31): evaluate Action, export Action, gen_trt_engine Action, inference Action, train Action, bp2 Checkpoint, Cost Volume, StereoDataset Class (+23 more)

### Community 118 - "Community 118"
Cohesion: 0.09
Nodes (31): Callback Registration, Electron SHM Viewer, Frame Data, Frame Loop, Health Server, ovrtx, OVRTX SKIP USD CHECK, ovstream (+23 more)

### Community 119 - "Community 119"
Cohesion: 0.08
Nodes (31): Capacitated VRP with Time Windows, C API Constants Reference, cuopt_cli Command, cuOptCreateRangedProblem, Problem Class (Python), cuOpt REST Server, DataModel Class (Routing), cuOptSetFloatParameter (+23 more)

### Community 120 - "Community 120"
Cohesion: 0.09
Nodes (29): FastAPI, Request, _build_backend(), _enrich_incident_with_video(), _fan_out(), health(), lifespan(), _parse_backend_names() (+21 more)

### Community 121 - "Community 121"
Cohesion: 0.06
Nodes (30): analysis, canonical, deprecated, documentary, specialty, wired_into, properties, required (+22 more)

### Community 122 - "Community 122"
Cohesion: 0.28
Nodes (31): dataset._eig_val, dataset._eig_vec, dataset.flip_idx, dataset.mean, dataset.std, train.loss_config, automl_disabled_parameters, automl_disabled_parameters (+23 more)

### Community 123 - "Community 123"
Cohesion: 0.18
Nodes (31): dataset.transform, dataset.transform.global_crops_scale, dataset.transform.local_crops_scale, model.distill, train.schedulers, train.schedulers.last_layer_learning_rate, train.schedulers.learning_rate, train.schedulers.momentum (+23 more)

### Community 124 - "Community 124"
Cohesion: 0.12
Nodes (30): analyze_annotations(), api_request(), check_image_classification_compatibility(), check_object_detection_compatibility(), check_sam_segmentation_compatibility(), detect_bbox_format(), _extract_image_size(), find_columns() (+22 more)

### Community 125 - "Community 125"
Cohesion: 0.21
Nodes (30): _build_command(), build_parser(), _emit(), _empty_output(), _git_commit(), _load_json(), _loss_weighted_sum(), main() (+22 more)

### Community 126 - "Community 126"
Cohesion: 0.18
Nodes (30): _build_command(), _candidate_upstream_roots(), _coerce_label_id(), emit(), _empty_geometry(), _empty_output_summary(), _error_payload(), _expected_output_candidates() (+22 more)

### Community 127 - "Community 127"
Cohesion: 0.08
Nodes (31): DINO Skill Card, FastFoundationStereo Benchmark, FastFoundationStereo Skill, AdamW Optimizer, DINO AutoML HPO, FAN Backbone Family, ResNet-50 Backbone, COCO Dataset Format (+23 more)

### Community 128 - "Community 128"
Cohesion: 0.08
Nodes (31): export, gpu_ids, num_gpus, num_nodes, popular, core_module, path, popular (+23 more)

### Community 129 - "Community 129"
Cohesion: 0.07
Nodes (30): Bearer Token Authentication, FRAMES_PER_SIDE Parameter, Hugging Face Cache Volume, Apache Kafka Message Broker, NGC Model Cache Volume, NVSkills-Eval Evaluation Framework, nvdspreprocess Configuration, NVIDIA VSS Documentation (+22 more)

### Community 130 - "Community 130"
Cohesion: 0.09
Nodes (30): cuPyNumeric API Support, cuPyNumeric, Migration Decision Framework, Dense Linear Algebra, Legate Execution Model, GPUDirect Storage, HDF5 File Format, Lazy Execution Model (+22 more)

### Community 131 - "Community 131"
Cohesion: 0.11
Nodes (19): DataArray, datetime64, datetime, ndarray, A single async fetch unit.      Each task represents one (time, variable) pair t, Short description of the data source.      Extended description: what data this, Initialize the async filesystem connection., Retrieve data for given times and variables.          Parameters         ------- (+11 more)

### Community 132 - "Community 132"
Cohesion: 0.19
Nodes (30): dataset.augmentation.color_jitter, dataset.augmentation.scale, dataset.train.datasets, dataset.train.wds, dataset.val.datasets, evaluate.datasets, inference.datasets, automl_disabled_parameters (+22 more)

### Community 133 - "Community 133"
Cohesion: 0.08
Nodes (30): ddpm-ct, rflow-ct, type, type, type, type, items, type (+22 more)

### Community 134 - "Community 134"
Cohesion: 0.09
Nodes (30): train, batch_size, num_classes, num_instances, num_workers, val_batch_size, gpu_ids, num_gpus (+22 more)

### Community 135 - "Community 135"
Cohesion: 0.07
Nodes (29): Analysis-Only Operation, Batch Mode Orchestration, Bounded-Loss Operation, Bounding Box Clip Operation, Compute Extents Operation, Count Vertices Operation, Lossless Operation, USD Performance Tuning OpenAI Agent Config (+21 more)

### Community 136 - "Community 136"
Cohesion: 0.08
Nodes (29): DBHead, DDP Distributed Strategy, Deformable ResNet18, Differentiable Binarization, Front3D Dataset, 3D Frustum Reconstruction, hmean Metric, Mask2Former (+21 more)

### Community 137 - "Community 137"
Cohesion: 0.10
Nodes (15): compact JSON output should be substantially smaller than full json., argparse should reject an unknown --format value., validate_pipeline.py --format {json,summary}, Default (no --format) must remain full JSON for backward compat., Multi-stream pipelines should mention 'live-parse skipped' in summary., The Step 5 generated script uses 'gst-launch-1.0 -e' — validator must accept., generate_pipeline.py --format {json,compact,summary}, Default (no --format) must remain full JSON for backward compat. (+7 more)

### Community 138 - "Community 138"
Cohesion: 0.12
Nodes (26): assert_diagnostic_coord_order(), assert_generative_coord_order(), load_mock_model(), make_coords(), make_input(), PhooModelName, Package, Tensor (+18 more)

### Community 139 - "Community 139"
Cohesion: 0.09
Nodes (26): AutoML Enabled, Checkpoint Handoff Convention, Classification PyT Deploy Workflow, TensorRT Engine Generation, MAE Distributed Strategies, MAE Pretrain and Finetune Stages, MAE Stage Mismatch Error, ONNX (+18 more)

### Community 140 - "Community 140"
Cohesion: 0.09
Nodes (28): BERT text encoder, BERT Text Encoder, COCO Panoptic annotation format, DINO Object Detection, DINO-style object detection, Grounding DINO model, Grounding DINO architecture, Language-guided object detection (+20 more)

### Community 141 - "Community 141"
Cohesion: 0.11
Nodes (28): 1-based Indexing (Julia), Broadcast Dot Syntax (Julia), Column-Major Memory Layout (Julia), cuTile.jl (Julia), cuTile GPU Kernel, Kernel Conversion Workflow, TileGym Library, TMA (Tensor Memory Access) (+20 more)

### Community 142 - "Community 142"
Cohesion: 0.10
Nodes (28): Arithmetic Intensity, Autotune for cuTile Kernels, Batch Small Copy Kernels, Compute Throughput Bottleneck, cuTile Kernel Coverage Metric, FlashInfer Kernel Inventory Schema, Flush to Zero Optimization, GROUP_SIZE_M 2D Swizzling (+20 more)

### Community 143 - "Community 143"
Cohesion: 0.08
Nodes (28): Cross-Phase Data Flow, Debugging Playbook, Environment Isolation Strategy, HuggingFace Model Validation, local-docker Execution Platform, tao-pytorch vs tao-deploy Module Pitfalls, ONNX Exportability Check, Phase 0: Prerequisites Check (+20 more)

### Community 144 - "Community 144"
Cohesion: 0.20
Nodes (27): _aggregate(), _build_command(), _candidate_upstream_roots(), _detect_cuda(), emit(), _estimate_cost(), file_sha256_safe(), git_commit() (+19 more)

### Community 145 - "Community 145"
Cohesion: 0.20
Nodes (27): _aggregate(), _build_command(), _candidate_upstream_roots(), _detect_cuda(), emit(), _estimate_cost(), file_sha256_safe(), git_commit() (+19 more)

### Community 146 - "Community 146"
Cohesion: 0.09
Nodes (28): type, type, type, type, type, type, array, null (+20 more)

### Community 147 - "Community 147"
Cohesion: 0.09
Nodes (27): Adaptive Concurrency, Destructive Operations, ExecutionContext, Full Mode Profiling, Optimization Report, Optimization Report Template, Output Workspace Contract, Profile Stage (+19 more)

### Community 148 - "Community 148"
Cohesion: 0.10
Nodes (27): Asset Validator, Kit, Material Agent, Runtime Artifact Token Budget, Setup USD Performance Tuning, Install Asset Validator Standalone, Install Kit, Install Scene Optimizer Standalone (+19 more)

### Community 149 - "Community 149"
Cohesion: 0.14
Nodes (27): Auto-Triage Diagnostic, Docker Compose, Embedding NIM, Health Check Endpoint, Ingestor Server, Library Mode, LLM NIM, Model Cache (+19 more)

### Community 150 - "Community 150"
Cohesion: 0.07
Nodes (27): instance_count, material_count, payload_count, prim_count, prototype_count, reference_count, type, mesh_count (+19 more)

### Community 151 - "Community 151"
Cohesion: 0.13
Nodes (16): main(), PaperManager, Any, Link a paper to a model/dataset/space repository.          Args:             rep, Add paper reference to README content.          Args:             content: Curre, Create a research article from template.          Args:             template: Te, Fetch paper information from arXiv API.          Args:             arxiv_id: arX, Generate citation for a paper.          Args:             arxiv_id: arXiv identi (+8 more)

### Community 152 - "Community 152"
Cohesion: 0.09
Nodes (27): type, type, minimum, type, type, type, type, integer (+19 more)

### Community 153 - "Community 153"
Cohesion: 0.07
Nodes (27): type, type, type, type, minimum, type, properties, type (+19 more)

### Community 154 - "Community 154"
Cohesion: 0.08
Nodes (27): items, type, items, items, type, type, items, type (+19 more)

### Community 155 - "Community 155"
Cohesion: 0.07
Nodes (27): properties, required, image_path, image_readable, all_finite, finite_fraction, image_affine, image_bytes (+19 more)

### Community 156 - "Community 156"
Cohesion: 0.07
Nodes (27): properties, required, image_path, image_readable, all_finite, finite_fraction, image_affine, image_bytes (+19 more)

### Community 157 - "Community 157"
Cohesion: 0.08
Nodes (27): items, minItems, type, minimum, type, type, type, minimum (+19 more)

### Community 158 - "Community 158"
Cohesion: 0.22
Nodes (26): _anchored_relative(), assemble(), _authored_asset_paths(), _copy_with_collision(), _errors_from_checks(), _file_same(), _is_uri(), _iter_prim_specs() (+18 more)

### Community 159 - "Community 159"
Cohesion: 0.21
Nodes (26): _cad_core_for_source(), check_dependencies(), _compact(), convert_with_kit_app_template(), _core_command(), _core_exec_payload(), discover_generated_files(), _host_platform() (+18 more)

### Community 160 - "Community 160"
Cohesion: 0.07
Nodes (27): additionalProperties, type, additionalProperties, type, additionalProperties, type, additionalProperties, type (+19 more)

### Community 161 - "Community 161"
Cohesion: 0.09
Nodes (27): API server VIP connectivity, ECR registry, FLAC audio format, k3s control plane, k3s containerd image import, kubectl on Waggle nodes, meta.task data API field, Node SSH access, ssh-agent recovery, and SES job ownership (+19 more)

### Community 162 - "Community 162"
Cohesion: 0.07
Nodes (26): actions, export, inference, quantize, train, automl_enabled, core_module, path (+18 more)

### Community 163 - "Community 163"
Cohesion: 0.10
Nodes (27): evaluate, core_module, gpu_ids, num_gpus, num_nodes, path, popular, schema_action (+19 more)

### Community 164 - "Community 164"
Cohesion: 0.09
Nodes (26): actions, export, inference, train, automl_enabled, automl_default_parameters, core_module, path (+18 more)

### Community 165 - "Community 165"
Cohesion: 0.11
Nodes (27): gpu_ids, num_gpus, num_nodes, popular, popular, batch_size, gpu_id, tensorrt (+19 more)

### Community 166 - "Community 166"
Cohesion: 0.12
Nodes (20): IBatchArray, IBatchBuffer, IInferCustomProcessor, InferBufferDescription, InferDataType, InferMemType, IOptions, map (+12 more)

### Community 167 - "Community 167"
Cohesion: 0.08
Nodes (26): binary, clean_v2, graded_s0_s4, mostly_custom, v2_plus_custom, type, type, format (+18 more)

### Community 168 - "Community 168"
Cohesion: 0.14
Nodes (25): _apply_marker_defaults(), _load_catalog(), main(), Path, Load a canned-entries catalog from references/catalog/<name>.json.      Missing, Ensure optional verify-marker fields exist so StrictUndefined doesn't bite., render(), _type_name() (+17 more)

### Community 169 - "Community 169"
Cohesion: 0.10
Nodes (25): VSS Alerts Profile, VSS Base Profile, COMPOSE_PROFILES, Docker Compose Deploy, Environment Override Configuration Pattern, generated.env, VSS LVS (Long Video Summarization) Profile, Docker Compose Resolved YAML (+17 more)

### Community 170 - "Community 170"
Cohesion: 0.12
Nodes (25): Structural Defect Generation OSMO Workflow, Texture Defect Generation Day 0 OSMO Workflow, Texture Defect Generation Day 1 Manual ROI OSMO Workflow, Texture Defect Generation Day 1 Real Photo Alignment OSMO Workflow, AnomalyGen Training Config for Glass Use Case, AnomalyGen Training Config for Metal Surface Use Case, Day 0 Crop Config for 0603_H100 PCB Board, Day 0 Image Render Config for 0603_H100 PCB Board (+17 more)

### Community 171 - "Community 171"
Cohesion: 0.22
Nodes (20): AST, cad_to_usd(), ConversionReport, default_upstream_root(), discover_generated_files(), emit_probe(), emit_report(), main() (+12 more)

### Community 172 - "Community 172"
Cohesion: 0.13
Nodes (24): AutoImageProcessor, BatchFeature, EvalPrediction, augment_and_transform_batch(), collate_fn(), compute_metrics(), convert_bbox_yolo_to_pascal(), DataTrainingArguments (+16 more)

### Community 173 - "Community 173"
Cohesion: 0.09
Nodes (25): BPMP DTB (Boot Processor Management Unit Device Tree Blob), BPMP-DTB customization protocol, cpufreq governor, devfreq governor, nvfancontrol FAN_PROFILE, BPMP DTB clock-node edits reference, Clock control model reference, jetson-customize-nvpmodel skill (+17 more)

### Community 174 - "Community 174"
Cohesion: 0.10
Nodes (25): ChangeNet Model, Counterfactual Analysis, Cross-Dimensional Analysis, Deep Image Investigation, Golden Image, Investigation Phases, Pillar-Based Point Cloud Encoding, Root Cause Analysis (+17 more)

### Community 175 - "Community 175"
Cohesion: 0.08
Nodes (25): cuda_available, gpu_count, gpu_free_mb, gpu_total_mb, host_ram_mb, type, properties, required (+17 more)

### Community 176 - "Community 176"
Cohesion: 0.12
Nodes (12): load_ddm_net_model(), Module, DDMTensorRTEngine, Tensor, Run one TRT call on exactly trt_batch_size windows.          Returns:, Run TRT inference over an arbitrary number of windows, chunking into         trt, This function allows         the model to initialize any state associated with t, Step 1: load a cached engine from DDM_TRT_ENGINE_OUTPUT_PATH if it         exist (+4 more)

### Community 177 - "Community 177"
Cohesion: 0.08
Nodes (25): type, type, type, type, type, type, properties, consistency (+17 more)

### Community 178 - "Community 178"
Cohesion: 0.15
Nodes (24): Check, check_env(), check_nixl(), check_node(), classify_node_probe(), exec_prefix(), find_env_value(), main() (+16 more)

### Community 179 - "Community 179"
Cohesion: 0.12
Nodes (24): _apply_pinmux_edits(), Apply all session pin_edits to a pinmux DTSI text in memory., _append_one_gpio(), gpio_macro_for(), _insert_marker(), _patch_function(), patch_gpio_block(), _patch_optional() (+16 more)

### Community 180 - "Community 180"
Cohesion: 0.12
Nodes (24): _augment_with_gpio(), cmd_lookup(), _print_lookup_suggestions(), Path, Print closest-match suggestions when lookup found nothing., Decorate edits with `_gpio` (bank/idx/kind) when sfio == 'gpio'., Resolve a CVM ball / signal / pin query against the pinmap KB., load_pinmap() (+16 more)

### Community 181 - "Community 181"
Cohesion: 0.11
Nodes (23): _check_sudo_pw(), check_tty_lock(), _dispatch(), _ensure_pyserial(), LoginError, main(), parse_args(), Exception (+15 more)

### Community 182 - "Community 182"
Cohesion: 0.28
Nodes (25): automl_disabled_parameters, automl_disabled_parameters, automl_disabled_parameters, dataset, dataset.augmentation, dataset.augmentation.mean, dataset.augmentation.std, evaluate (+17 more)

### Community 183 - "Community 183"
Cohesion: 0.11
Nodes (24): Attribute Binding, Camera Controls, FBO Y-Flip for Compositing, GL Overlay Renderer, GL Viewport Overlay, HuggingFace USD, Incremental Drag Math, Local Viewer (+16 more)

### Community 184 - "Community 184"
Cohesion: 0.14
Nodes (24): Azure AI Foundry, Azure File CSI Driver, azurefile-nfs-premium StorageClass, nvidia RuntimeClass, Infrastructure Driver Reference, Azure AI Foundry Inference Reference, Cosmos Predict NIMService, Cosmos Reason NIMService (+16 more)

### Community 185 - "Community 185"
Cohesion: 0.12
Nodes (24): AutoModel, BYOB MCQ Benchmark, Checkpoint Conversion, Curation Pipeline, Data Designer, Evaluation, NeMo Curator, Nemotron Step (+16 more)

### Community 186 - "Community 186"
Cohesion: 0.12
Nodes (24): Creative Mode (Custom HTML/JS), Creative mode (custom HTML/JS), Diffusers library, Gradio, Gradio, Krea2Pipeline, LTX2InContextPipeline, LTX2Pipeline (+16 more)

### Community 187 - "Community 187"
Cohesion: 0.11
Nodes (24): Kernel-DT Overlay, ODMDATA Token, PCIe Controller, pin_verifier.py, UPHY Lane Allocation, USB Three-place Lockstep, jetson-customize-nvpmodel SKILL, jetson-customize-pcie BENCHMARK (+16 more)

### Community 188 - "Community 188"
Cohesion: 0.09
Nodes (24): Dataset Format by Task, Error Recovery Minimal Change, FSDP Parallelism, Hardware Sizing bf16, HuggingFace Trainer, NGC PyTorch Container, Research Priority Ladder, Six-Step Fine-tuning Workflow (+16 more)

### Community 189 - "Community 189"
Cohesion: 0.08
Nodes (23): environment, plan, type, input, intended_use_disclaimer, invocation, model, model_repo (+15 more)

### Community 190 - "Community 190"
Cohesion: 0.09
Nodes (24): X, Y, Z, properties, type, type, description, type (+16 more)

### Community 191 - "Community 191"
Cohesion: 0.12
Nodes (23): automodel_call_template(), generative_call_template(), generative_output_coords_template(), input_coords_template(), load_default_package_template(), load_model_template(), output_coords_template(), CoordSystem (+15 more)

### Community 192 - "Community 192"
Cohesion: 0.12
Nodes (23): call_template(), create_iterator_template(), default_generator_template(), input_coords_template(), input_coords_with_history_template(), load_default_package_template(), load_model_template(), output_coords_template() (+15 more)

### Community 193 - "Community 193"
Cohesion: 0.15
Nodes (23): api_request(), check_dpo_compatibility(), check_grpo_compatibility(), check_kto_compatibility(), check_sft_compatibility(), find_columns(), format_value_preview(), generate_mapping_code() (+15 more)

### Community 194 - "Community 194"
Cohesion: 0.30
Nodes (23): _append_unique(), conform(), _core_output_path(), emit(), _empty_report(), _failed_requirements(), _finalize(), _load_json() (+15 more)

### Community 195 - "Community 195"
Cohesion: 0.11
Nodes (23): AdamW Optimizer, C-RADIOv2-B Pretrained Model, C-RADIOv2 Backbone, C-RADIO v2 ViT Base Patch16 224 Backbone, Checkpoint Resolution Pattern, CNDataset, Contrastive Loss, Cross Entropy Loss (+15 more)

### Community 196 - "Community 196"
Cohesion: 0.11
Nodes (23): apply_binaries.sh Binary Application Script, boardctl Recovery Automation Tool, Device Tree Overlay, EEPROM Module Identification, Per-Board Flash Configuration, flash.sh Flashing Tool, Jetson Orin Platform, Jetson Thor Platform (+15 more)

### Community 197 - "Community 197"
Cohesion: 0.09
Nodes (23): AttributeFilterMode, Custom Overlay, Dynamic Root Prim, FilterKind, Hot Swap Sequence, Lazy Hierarchy Expansion, Native Picking, Native Selection Outlines (+15 more)

### Community 198 - "Community 198"
Cohesion: 0.12
Nodes (23): 3D Object Detection, AutoML Enabled, LiDAR Point Clouds, Pillar-based Encoding, PointPillars Skill, Prune Retrain Workflow, TAO Deploy PointPillars, TorchRun Distributed Training (+15 more)

### Community 199 - "Community 199"
Cohesion: 0.11
Nodes (23): AutoML / HPO, CTC and Attention-based Decoders, Deformable DETR Object Detection, Differentiable Binarization for Text Detection, LMDB Dataset Format for OCRNet, OCDNet - Optical Character Detection Network, OCRNet - Optical Character Recognition Network, Scene Text Recognition Pipeline (+15 more)

### Community 200 - "Community 200"
Cohesion: 0.13
Nodes (16): HTMLParser, ApiEntry, _Cell, _classify_row(), _ComparisonParser, fetch_html(), main(), _notes_for() (+8 more)

### Community 201 - "Community 201"
Cohesion: 0.19
Nodes (23): config_maisi_diff_model_rflow-mr-brain.json, config_maisi_diff_model_rflow-mr.json, modality_mapping.json, MR Synthesis Quality Verifier v1, NV_GENERATE_ROOT environment variable, NVIDIA-Medtech/NV-Generate-CTMR, nvidia/NV-Generate-MR HuggingFace model, nvidia/NV-Generate-MR-Brain HuggingFace model (+15 more)

### Community 202 - "Community 202"
Cohesion: 0.09
Nodes (22): artifacts, measurement_context, metric_groups, metrics, optimization_score, output_path, score_label, score_scope (+14 more)

### Community 203 - "Community 203"
Cohesion: 0.40
Nodes (23): train.optim.layer_decay_rate, automl_default_parameters, automl_default_parameters, automl_default_parameters, automl_default_parameters, dataset.augmentation.horizontal_flip_prob, dataset.augmentation.train_random_crop_max, dataset.augmentation.train_random_crop_min (+15 more)

### Community 204 - "Community 204"
Cohesion: 0.13
Nodes (22): _add_apply_parser(), _add_commit_parser(), _add_generate_parser(), _add_lookup_parser(), _add_probe_parser(), _add_set_pin_parser(), build_parser(), cmd_apply() (+14 more)

### Community 205 - "Community 205"
Cohesion: 0.11
Nodes (10): ndarray, Path, _save_pair(), test_aggregate_checks_saved_output_label_ordinals_not_raw_maisi_ids(), test_aggregate_flags_empty_foreground_and_constant_image(), test_aggregate_pass(), test_aggregate_reports_missing_expected_output_label(), test_curated_lung_tumor_fixture_uses_robust_size() (+2 more)

### Community 206 - "Community 206"
Cohesion: 0.09
Nodes (23): type, properties, items, type, items, maxItems, minItems, type (+15 more)

### Community 207 - "Community 207"
Cohesion: 0.09
Nodes (23): type, properties, items, type, items, maxItems, minItems, type (+15 more)

### Community 208 - "Community 208"
Cohesion: 0.09
Nodes (23): required, type, application, assetValidator, extension, kit, package, path (+15 more)

### Community 209 - "Community 209"
Cohesion: 0.25
Nodes (22): add_invoker_to_docker_group(), configure_docker_runtime(), confirm_install(), container_toolkit_ok(), cuda_ok(), detect_distro(), docker_installed_ok(), docker_runtime_ok() (+14 more)

### Community 210 - "Community 210"
Cohesion: 0.10
Nodes (23): train, gpu_ids, num_gpus, num_nodes, popular, gpu_ids, num_gpus, num_nodes (+15 more)

### Community 211 - "Community 211"
Cohesion: 0.14
Nodes (22): aiperf Load Testing, Docker Deployment, Helm Deployment, Library Mode, NVIDIA RAG Blueprint, rag-perf CLI, Self-Hosted NIM, RAG Blueprint Evaluation Report (+14 more)

### Community 212 - "Community 212"
Cohesion: 0.10
Nodes (22): CODEOWNERS, CUDA_DEVICE_MAX_CONNECTIONS, DockerExecutor, Functional Tests, Golden Values, NVIDIA Megatron-LM, nemo-run, Pull Request (+14 more)

### Community 213 - "Community 213"
Cohesion: 0.13
Nodes (22): Cosmos Embed1 Embeddings, Cosmos-Embed1-448p Embedding Model, Elasticsearch for Video Embeddings Index, Embedding Model (llama-nemotron-embed-1b-v2), Fusion Search, LLM Model, Milvus Vector Database, Models and Infrastructure Configuration (+14 more)

### Community 214 - "Community 214"
Cohesion: 0.10
Nodes (22): DaemonSet, Data API, k3s, Node Service, NRP Storage, pywaggle2, Sage Continuum Data Query, Slack Notification Pattern (+14 more)

### Community 215 - "Community 215"
Cohesion: 0.09
Nodes (22): Evaluator Plugin, NVSkills-Eval, holoscan-install-container Benchmark, holoscan-install-debian Benchmark, holoscan-install-source Benchmark, holoscan-install-wheel Benchmark, holoscan-setup Benchmark, hsb-app Benchmark (+14 more)

### Community 216 - "Community 216"
Cohesion: 0.15
Nodes (14): PrognosticMixin, ModelName, AutoModelMixin, CoordSystem, Module, Tensor, Input coordinate system of the prognostic model.          Returns         ------, Output coordinate system of the prognostic model.          Parameters         -- (+6 more)

### Community 217 - "Community 217"
Cohesion: 0.09
Nodes (22): authored_list_op_items, mixed_or_unknown, prims_with_authored_arcs, properties, description, enum, type, type (+14 more)

### Community 218 - "Community 218"
Cohesion: 0.09
Nodes (21): available_profiles, feature_results, profile_name, profile_results, profile_target, requirement_counts, asset_path, command (+13 more)

### Community 219 - "Community 219"
Cohesion: 0.09
Nodes (22): custom.train_dataset, custom.val_dataset, custom.vision, logging, logging.logger, policy, policy.lora, policy.lora.alpha_pattern (+14 more)

### Community 220 - "Community 220"
Cohesion: 0.09
Nodes (22): dataset_dir, label_mappings, smoke, type, additionalProperties, type, type, properties (+14 more)

### Community 221 - "Community 221"
Cohesion: 0.09
Nodes (22): file, fixture_file, generated_fixture, jpeg, png, enum, minimum, type (+14 more)

### Community 222 - "Community 222"
Cohesion: 0.09
Nodes (22): seconds, step, total_seconds, properties, required, type, properties, required (+14 more)

### Community 223 - "Community 223"
Cohesion: 0.10
Nodes (22): create_manual_task API, Supported Data Formats, DLPack Interoperability, Legate @task, Manual Partition Pattern, Manual Task Launch Pattern, PhysicalStore, cuPyNumeric Parallel Data Load Skill (+14 more)

### Community 224 - "Community 224"
Cohesion: 0.09
Nodes (22): type, type, properties, required, type, command, exit_code, upstream_root (+14 more)

### Community 225 - "Community 225"
Cohesion: 0.16
Nodes (21): _accumulate(), align(), _build_parser(), collect_assistant_usage(), cwd_to_project_slug(), discover_project_dir(), _empty_tokens(), main() (+13 more)

### Community 226 - "Community 226"
Cohesion: 0.09
Nodes (21): actions, evaluate, export, train, automl_enabled, core_module, path, schema_action (+13 more)

### Community 227 - "Community 227"
Cohesion: 0.09
Nodes (21): actions, evaluate, inference, train, automl_enabled, core_module, path, schema_action (+13 more)

### Community 228 - "Community 228"
Cohesion: 0.09
Nodes (21): actions, evaluate, inference, train, automl_enabled, core_module, path, schema_action (+13 more)

### Community 229 - "Community 229"
Cohesion: 0.09
Nodes (21): actions, export, inference, train, automl_enabled, core_module, path, schema_action (+13 more)

### Community 230 - "Community 230"
Cohesion: 0.12
Nodes (22): batch_size, pin_memory, workers, disable_masking, enable, popular, batch_size, gpu_id (+14 more)

### Community 231 - "Community 231"
Cohesion: 0.09
Nodes (21): actions, export, quantize, train, automl_enabled, core_module, path, schema_action (+13 more)

### Community 232 - "Community 232"
Cohesion: 0.09
Nodes (21): actions, export, inference, train, automl_enabled, core_module, path, schema_action (+13 more)

### Community 233 - "Community 233"
Cohesion: 0.09
Nodes (21): actions, evaluate, inference, train, automl_enabled, core_module, path, schema_action (+13 more)

### Community 234 - "Community 234"
Cohesion: 0.12
Nodes (20): next_power_of_2(), Constant, Tensor, Test function to verify correctness., Return the smallest power of 2 >= n., cuTile kernel for row-wise softmax.      Each block processes multiple rows usin, Host wrapper for cuTile softmax.      Applies softmax along the last dimension (, softmax() (+12 more)

### Community 235 - "Community 235"
Cohesion: 0.13
Nodes (21): Composite custom overlay .dts, Dual-fragment trap (camera kernel-DT gotcha), CSI DT bindings reference, jetson-customize-camera procedure, jetson-customize-mgbe procedure, jetson-customize-pinmux skill, jetson-customize-uphy skill, jetson-derive-carrier skill (+13 more)

### Community 236 - "Community 236"
Cohesion: 0.12
Nodes (21): AnomalyGen Cosmos SDG, AOI (Automated Optical Inspection), C-RADIOv2-B Backbone, False Accept Rate, FAR @ 100% Recall, k-NN Mining, Root Cause Analysis, Synthetic Data Generation (+13 more)

### Community 237 - "Community 237"
Cohesion: 0.11
Nodes (21): Ahead-of-time compilation (AoTI), Blackwell GPU (sm_120), HF Buckets, Community GPU grants, Flash Attention 2, HuggingFace Spaces, Inference Providers, Quantization (bitsandbytes, torchao) (+13 more)

### Community 238 - "Community 238"
Cohesion: 0.20
Nodes (21): NVIDIA B200 GPU, Context Parallelism, Dropless MoE, DeepSeek-V3 Model, Force Balance Routing, NVIDIA GB200, NVIDIA GB300, NVIDIA H100 GPU (+13 more)

### Community 239 - "Community 239"
Cohesion: 0.22
Nodes (20): OutputStore, build_parser(), build_reference(), cleanup_phase(), demo_phase(), discover_layout(), load_seed_if_present(), load_tile() (+12 more)

### Community 240 - "Community 240"
Cohesion: 0.38
Nodes (21): dataset.augmentation_config.augment, dataset.augmentation_config.random_color.brightness, dataset.augmentation_config.random_color.color_probability, dataset.augmentation_config.random_color.contrast, dataset.augmentation_config.random_color.enable, dataset.augmentation_config.random_color.hue, dataset.augmentation_config.random_color.saturation, dataset.augmentation_config.random_flip.enable (+13 more)

### Community 241 - "Community 241"
Cohesion: 0.43
Nodes (21): dataset.augmentation.distortion_prob, dataset.augmentation.iou_crop_prob, train.ema.decay, automl_default_parameters, automl_default_parameters, automl_default_parameters, automl_default_parameters, dataset.batch_size (+13 more)

### Community 242 - "Community 242"
Cohesion: 0.10
Nodes (20): failed_requirements, profile_version, requirements_skipped, errors, input_usd_path, next_step, output_dir, output_usd_path (+12 more)

### Community 243 - "Community 243"
Cohesion: 0.32
Nodes (21): model.stride_size, re_ranking, automl_disabled_parameters, automl_disabled_parameters, automl_disabled_parameters, dataset, dataset.pixel_mean, dataset.pixel_std (+13 more)

### Community 244 - "Community 244"
Cohesion: 0.11
Nodes (12): generate_clean_sequence(), MissingNumberDetector, Complete the current cycle and detect any missing numbers and collect mis-ordere, Get comprehensive statistics about the detection process, Get status of the current incomplete cycle, Complete any remaining cycles, Detects missing numbers and mis-ordered numbers in a sequence that should follow, Print a summary of the sequence processing (+4 more)

### Community 245 - "Community 245"
Cohesion: 0.11
Nodes (21): type, type, items, type, items, type, type, properties (+13 more)

### Community 246 - "Community 246"
Cohesion: 0.12
Nodes (21): type, type, type, type, boolean, null, number, string (+13 more)

### Community 247 - "Community 247"
Cohesion: 0.38
Nodes (21): automl_default_parameters, automl_default_parameters, automl_default_parameters, dataset.augmentation.horizontal_flip_prob, dataset.augmentation.train_random_crop_max, dataset.augmentation.train_random_crop_min, dataset.batch_size, dataset.workers (+13 more)

### Community 248 - "Community 248"
Cohesion: 0.38
Nodes (21): automl_default_parameters, automl_default_parameters, automl_default_parameters, dataset.segment.augmentation.random_color.brightness, dataset.segment.augmentation.random_color.color_probability, dataset.segment.augmentation.random_color.contrast, dataset.segment.augmentation.random_color.enable, dataset.segment.augmentation.random_color.hue (+13 more)

### Community 249 - "Community 249"
Cohesion: 0.11
Nodes (20): Chain-of-Thought Training Data Generation, DEFT Embed-then-Mine Workflow, Step 1/2: Embed Target/Source Images, Image Embedding, k-NN Mining, Nearest Neighbour Mining, SigLIP/CLIP Encoder, Bundled Scripts and Agents (+12 more)

### Community 250 - "Community 250"
Cohesion: 0.11
Nodes (20): Controllable Mask Generation, CT ControlNet, CT Mask Generation, CT Synthesis Quality Verifier v1, CT Volume Generation, Field of View Constraints, MAISI Label Space, NIfTI Format (+12 more)

### Community 251 - "Community 251"
Cohesion: 0.10
Nodes (20): aicity, aicity.anchor_init_config, aicity.class_config, aicity.class_config.ATTRIBUTE_DICT, aicity.class_config.CLASS_LIST, aicity.class_config.CLASS_RANGE_DICT, aicity.class_config.MAP_CLASS_NAMES, aicity.class_config.SUB_CLASS_DICT (+12 more)

### Community 252 - "Community 252"
Cohesion: 0.10
Nodes (19): custom_layer_key, custom_layer_written, sidecar_json_path, tool, asset_path, checks, errors, metadata (+11 more)

### Community 253 - "Community 253"
Cohesion: 0.15
Nodes (7): BM25Retriever, BM25 retriever with structural metadata boosting. Pure stdlib., Load pipeline dataset from CSV.          The fully-indexed retriever state (docu, Compute IDF with BM25 formula: log((N - df + 0.5) / (df + 0.5) + 1)., Precompute term frequency dicts per document., Regression: the BM25 index is cached to a sibling     JSON file keyed on (CSV mt, TestIndexCache

### Community 254 - "Community 254"
Cohesion: 0.15
Nodes (14): cmd_pull(), cmd_push(), Pattern, Serial-port session manager: login, exec, file transfer over a tty., Consume whatever is sitting in the read buffer.          Drops kernel printk noi, Write `data` to the serial port and flush., Read until `pattern` matches the buffered tail.          If `sudo_password` is s, Establish a session and set a uuid-tagged PS1 sentinel.          Returns the sen (+6 more)

### Community 255 - "Community 255"
Cohesion: 0.14
Nodes (18): classes_by_region(), _edit_distance(), load_label_dict(), Any, Path, Read the upstream's label_dict.json. Drops the `dummy*` placeholder     entries, Return the region grouping for a class name, or None if it has no     canonical, Group `label_dict` entries by region. Classes with no canonical     region land (+10 more)

### Community 256 - "Community 256"
Cohesion: 0.30
Nodes (19): _aggregate(), _build_command(), _candidate_upstream_roots(), _detect_cuda(), _load_json(), _load_request(), main(), _model_inventory() (+11 more)

### Community 257 - "Community 257"
Cohesion: 0.11
Nodes (20): minimum, type, type, additionalProperties, type, additionalProperties, type, type (+12 more)

### Community 258 - "Community 258"
Cohesion: 0.10
Nodes (20): type, type, type, properties, type, type, type, properties (+12 more)

### Community 259 - "Community 259"
Cohesion: 0.10
Nodes (19): type, converter_command, converter_skill, converter_tool, errors, generated_files, next_step, output_directory (+11 more)

### Community 260 - "Community 260"
Cohesion: 0.22
Nodes (15): AssetValidatorIssue, AssetValidatorReport, dependency_blocked_report(), emit_report(), flatten_issues(), issue_location(), issue_requirement(), issue_suggestion() (+7 more)

### Community 261 - "Community 261"
Cohesion: 0.10
Nodes (19): actions, dataset_convert, inference, automl_enabled, automl_default_parameters, automl_disabled_parameters, core_module, path (+11 more)

### Community 262 - "Community 262"
Cohesion: 0.15
Nodes (19): ActionWorkflow, build_entrypoint Function, Kubernetes Indexed Job, Job Status Polling Pattern, Kubernetes Execution, Lustre Storage, Multi-node Distributed Training, NVIDIA GPU Operator (+11 more)

### Community 263 - "Community 263"
Cohesion: 0.18
Nodes (19): Automated Optical Inspection, Cosmos AnomalyGen Model, DIG Finetune Workflow, DIG Good Image Generation, DIG Structural Defect Generation, DIG Day 0 Texture Defect Generation, DIG Day 1 Texture Defect Generation, Glass Use Case (+11 more)

### Community 264 - "Community 264"
Cohesion: 0.15
Nodes (19): CUDA Graph Capture, Expert-Parallel Overlap, Flex Dispatcher, Flex Dispatcher Backend, MoE Expert-Parallel Communication Overlap, cuda_graph_impl Config, cuda_graph_scope Config, delay_wgrad_compute Config (+11 more)

### Community 265 - "Community 265"
Cohesion: 0.15
Nodes (19): Deformable DETR, DINO Object Detector, DINOv2 ViT-L Encoder, MetricDepthAnything, Monocular Depth Estimation, RelativeDepthAnything, Deformable DETR Skill Card, Depth Anything V2 Benchmark Report (+11 more)

### Community 266 - "Community 266"
Cohesion: 0.11
Nodes (6): gh CLI, GitHub Actions, pytest, mcore-create-issue Evaluation Benchmark, mcore-create-issue Skill, mcore-create-issue Skill Card

### Community 267 - "Community 267"
Cohesion: 0.15
Nodes (19): jetson-diagnostic Skill, jetson-headless-mode Skill, jetson-inference-mem-tune Skill, jetson-link-docs Skill Card, jetson-llm-benchmark Skill, jetson-llm-serve Evaluation Report, jetson-llm-serve Skill, jetson-llm-serve Skill Card (+11 more)

### Community 268 - "Community 268"
Cohesion: 0.15
Nodes (19): CloudpickleMetricBundlePackager, NVSkills-Eval Evaluation Framework, NeMoPlatform Client, api_key_secret Configuration, bundle_metric Function, Durable Evaluation Execution, Evaluation Spec, LLM-as-Judge Metric (+11 more)

### Community 269 - "Community 269"
Cohesion: 0.18
Nodes (19): CPU Offloading Alternative, Full-Layer Recompute, Llama3 70B SFT FP8 CS Benchmark, MLP Recompute, recompute_modules Configuration, Selective Recompute, HybridDeviceOptimizer, Activation CPU Offloading (+11 more)

### Community 270 - "Community 270"
Cohesion: 0.11
Nodes (19): baseline, type, $ref, items, type, type, type, after (+11 more)

### Community 271 - "Community 271"
Cohesion: 0.11
Nodes (19): cheap, expensive, medium, stage_dependent, $comment, pattern, type, properties (+11 more)

### Community 272 - "Community 272"
Cohesion: 0.11
Nodes (19): ground_truth_path, label_map_loaded, label_map_source, ndim, required, any_label_present, class_counts, class_volumes_ml (+11 more)

### Community 273 - "Community 273"
Cohesion: 0.11
Nodes (19): openability, rule, pattern, type, type, minimum, type, enum (+11 more)

### Community 274 - "Community 274"
Cohesion: 0.35
Nodes (19): train.optim.embedder.base_lr, train.optim.embedder.bias_lr_factor, train.optim.embedder.momentum, train.optim.embedder.weight_decay, train.optim.embedder.weight_decay_bias, train.optim.gamma, train.optim.miner_function_margin, train.optim.triplet_loss_margin (+11 more)

### Community 275 - "Community 275"
Cohesion: 0.11
Nodes (19): nvds_inference_template Configuration, nvds_preprocess_template Configuration, VLM Prompts Configuration, Evaluation SOP Prompt, Example SOP Prompt, DeepStream SOP README Reference, FastAPI Endpoints Reference, Pydantic API Schemas Reference (+11 more)

### Community 276 - "Community 276"
Cohesion: 0.17
Nodes (19): type, type, properties, type, integer, null, type, type (+11 more)

### Community 277 - "Community 277"
Cohesion: 0.11
Nodes (19): items, type, items, type, items, minItems, type, items (+11 more)

### Community 278 - "Community 278"
Cohesion: 0.30
Nodes (18): _aggregate(), _build_command(), _candidate_upstream_roots(), _detect_cuda(), _estimate_cost(), _load_config_override(), _load_json(), main() (+10 more)

### Community 279 - "Community 279"
Cohesion: 0.33
Nodes (18): _aggregate(), _anatomy_size_condition(), _candidate_upstream_roots(), _detect_cuda(), _expected_label_mapping(), _load_json(), _load_label_dict(), _load_request() (+10 more)

### Community 280 - "Community 280"
Cohesion: 0.11
Nodes (19): type, properties, null, string, type, type, type, type (+11 more)

### Community 281 - "Community 281"
Cohesion: 0.11
Nodes (19): type, properties, null, string, type, type, type, type (+11 more)

### Community 282 - "Community 282"
Cohesion: 0.26
Nodes (14): ConversionReport, convert_gsplat_to_usd(), default_upstream_root(), discover_generated_files(), emit_probe(), emit_report(), main(), parse_upstream_gsplat_suffixes() (+6 more)

### Community 283 - "Community 283"
Cohesion: 0.26
Nodes (14): _base_metadata(), _collect_usd_structure_metadata(), _count_applied_api(), _count_authored_references(), _count_material_bindings(), _count_meshes(), emit_report(), main() (+6 more)

### Community 284 - "Community 284"
Cohesion: 0.12
Nodes (19): items, type, items, type, items, type, additionalProperties, type (+11 more)

### Community 285 - "Community 285"
Cohesion: 0.11
Nodes (19): max_decay_steps, val_base, val_final, val_start, warm_up_steps, max_decay_steps, val_base, val_final (+11 more)

### Community 286 - "Community 286"
Cohesion: 0.13
Nodes (16): _adjust_group_size(), conv2d_implicit_gemm_kernel(), launch(), next_power_of_2(), Constant, pytorch_reference(), Compute 2D convolution with bias via implicit im2col GEMM on tensor cores., Launch the conv2d implicit GEMM kernel with persistent scheduling. (+8 more)

### Community 287 - "Community 287"
Cohesion: 0.13
Nodes (16): _adjust_group_size(), conv_transpose_2d_implicit_gemm_kernel(), launch(), next_power_of_2(), Constant, pytorch_reference(), Compute 2D transposed convolution via implicit im2col GEMM on tensor cores., Launch the optimized implicit GEMM kernel with heuristic tile selection. (+8 more)

### Community 288 - "Community 288"
Cohesion: 0.13
Nodes (16): _adjust_group_size(), conv_transpose_3d_implicit_gemm_kernel(), launch(), next_power_of_2(), Constant, pytorch_reference(), Compute 3D transposed convolution via implicit im2col GEMM on tensor cores., Launch the optimized implicit GEMM kernel with heuristic tile selection. (+8 more)

### Community 289 - "Community 289"
Cohesion: 0.23
Nodes (18): CalibrationError, cmd_check(), cmd_ensure(), generate_calibration(), generate_sensor_id(), get_sensor_count(), load_calibration(), main() (+10 more)

### Community 290 - "Community 290"
Cohesion: 0.19
Nodes (11): backup_once(), compute_tile_grid(), die(), require_dir(), require_file(), resolve_unique_path(), common.sh script, update_ds_config() (+3 more)

### Community 291 - "Community 291"
Cohesion: 0.16
Nodes (18): Activation Checkpointing, Context Parallelism (CP), DDP, DTensor, Expert Parallelism (EP), FSDP2, Hybrid Sharded Data Parallel (HSDP), MegatronFSDP (+10 more)

### Community 292 - "Community 292"
Cohesion: 0.18
Nodes (18): ArangoDB Graph Backend, Cosmos Reason 2 VLM, Elasticsearch Database Backend, Human-In-The-Loop (HITL), LVS Video Summarization Microservice, Neo4j Graph Backend, vss-summarize-video Skill, vss-summarize-video Skill Card (+10 more)

### Community 293 - "Community 293"
Cohesion: 0.20
Nodes (18): Beehive Cloud Services, Beekeeper Management, BioCLIP 2.5, Sage Edge Nodes, Edge Scheduler, Manifest Exposure, Node Info, Node Manifests API (+10 more)

### Community 294 - "Community 294"
Cohesion: 0.16
Nodes (18): check_router_health.py Script, collect_dynamo_debug_bundle.py Script, Dynamo Kubernetes Recipe, K8s Recipe Workflow, Router Modes, Failure Decision Tree, Dynamo Troubleshoot Workflow, KV Routing (+10 more)

### Community 295 - "Community 295"
Cohesion: 0.15
Nodes (18): BSP Image, BSP Sources, Crosstool-NG Toolchain, documents Block, GPU Stack, Knowledge Base, Linux_for_Tegra, nvgpu (+10 more)

### Community 296 - "Community 296"
Cohesion: 0.18
Nodes (18): native_functions.yaml Registry, TileGym cuTile Python Skill Card, TileGym and Examples Guide, cuTile Implementation Lessons, cuTile Code Generation Rules, cuTile Concepts, Analyzer Agent, Composer Agent (+10 more)

### Community 297 - "Community 297"
Cohesion: 0.18
Nodes (18): Detect-Classify Cascade, Dockerfile COPY Gotcha, Heartbeat Telemetry, image-sampler2, Producer-Consumer Pattern, Ring Cache, Stack Architecture Map, WES Shared Filesystem and Cache Architecture (+10 more)

### Community 298 - "Community 298"
Cohesion: 0.12
Nodes (18): Direct Preference Optimization, Group Relative Policy Optimization, ModelOpt Distillation, ModelOpt Structured Pruning, ModelOpt Quantization, NeMo Evaluator Launcher, Packed Parquet Data, Pretraining Data Prep (+10 more)

### Community 299 - "Community 299"
Cohesion: 0.11
Nodes (18): Jetson Build Source Skill, Composite Custom Overlay, customize-* Skills, Dirty Repo Detection, jetson-flash-image, jetson-init-source, jetson-promote-image, kernel_src_build_env.sh (+10 more)

### Community 300 - "Community 300"
Cohesion: 0.11
Nodes (18): candidates, instances, prototypes, ratio, type, type, additionalProperties, description (+10 more)

### Community 301 - "Community 301"
Cohesion: 0.11
Nodes (18): return_code, wall_seconds, type, items, type, type, log_path, log_tail (+10 more)

### Community 302 - "Community 302"
Cohesion: 0.16
Nodes (15): build_trt_engine(), DDMWrapper, export_to_onnx(), find_ddm_base_path(), load_ddm_model(), main(), Module, Tensor (+7 more)

### Community 303 - "Community 303"
Cohesion: 0.25
Nodes (17): _axcodes_from_iop(), _iop_list(), _is_compressed_transfer_syntax(), _list_dicom_paths(), main(), _phi_tags_found(), preflight(), _public_path() (+9 more)

### Community 304 - "Community 304"
Cohesion: 0.22
Nodes (17): audit_int(), build_alternatives(), build_flags(), build_notes(), l4t_major(), llama_cpp_flags(), load_audit(), main() (+9 more)

### Community 305 - "Community 305"
Cohesion: 0.12
Nodes (18): description, type, type, type, type, items, type, properties (+10 more)

### Community 306 - "Community 306"
Cohesion: 0.11
Nodes (18): type, device, subprocess_seconds, type, type, type, type, properties (+10 more)

### Community 307 - "Community 307"
Cohesion: 0.11
Nodes (18): type, type, properties, type, const, type, properties, intended_use_disclaimer (+10 more)

### Community 308 - "Community 308"
Cohesion: 0.11
Nodes (18): type, type, type, type, type, type, type, minimum (+10 more)

### Community 309 - "Community 309"
Cohesion: 0.11
Nodes (18): type, type, type, type, type, type, type, minimum (+10 more)

### Community 310 - "Community 310"
Cohesion: 0.13
Nodes (18): minimum, type, boolean, integer, null, string, minimum, type (+10 more)

### Community 311 - "Community 311"
Cohesion: 0.13
Nodes (18): type, type, properties, null, number, string, type, type (+10 more)

### Community 312 - "Community 312"
Cohesion: 0.11
Nodes (17): asset_path, categories, command, errors, issue_counts, issues, next_step, passed (+9 more)

### Community 313 - "Community 313"
Cohesion: 0.11
Nodes (17): asset_path, categories, command, errors, issue_counts, issues, next_step, passed (+9 more)

### Community 314 - "Community 314"
Cohesion: 0.11
Nodes (17): asset_path, categories, command, errors, issue_counts, issues, next_step, passed (+9 more)

### Community 315 - "Community 315"
Cohesion: 0.12
Nodes (18): additionalProperties, description, type, description, type, properties, kit, probed_at (+10 more)

### Community 316 - "Community 316"
Cohesion: 0.11
Nodes (18): type, type, type, type, type, description, type, properties (+10 more)

### Community 317 - "Community 317"
Cohesion: 0.15
Nodes (18): Qwen Image Edit NIMService YAML, NIMService (Qwen OVSL2SL), vllm/vllm-omni:v0.20.0, Day 0 Image-Edit Endpoint Setup, Option A: Existing Endpoint, Option B: Local Cluster Endpoint, NIM Operator, physical-ai-defect-image-generation Skill Card (+10 more)

### Community 318 - "Community 318"
Cohesion: 0.42
Nodes (18): automl_default_parameters, automl_default_parameters, automl_default_parameters, dataset.augmentation.horizontal_flip_prob, dataset.augmentation.train_random_crop_max, dataset.augmentation.train_random_crop_min, model.dec_layers, model.enc_layers (+10 more)

### Community 319 - "Community 319"
Cohesion: 0.14
Nodes (15): _adjust_group_size(), conv3d_implicit_gemm_kernel(), launch(), next_power_of_2(), Constant, pytorch_reference(), Compute 3D convolution (no bias) via implicit im2col GEMM on tensor cores., Launch the conv3d implicit GEMM kernel with persistent scheduling. (+7 more)

### Community 320 - "Community 320"
Cohesion: 0.19
Nodes (17): BioCLIP Confidence Issue, BioCLIP Species Classifier, Detect-Then-Classify, Heartbeat invariant, Real GPU Inference Testing, Testing Patterns, Vision Detect-Then-Classify Pipeline, Vision Plugin Annotation and Confidence (+9 more)

### Community 321 - "Community 321"
Cohesion: 0.15
Nodes (17): BirdNET V2.4 Audio Classifier, BirdNET Geo-filtering, Capture timestamp, FLAC Audio Format, meta String Requirement, pywaggle SDK, pywaggle upload_file naming and metadata, Sentinel Collision Bug (+9 more)

### Community 322 - "Community 322"
Cohesion: 0.17
Nodes (17): Brev Instance Etiquette, Cache Management, Checkpoint Pattern, Environment Secrets Management, Ephemeral Storage Volume, Experiment Campaign, Agent Handoff, Hypothesis Testing (+9 more)

### Community 323 - "Community 323"
Cohesion: 0.15
Nodes (17): COCO Panoptic Dataset Format, Lightning Distributed Training, OneFormer Universal Segmentation Model, OneFormer Benchmark, OneFormer Deploy Skill Info, OneFormer Skill, OneFormer Skill Card, OneFormer Skill Info (+9 more)

### Community 324 - "Community 324"
Cohesion: 0.18
Nodes (17): CombinedGateUpMLP, CombinedQKVAttentionMixin, Dense LLM Pattern, HFCheckpointingMixin, Model Capabilities, Model Onboarding Workflow, Mixture of Experts Pattern, MoEConfig (+9 more)

### Community 325 - "Community 325"
Cohesion: 0.22
Nodes (17): Dataset Viewer API, DPO (Direct Preference Optimization), GRPO (Group Relative Policy Optimization), Hugging Face Hub, Hugging Face Jobs, SFT (Supervised Fine-Tuning), TRL (Transformer Reinforcement Learning), huggingface-datasets Skill (+9 more)

### Community 326 - "Community 326"
Cohesion: 0.20
Nodes (17): Continuous Pod Pattern, ECR App Catalog, k3s Sideload, One-shot Cron Pattern, pluginctl, QEMU Cross-build Failure, runc /proc/acpi Bug, SES Scheduler (+9 more)

### Community 327 - "Community 327"
Cohesion: 0.12
Nodes (17): Path Dictionary, Native Pick Query, Selection Outline, OVRTX C API, glTexSubImage2D Upload, CMake Build System, ovrtx_create_renderer, Single-Thread Rule (+9 more)

### Community 328 - "Community 328"
Cohesion: 0.26
Nodes (16): ModuleType, CompletedProcess, Path, _run(), _script_module(), test_api_backend_mock_keeps_json_contract(), test_api_backend_rejects_local_files_only(), test_check_setup_reports_json() (+8 more)

### Community 329 - "Community 329"
Cohesion: 0.12
Nodes (17): case, definition, examples_safe, examples_unsafe, in_scope, out_of_scope, resolution, items (+9 more)

### Community 330 - "Community 330"
Cohesion: 0.12
Nodes (17): copied_files, deliverable_root, output_root, rewritten_paths, root_usd_path, root_usd_relative_path, thumbnail_path, asset_name (+9 more)

### Community 331 - "Community 331"
Cohesion: 0.12
Nodes (17): target_class, properties, required, type, mesh_count, path, type, items (+9 more)

### Community 332 - "Community 332"
Cohesion: 0.16
Nodes (17): GPU Stack, Communication Fabric Layer, NCCL, UCX Transport, Idioms That Block, R106 Non-Unit Step Slicing, R203 Stack in Loop, R204 nonzero() Plus Indexing (+9 more)

### Community 333 - "Community 333"
Cohesion: 0.12
Nodes (16): type, type, type, type, type, items, type, properties (+8 more)

### Community 334 - "Community 334"
Cohesion: 0.15
Nodes (17): type, string, type, AccessionNumber, name, StudyDate, StudyDescription, StudyInstanceUID (+9 more)

### Community 335 - "Community 335"
Cohesion: 0.12
Nodes (17): type, type, type, minimum, type, properties, inconsistent_shape, input_dir (+9 more)

### Community 336 - "Community 336"
Cohesion: 0.29
Nodes (16): discover(), gpu_count_hint(), gpu_values_in_yaml_blocks(), line_matches(), main(), match_recipes(), metadata_names(), model_cache_dir_for() (+8 more)

### Community 337 - "Community 337"
Cohesion: 0.16
Nodes (17): _build_edit_record(), cmd_generate(), cmd_set_pin(), _prep_commit(), Namespace, Validate set-pin CLI args. Returns 0 on success, error code otherwise., Build a session pin_edit record from validated args + matched row., Record a single pin's user-chosen sfio/direction/state in session. (+9 more)

### Community 338 - "Community 338"
Cohesion: 0.12
Nodes (17): minLength, type, minimum, type, type, type, minLength, type (+9 more)

### Community 339 - "Community 339"
Cohesion: 0.15
Nodes (17): type, type, array, null, number, string, type, type (+9 more)

### Community 340 - "Community 340"
Cohesion: 0.12
Nodes (16): converter_command, converter_skill, converter_tool, errors, generated_files, next_step, output_directory, output_usd_path (+8 more)

### Community 341 - "Community 341"
Cohesion: 0.12
Nodes (16): converter_command, converter_skill, converter_tool, errors, generated_files, next_step, output_directory, output_usd_path (+8 more)

### Community 342 - "Community 342"
Cohesion: 0.12
Nodes (16): converter_command, converter_skill, converter_tool, errors, generated_files, next_step, output_directory, output_usd_path (+8 more)

### Community 343 - "Community 343"
Cohesion: 0.12
Nodes (17): type, type, type, type, type, type, properties, converter_reference (+9 more)

### Community 344 - "Community 344"
Cohesion: 0.32
Nodes (16): _aggregate_rigid_bodies_to_remove(), emit(), _find_component_body_candidates(), _find_rigid_bodies(), _has_schema(), _is_collider(), _is_mass_api(), _is_rigid_body() (+8 more)

### Community 345 - "Community 345"
Cohesion: 0.12
Nodes (16): actions, export, inference, automl_enabled, core_module, path, schema_action, spec_template (+8 more)

### Community 346 - "Community 346"
Cohesion: 0.12
Nodes (16): actions, evaluate, inference, automl_enabled, core_module, path, schema_action, spec_template (+8 more)

### Community 347 - "Community 347"
Cohesion: 0.20
Nodes (16): Robot Assembly Cookbook, Robot Assembly Augmentation, Robot Assembly Auto-Labeling, Robot Assembly Workflow Config, Trailer Dashcam Cookbook, Trailer Dashcam Augmentation Config, Trailer Dashcam Prompt Polishing Prompt, Trailer Dashcam Workflow Config (+8 more)

### Community 348 - "Community 348"
Cohesion: 0.16
Nodes (16): auto_label CLI, Bounding Boxes, Gemini VLM, Image Grounding Pipeline, KITTI Format, OpenAI-Compatible Endpoint, Qwen3-VL-30B-A3B-Instruct, Referring Expression Pipeline (+8 more)

### Community 349 - "Community 349"
Cohesion: 0.13
Nodes (16): AutoMagicCalib (AMC), BEV Fusion, Camera Name Normalization, DeepStream Perception, MV3DT Microservice, NUM_STREAMS Sync, RTVI-CV-3D, VSS Deploy Detection Tracking 3D Benchmark (+8 more)

### Community 350 - "Community 350"
Cohesion: 0.17
Nodes (16): Attention, Communication Wall, Compute Wall, CUDA Graphs for MoE, Expert Parallelism, FP8 for MoE, Memory Wall, AlltoAll Dispatcher (+8 more)

### Community 351 - "Community 351"
Cohesion: 0.12
Nodes (16): Convolution Examples, Deep Agent Orchestration Workflow, Matrix Multiplication Examples, Normalization Examples, Pooling Examples, Scan and Reduce Examples, tilegym-cutile-python Benchmark Report, cuTile Python Programming Skill (+8 more)

### Community 352 - "Community 352"
Cohesion: 0.14
Nodes (16): Cost volume convolution for stereo, depth_net TAO Deploy command, DepthNet Stereo architecture, Disparity map prediction, FoundationStereo model, GenericDataset data format, FoundationStereo skill card, StereoDataset data format (+8 more)

### Community 353 - "Community 353"
Cohesion: 0.21
Nodes (16): CUDA Forward Compatibility, CUDA Toolkit 13.0, Docker Runtime, DockerSDK, Holoscan SDK, NVIDIA GPU Operator for Kubernetes, NGC Docker Container, NVIDIA Container Toolkit (+8 more)

### Community 354 - "Community 354"
Cohesion: 0.14
Nodes (16): Agentic RAG, Brev Cloud Deployment, Conversation History, Git LFS, JupyterLab, LangChain Retriever Connector, LangGraph Agent, MCP Server (+8 more)

### Community 355 - "Community 355"
Cohesion: 0.17
Nodes (16): NVIDIA GPU Operator, H100 GPU, Helm Chart, Kubernetes, MIG GPU Slicing, NIMCache, NVIDIA NIM Operator, OKD (+8 more)

### Community 356 - "Community 356"
Cohesion: 0.12
Nodes (15): asset_physical_context, hierarchy_dedupe, phase_recommendation, summary_counts, validation_scope, additionalProperties, description, $id (+7 more)

### Community 357 - "Community 357"
Cohesion: 0.12
Nodes (16): command_prefix, config_stack, cwd, multi_gpu, nproc_per_node, train_dataset_cache_rate, required, type (+8 more)

### Community 358 - "Community 358"
Cohesion: 0.12
Nodes (16): generated_tokens, hf_space_api, hf_transformers, local_files_only, max_new_tokens, mock, model_revision, torch_dtype (+8 more)

### Community 359 - "Community 359"
Cohesion: 0.19
Nodes (15): _arch_bucket_from_compute_cap(), classify_bound(), compute_capacity(), main(), _nvdec_count_for_gpu(), parse_dmon(), parse_microbench(), Path (+7 more)

### Community 360 - "Community 360"
Cohesion: 0.17
Nodes (9): Load the checker from the cache., Save the checker to the cache., Try to delete the checker from the cache., Process SOP checking logic.          Args:             action_json: The content, Parse SOP steps from content string and return them as a list.      Args:, read_sop_steps(), SopCheckerCache, SopCheckerRequest (+1 more)

### Community 361 - "Community 361"
Cohesion: 0.31
Nodes (11): ConversionReport, discover_generated_files(), emit_probe(), emit_report(), is_mujoco_source(), main(), probe_source(), Any (+3 more)

### Community 362 - "Community 362"
Cohesion: 0.25
Nodes (14): check_dependencies(), check_upstream_validation(), default_upstream_root(), main(), Any, Path, resolve_usd_convert_cad_root(), _write_report() (+6 more)

### Community 363 - "Community 363"
Cohesion: 0.36
Nodes (15): _dedupe(), _detect_source_format(), _emit(), inspect_source_asset(), _local_identifiers(), main(), _markdown(), _metadata_from_excerpt() (+7 more)

### Community 364 - "Community 364"
Cohesion: 0.12
Nodes (16): description, type, description, description, type, properties, description, type (+8 more)

### Community 365 - "Community 365"
Cohesion: 0.23
Nodes (15): load_recorded_manifests(), main(), _manifest_targets(), Any, Path, Return a list of schema-violation messages; empty list means the report conforms, Enforce the load-bearing apply-restructure manifest invariants.      Independent, Load the manifests recorded in ``target_coverage.source_manifests[]``.      Rela (+7 more)

### Community 366 - "Community 366"
Cohesion: 0.13
Nodes (16): popular, batch_size, gpu_id, tensorrt, gen_trt_engine, train, max_batch_size, min_batch_size (+8 more)

### Community 367 - "Community 367"
Cohesion: 0.46
Nodes (16): automl_default_parameters, automl_default_parameters, automl_default_parameters, dataset.augmentation.horizontal_flip_prob, dataset.augmentation.train_random_crop_max, dataset.augmentation.train_random_crop_min, model.num_select, train.optim.lr (+8 more)

### Community 368 - "Community 368"
Cohesion: 0.12
Nodes (16): tao-train-sparse4d Benchmark, Sparse4D Local Docker Conversion, Sparse4D Skill Info, Sparse4D Spec Param Inference, Sparse4D Dataset Convert Template, Sparse4D Evaluate Template, Sparse4D Export Template, Sparse4D Inference Template (+8 more)

### Community 369 - "Community 369"
Cohesion: 0.12
Nodes (12): API_FAILS, CPU_UTILS, FPS_COUNT, FPS_SUM, GPU_MEM_GB, GPU_POWERS, GPU_TEMPS, GPU_UTILS (+4 more)

### Community 370 - "Community 370"
Cohesion: 0.14
Nodes (9): ABC, NotifierBase, Any, Abstract notifier. Each delivery backend implements this interface.      Lifecyc, Validate config and connect to the backend. Raise on fatal errors., Deliver a formatted notification for the given incident payload., Deliver a synthetic test notification to verify end-to-end wiring., Release any resources held by the backend (HTTP clients, etc.). (+1 more)

### Community 371 - "Community 371"
Cohesion: 0.24
Nodes (15): Image acquisition ladder, BirdNET Species Plugin, Camera Vendor Interface, Hanwha Wisenet Camera, HTTP vendor still endpoint, Mobotix Camera, Native Still Acquisition, Reolink Camera (+7 more)

### Community 372 - "Community 372"
Cohesion: 0.24
Nodes (15): Robot Assembly Auto-Labeling Config, Robot Assembly Event Analysis Prompt, Trailer Dashcam Auto-Labeling Config, Trailer Dashcam Event Analysis Prompt, Warehouse Auto-Labeling Config, Warehouse Event Analysis Prompt, BoostTrack Object Tracker, City Traffic Auto-labeling Config (+7 more)

### Community 373 - "Community 373"
Cohesion: 0.31
Nodes (15): City Traffic Event Analysis VLM Prompt, City Traffic Prompt Polishing System Prompt, City Traffic Scene, City Traffic Template Generation System Prompt, Lighting Augmentation Variable, Piazza Event Analysis VLM Prompt, Piazza Prompt Polishing System Prompt, Piazza Scene (+7 more)

### Community 374 - "Community 374"
Cohesion: 0.14
Nodes (15): 6-DoF Object Pose Estimation, CenterPose, TensorRT, tao-train-centerpose Benchmark Report, tao-train-centerpose SKILL, CenterPose Skill Card, CenterPose Skill Info, CenterPose Deploy Evaluate Spec Template (+7 more)

### Community 375 - "Community 375"
Cohesion: 0.15
Nodes (15): Automated Optical Inspection (AOI), NVIDIA Omniverse Asset Validator, Cosmos AnomalyGen (Cosmos-Predict2 finetuned), Defect Image Generation, OSMO Workflow Orchestration, Scene Optimizer Validators, USD-to-ROI Processing, USD Validation Runner (+7 more)

### Community 376 - "Community 376"
Cohesion: 0.13
Nodes (15): ASHA, AutoMLRunner, Autoresearch, Bayesian Optimization, Hyperband, LLM-Guided Search, Weights and Biases, tao-run-automl Skill (+7 more)

### Community 377 - "Community 377"
Cohesion: 0.16
Nodes (15): C2C (Chunk-To-Chunk Latency), Chunk E2E Latency, DDM TensorRT Optimization, Kafka Messaging, RTSP Streaming Output, TTFC (Time-To-First-Chunk), Environment Variables Reference, SOP Inference Microservice Evaluation Workflow (+7 more)

### Community 378 - "Community 378"
Cohesion: 0.20
Nodes (15): ECR, ECR (Edge Code Repository), Sage Edge Job YAML, Thor ARM64 Deploy Pipeline, Job YAML Template, sesctl CLI, ECR Public Apps API, Job Scheduling and Debugging (+7 more)

### Community 379 - "Community 379"
Cohesion: 0.16
Nodes (15): Metric Learning Recognition, tao-train-metric-learning-recognition Benchmark Report, ml-recog Skill Card, ml-recog Skill Info, tao-train-metric-learning-recognition SKILL, ml-recog Deploy Evaluate Spec Template, ml-recog Deploy Gen TRT Engine Spec Template, ml-recog Deploy Inference Spec Template (+7 more)

### Community 380 - "Community 380"
Cohesion: 0.13
Nodes (15): amp, run_inference, testing_cases, train_from_scratch, required, type, data_base_dir, datalist (+7 more)

### Community 381 - "Community 381"
Cohesion: 0.13
Nodes (15): batch_size, cache_rate, finetune, lr, validation_cases, required, data_base_dir, datalist (+7 more)

### Community 382 - "Community 382"
Cohesion: 0.13
Nodes (15): BodyPartExamined, phi_present, phi_scope_disclaimer, phi_tags_found, SeriesDescription, SeriesInstanceUID, SeriesNumber, study (+7 more)

### Community 383 - "Community 383"
Cohesion: 0.13
Nodes (15): customer_byo_policy, eval_rubric, ncs, ncs-reasoning, ncs-vl, nemo-guardrails, runtime_guardrails, training_data_labeling (+7 more)

### Community 384 - "Community 384"
Cohesion: 0.15
Nodes (15): excellent, improved, mixed, moderate, neutral, regressed, strong, score_label (+7 more)

### Community 385 - "Community 385"
Cohesion: 0.13
Nodes (15): html, json, markdown, additionalProperties, description, properties, required, type (+7 more)

### Community 386 - "Community 386"
Cohesion: 0.48
Nodes (15): model.mask_former.dec_layers, model.mask_former.hidden_dim, model.mask_former.num_object_queries, automl_default_parameters, automl_default_parameters, automl_default_parameters, dataset.augmentation.test_max_size, dataset.augmentation.test_min_size (+7 more)

### Community 387 - "Community 387"
Cohesion: 0.19
Nodes (8): main(), normalize_user_params(), Map user CLI params to the same vocabulary as pipeline metadata., Lowercase, strip punctuation, split into tokens.      `/` is intentionally NOT i, tokenize(), The tokenizer keeps compound hyphenated         tokens (config-file-path) intact, TestNormalizeUserParams, TestTokenizer

### Community 388 - "Community 388"
Cohesion: 0.20
Nodes (6): Detect memory format mismatches — e.g. nvjpegdec (system memory) feeding     dir, validate_memory_format(), Test memory format mismatch detection between elements., Test that NVMM checks cover encoders too., TestExpandedNVMMChecks, TestMemoryFormatValidation

### Community 389 - "Community 389"
Cohesion: 0.13
Nodes (15): type, properties, type, BodyPartExamined, dicom_metadata, SeriesDescription, SeriesInstanceUID, StudyDate (+7 more)

### Community 390 - "Community 390"
Cohesion: 0.13
Nodes (15): type, properties, type, exit_code, official_entrypoint, rendered_env_output_dir, rendered_env_output_prefix, rendered_model_config (+7 more)

### Community 391 - "Community 391"
Cohesion: 0.13
Nodes (15): type, properties, type, exit_code, official_entrypoint, rendered_env_output_dir, rendered_env_output_prefix, rendered_model_config (+7 more)

### Community 393 - "Community 393"
Cohesion: 0.27
Nodes (14): _find_output_mask(), _geometry_summary(), _input_summary(), main(), _mask_summary(), _public_path(), Path, SpatialImage (+6 more)

### Community 394 - "Community 394"
Cohesion: 0.13
Nodes (15): required, type, type, path, type, type, type, properties (+7 more)

### Community 395 - "Community 395"
Cohesion: 0.13
Nodes (15): type, type, properties, items, type, type, config_file, exit_code (+7 more)

### Community 396 - "Community 396"
Cohesion: 0.13
Nodes (15): type, type, type, type, type, properties, assembly_report_path, asset_name (+7 more)

### Community 397 - "Community 397"
Cohesion: 0.13
Nodes (15): type, type, type, type, properties, input_usd_path, next_step, output_dir (+7 more)

### Community 398 - "Community 398"
Cohesion: 0.35
Nodes (14): _child_output_path(), emit(), _empty_report(), _finalize(), _load_json(), main(), Any, Namespace (+6 more)

### Community 399 - "Community 399"
Cohesion: 0.31
Nodes (10): ConversionReport, discover_generated_files(), emit_probe(), emit_report(), main(), probe_source(), Any, Path (+2 more)

### Community 400 - "Community 400"
Cohesion: 0.13
Nodes (15): type, type, type, type, type, properties, converter_skill, converter_tool (+7 more)

### Community 401 - "Community 401"
Cohesion: 0.37
Nodes (14): conversion_command(), converted_checkpoint_status(), docker_checkpoint_mount(), docker_env_args(), ensure_cosmos_framework(), expand_path(), main(), parse_args() (+6 more)

### Community 402 - "Community 402"
Cohesion: 0.13
Nodes (15): export, inference, automl_default_parameters, automl_default_parameters, core_module, path, schema_action, spec_template (+7 more)

### Community 403 - "Community 403"
Cohesion: 0.18
Nodes (14): layernorm_backward(), layernorm_backward_kernel(), layernorm_dgamma_dbeta_kernel(), layernorm_forward(), layernorm_forward_kernel(), constexpr, Tensor, Triton kernel for layer normalization backward pass.      Computes dx given dy, (+6 more)

### Community 404 - "Community 404"
Cohesion: 0.20
Nodes (14): benchmark_matmul(), matmul(), matmul_fp16(), matmul_kernel(), matmul_kernel_autotuned(), constexpr, Tensor, Autotuned version of matmul kernel.      Autotune parameters:     - BLOCK_SIZE_M (+6 more)

### Community 405 - "Community 405"
Cohesion: 0.13
Nodes (14): Anomaly Event Category, Arm Malfunction Event, Arm Workpiece Contact Event, Backing Contact Event, Cable Trip Hazard Event, Collision Event Category, Component Drop Event, Hitch Issue Event (+6 more)

### Community 406 - "Community 406"
Cohesion: 0.15
Nodes (14): AutoMagicCalib (AMC) Camera Calibration, Camera Calibration Workflow, ResNet Detector for Calibration, Transformer Detector for Calibration, Docker Build Process, Docker Compose Deployment, Ground Truth Evaluation for Calibration, MV3DT (Multi-View 3D Tracking) Calibration Export (+6 more)

### Community 407 - "Community 407"
Cohesion: 0.14
Nodes (14): Catalog Routing, Implicit Invocation, NVIDIA Skills Catalog, NVSkills-Eval benchmark framework, Physical AI, jetson-customize-camera benchmark, jetson-customize-clocks benchmark, jetson-customize-fan benchmark (+6 more)

### Community 408 - "Community 408"
Cohesion: 0.18
Nodes (14): claude-code Agent, codex Agent, Context JSON, discover_assets.py, Governance Skill Card, Jinja Template, NVIDIA, render_card.py (+6 more)

### Community 409 - "Community 409"
Cohesion: 0.21
Nodes (14): Cosmos3-Nano Model, DEFT Video QA Workflow, LoRA Adapter Fine-tuning, Cosmos-RL AutoML / HPO Guide, Cosmos-RL Evaluate and Datasets Guide, Cosmos-RL Launch Intake and Preflight Guide, Cosmos-RL Parameters, Hardware, Errors, and Inference Mapping, Cosmos-Reason Detailed Guide Map (+6 more)

### Community 410 - "Community 410"
Cohesion: 0.14
Nodes (14): Dev Mode, Editable Install, Entrypoint Workaround, Log Progress Helper, NGC Base Image Selection, Shared Memory Size 16GB, Deliverables and README Reference, Docker Run Catalog (+6 more)

### Community 411 - "Community 411"
Cohesion: 0.15
Nodes (14): Hugging Face Vision Trainer Skill, D-FINE, Dataset Validation, Hugging Face Jobs, HfArgumentParser, Image Classification Training, Fine-tuning SAM2 with HF Trainer, Sam2Model (+6 more)

### Community 412 - "Community 412"
Cohesion: 0.21
Nodes (14): LanceDB Vector Database, NeMo Retriever Install Guide, NeMo Retriever Query Guide, NeMo Retriever Setup Guide, NeMo Retriever Troubleshooting, NeMo Retriever Skill, Pdfium Text Extraction, Retriever CLI (+6 more)

### Community 413 - "Community 413"
Cohesion: 0.22
Nodes (14): MONAI Bundle, Medical Decathlon Task06 Lung Tumor, Medical Decathlon Task09 Spleen, NV-Segment-CT Model, NV-Segment-CTMR Model, Task06 and Results Reference, NV-Segment-CT-Finetune Skill, NV-Segment-CT-Finetune Manifest (+6 more)

### Community 414 - "Community 414"
Cohesion: 0.16
Nodes (14): NVDINOv2, Self-Supervised Learning, tao-train-nvdinov2 Benchmark Report, NvDINOv2 Deploy, NVDINOv2 Skill Card, nvdinov2 Skill Info, tao-train-nvdinov2 SKILL, nvdinov2 Deploy Gen TRT Engine Spec Template (+6 more)

### Community 415 - "Community 415"
Cohesion: 0.26
Nodes (13): Prim, author_curve(), copy_sidecar(), main(), make_extent(), next_grasp_name(), parse_point(), Any (+5 more)

### Community 416 - "Community 416"
Cohesion: 0.14
Nodes (14): all_inference_outputs_present, checkpoint, checkpoint_bytes, checkpoint_present, embedding_sidecars, inference_outputs, num_embedding_sidecars, num_inference_outputs (+6 more)

### Community 417 - "Community 417"
Cohesion: 0.14
Nodes (14): case_id, prompt, minLength, type, additionalProperties, properties, required, type (+6 more)

### Community 418 - "Community 418"
Cohesion: 0.49
Nodes (14): dataset.augmentation.aug_prob, dataset.augmentation.blur_prob, dataset.augmentation.reverse_color_prob, dataset.augmentation.rotate_prob, automl_default_parameters, automl_default_parameters, automl_default_parameters, automl_default_parameters (+6 more)

### Community 419 - "Community 419"
Cohesion: 0.25
Nodes (14): dataset.test_dataset.batch_size, dataset.test_dataset.num_workers, dataset.train_dataset.batch_size, dataset.train_dataset.num_workers, dataset.val_dataset.batch_size, dataset.val_dataset.num_workers, evaluate, automl_default_parameters (+6 more)

### Community 420 - "Community 420"
Cohesion: 0.14
Nodes (14): errorCount, kind, warningCount, validator_entry, name, status, summary, additionalProperties (+6 more)

### Community 421 - "Community 421"
Cohesion: 0.15
Nodes (14): metersPerUnit, upAxis, additionalProperties, description, required, type, identifier, rootLayer (+6 more)

### Community 422 - "Community 422"
Cohesion: 0.14
Nodes (14): target, additionalProperties, required, type, $defs, coverage_ledger, ledger_entry, complete (+6 more)

### Community 423 - "Community 423"
Cohesion: 0.20
Nodes (10): check_element_exists(), main(), Check if a GStreamer element is registered using gst-inspect-1.0., Validate all elements exist and properties are recognized., Use gst-launch-1.0 for a dry-run parse check by substituting     fakesrc/fakesin, validate_elements(), validate_with_gst_launch(), Dry-run is skipped for multi-stream pipelines with named pad refs. (+2 more)

### Community 424 - "Community 424"
Cohesion: 0.22
Nodes (5): extract_elements_and_properties(), Parse a gst-launch-1.0 pipeline string and extract elements with properties., Regression: a run of leading flags such as         '-e -v' must be stripped toge, Regression: the live-parse source/sink         replacement must not match the el, TestElementParser

### Community 425 - "Community 425"
Cohesion: 0.25
Nodes (13): chart_ds_streams_vs_fps(), chart_efficiency(), chart_trt_vs_ds(), chart_trtexec_bs1_vs_bsmax(), chart_trtexec_throughput(), main(), Single bar: GPU-only imgs/sec at MAX_BS with PEAK_GPU_STREAMS annotation., Line chart: X=stream count, Y=fps/stream. Red dashed line at 30fps. (+5 more)

### Community 426 - "Community 426"
Cohesion: 0.15
Nodes (14): items, items, maxItems, minItems, type, items, maxItems, minItems (+6 more)

### Community 427 - "Community 427"
Cohesion: 0.26
Nodes (13): aws_bin(), get_role(), log(), main(), CompletedProcess, Resolve the `aws` executable, honoring PATHEXT (finds aws.exe/aws.cmd on Windows, Run an aws CLI command, capturing output. Never raises on nonzero exit., Return the Role dict from `aws iam get-role`, or None if it can't be read. (+5 more)

### Community 428 - "Community 428"
Cohesion: 0.18
Nodes (14): _build_commit_state(), cmd_commit(), _CommitState, _emit_diff(), _FileEdit, _print_commit_plan(), A single DTSI file's pre/post text and resolved path., In-flight state during a commit run. (+6 more)

### Community 429 - "Community 429"
Cohesion: 0.27
Nodes (13): _categorical_palette(), _emit_card_fallback(), _esc(), _fmt(), Any, Path, 132-class palette built from matplotlib qualitative colormaps so     adjacent la, Drop a minimal summary.html that records the reason rendering failed. (+5 more)

### Community 430 - "Community 430"
Cohesion: 0.14
Nodes (14): items, type, items, maxItems, minItems, type, type, command (+6 more)

### Community 431 - "Community 431"
Cohesion: 0.14
Nodes (14): items, type, items, maxItems, minItems, type, type, command (+6 more)

### Community 432 - "Community 432"
Cohesion: 0.14
Nodes (14): items, type, type, items, type, items, maxItems, minItems (+6 more)

### Community 433 - "Community 433"
Cohesion: 0.14
Nodes (13): $comment, input, intended_use_disclaimer, invocation, model, model_repo, output, runtime (+5 more)

### Community 434 - "Community 434"
Cohesion: 0.14
Nodes (14): items, type, type, items, type, items, command, label_ids_present (+6 more)

### Community 435 - "Community 435"
Cohesion: 0.14
Nodes (14): description, type, complete, entries, complete, source_manifests, target_coverage, description (+6 more)

### Community 436 - "Community 436"
Cohesion: 0.32
Nodes (13): build_context(), _eval_condition(), _find_endfor(), _find_if_parts(), main(), Any, _render_block(), render_template() (+5 more)

### Community 437 - "Community 437"
Cohesion: 0.14
Nodes (14): type, items, minItems, type, items, minItems, type, $ref (+6 more)

### Community 438 - "Community 438"
Cohesion: 0.35
Nodes (11): check_az_auth(), check_deploy_tfvars(), check_min_version(), fail(), finish(), ok(), require_cmds(), require_file() (+3 more)

### Community 439 - "Community 439"
Cohesion: 0.37
Nodes (13): check_disk_gb(), check_driver(), check_min_version(), check_port_listener(), check_ports_free(), fail(), finish(), microk8s_is_running() (+5 more)

### Community 440 - "Community 440"
Cohesion: 0.15
Nodes (3): probe_models_json(), endpoint_common.sh script, wait_for_models_ready()

### Community 441 - "Community 441"
Cohesion: 0.34
Nodes (13): _check_object_url_non_empty(), _collect_cache_input_urls(), _collect_localpaths(), _collect_setup_input_urls(), _emit_cache_default_action(), _find_setup_task(), _invalid_video_name_values(), _is_aug_task() (+5 more)

### Community 442 - "Community 442"
Cohesion: 0.20
Nodes (10): Detector, fetch_snapshot(), iter_image_dir(), main(), ndarray, Sage/Waggle ML Vision Plugin Template Updated pattern from yolo-object-counter (, Load your ML model here., Run inference on a numpy image (H, W, C) BGR.         Returns dict of {class_nam (+2 more)

### Community 443 - "Community 443"
Cohesion: 0.14
Nodes (14): optim, train, checkpoint_interval, clip_grad_norm, gpu_ids, layerwise_decay, num_epochs, num_gpus (+6 more)

### Community 444 - "Community 444"
Cohesion: 0.15
Nodes (14): SentenceTransformer Model Architectures, Decoder/Causal LLM Architecture Family, Encoder Architecture Family, Multimodal VLM Backbone, Router Architecture, Static Embedding Module, SentenceTransformer Training Arguments, BatchSamplers (+6 more)

### Community 445 - "Community 445"
Cohesion: 0.25
Nodes (6): DashboardNotifier, Any, Injects incident notifications directly into the OpenClaw Dashboard     ``alerts, Send a single RPC request and wait for the matching response., Open a WebSocket, complete the connect handshake, return the ws., Resolve or create the alerts session (lazy, once per lifetime).

### Community 446 - "Community 446"
Cohesion: 0.22
Nodes (13): Async Checkpoint Save, Fault Tolerance, Fault Tolerance Launcher (ft_launcher), In-Process Restart, Local Checkpointing, nvidia-resiliency-ext, NVRx Straggler Detection, Preemption Handling (+5 more)

### Community 447 - "Community 447"
Cohesion: 0.23
Nodes (13): Benchmark Report Generation, Custom BBox Parser, DeepStream Benchmark, NV Engine Build, NV Model Acquire, DS Run Pipeline, NV Import Vision Model Report, PEAK_GPU_STREAMS (+5 more)

### Community 448 - "Community 448"
Cohesion: 0.29
Nodes (13): corpus/ Directory, evaluate_rag.py Script, nv_accuracy RAGAS Metric, nv_context_relevance RAGAS Metric, nv_response_groundedness RAGAS Metric, NVIDIA_API_KEY Credential, RAGAS Evaluation Framework, rag-eval Skill (+5 more)

### Community 449 - "Community 449"
Cohesion: 0.17
Nodes (13): Data Designer, DataDesignerConfigBuilder, ModelConfig, NeMo Platform, NeMo Data Designer Plugin Benchmark, NeMo Platform Plugin Additions Reference, NeMo Data Designer Plugin Skill, Data Designer Plugin Skill Card (+5 more)

### Community 450 - "Community 450"
Cohesion: 0.24
Nodes (12): DatasetDict, autocast_ctx(), build_evaluator(), load_parallel_data(), log_trackio_dashboard(), main(), Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., Load (en, target_lang) parallel pairs for each target language as a DatasetDict. (+4 more)

### Community 451 - "Community 451"
Cohesion: 0.19
Nodes (13): Electron SHM Architecture, Headless SHM CLI, JSON App Protocol, Message Router, N-API Addon, OVStream SHM, Process Boundary Rule, Python Server Runtime (+5 more)

### Community 452 - "Community 452"
Cohesion: 0.21
Nodes (11): FileDataset, generate(), Path, main(), _make_dataset(), _make_volume(), ndarray, Path (+3 more)

### Community 453 - "Community 453"
Cohesion: 0.15
Nodes (12): artifact_paths, scope, selection_reason, targets, tier_assignments, additionalProperties, $comment, concepts (+4 more)

### Community 454 - "Community 454"
Cohesion: 0.15
Nodes (12): assumptions, date, policy_name, target_models, taxonomy_mode, use_cases, categories, version (+4 more)

### Community 455 - "Community 455"
Cohesion: 0.15
Nodes (13): attached, direct, external, measured, not_measured, not_run, proxy, enum (+5 more)

### Community 456 - "Community 456"
Cohesion: 0.15
Nodes (13): autoencoder_checkpoint, autoencoder_checkpoint_present, best_autoencoder_checkpoints, discriminator_checkpoint, discriminator_checkpoint_present, loss_history, num_best_autoencoder_checkpoints, artifacts_dir (+5 more)

### Community 457 - "Community 457"
Cohesion: 0.15
Nodes (13): conformance_audit, opportunity_detector, performance_tuning, regression_evidence, safety_gate, target_scoping, enum, role (+5 more)

### Community 458 - "Community 458"
Cohesion: 0.15
Nodes (13): copies, estimated_prim_savings, path_pattern, subtree_prims, properties, required, copies, estimated_prim_savings (+5 more)

### Community 459 - "Community 459"
Cohesion: 0.15
Nodes (12): coverage_ledger, phase, additionalProperties, $comment, schemaVersion, stage, summary, validators (+4 more)

### Community 460 - "Community 460"
Cohesion: 0.23
Nodes (13): load_time, storage_proxy, structure_proxy, enum, type, enum, type, composition (+5 more)

### Community 461 - "Community 461"
Cohesion: 0.15
Nodes (13): op, param, question, additionalProperties, type, $defs, concept, parameter_prerequisite (+5 more)

### Community 462 - "Community 462"
Cohesion: 0.15
Nodes (13): reason, recommended, top_candidates, additionalProperties, description, properties, required, type (+5 more)

### Community 463 - "Community 463"
Cohesion: 0.15
Nodes (13): response_text, text_chars, additionalProperties, properties, required, type, output, response_text (+5 more)

### Community 464 - "Community 464"
Cohesion: 0.22
Nodes (13): train.optimizer.args.lr, train.optimizer.args.weight_decay, quantize, automl_default_parameters, automl_default_parameters, automl_default_parameters, automl_default_parameters, automl_default_parameters (+5 more)

### Community 465 - "Community 465"
Cohesion: 0.26
Nodes (4): Check for common syntax errors., validate_syntax(), Regression: the underscore-typo check must         scope to the segment that own, TestSyntaxValidation

### Community 466 - "Community 466"
Cohesion: 0.23
Nodes (8): collate_fn(), compute_loss(), DataTrainingArguments, main(), ModelArguments, Dataset, Wraps a HF dataset into the format expected by SAM/SAM2 processors.      Each sa, SAMSegmentationDataset

### Community 467 - "Community 467"
Cohesion: 0.15
Nodes (12): input, intended_use_disclaimer, invocation, model, model_repo, output, runtime, skill (+4 more)

### Community 468 - "Community 468"
Cohesion: 0.15
Nodes (12): input, intended_use_disclaimer, invocation, model, model_repo, output, runtime, skill (+4 more)

### Community 469 - "Community 469"
Cohesion: 0.15
Nodes (13): type, device, preflight_only, subprocess_seconds, type, device, preflight_only, runtime (+5 more)

### Community 470 - "Community 470"
Cohesion: 0.15
Nodes (12): input, intended_use_disclaimer, invocation, model, model_repo, output, runtime, skill (+4 more)

### Community 471 - "Community 471"
Cohesion: 0.15
Nodes (13): required, type, cfg_guidance_scale_requested, dim_requested, modality_code, modality_name, model_config_override, model_config_override_path (+5 more)

### Community 472 - "Community 472"
Cohesion: 0.15
Nodes (13): type, type, type, type, type, properties, intended_use_disclaimer, license (+5 more)

### Community 473 - "Community 473"
Cohesion: 0.26
Nodes (9): ndarray, Path, _save_image(), test_build_command_matches_documented_entrypoint(), test_load_config_override_accepts_flat_and_nested_keys(), test_load_config_override_rejects_unknown_key(), test_stage_config_writes_model_and_environment_overrides(), test_summarize_image_and_aggregate_pass() (+1 more)

### Community 474 - "Community 474"
Cohesion: 0.15
Nodes (12): input, intended_use_disclaimer, invocation, model, model_repo, output, runtime, skill (+4 more)

### Community 475 - "Community 475"
Cohesion: 0.15
Nodes (13): required, type, cfg_guidance_scale_requested, dim_requested, modality_code, modality_name, model_config_override, model_config_override_path (+5 more)

### Community 476 - "Community 476"
Cohesion: 0.15
Nodes (13): type, type, type, type, type, properties, intended_use_disclaimer, license (+5 more)

### Community 477 - "Community 477"
Cohesion: 0.15
Nodes (12): input, intended_use_disclaimer, invocation, model, model_repo, output, runtime, skill (+4 more)

### Community 478 - "Community 478"
Cohesion: 0.15
Nodes (13): items, type, items, type, type, properties, type, checked_upstream_roots (+5 more)

### Community 479 - "Community 479"
Cohesion: 0.15
Nodes (13): type, device, preflight_only, subprocess_seconds, type, device, preflight_only, runtime (+5 more)

### Community 480 - "Community 480"
Cohesion: 0.15
Nodes (13): type, type, type, const, type, properties, input, intended_use_disclaimer (+5 more)

### Community 481 - "Community 481"
Cohesion: 0.15
Nodes (13): any_label_present, class_counts, class_volumes_ml, geometry, label_ids_present, label_prompts_requested, label_set_valid, shape (+5 more)

### Community 482 - "Community 482"
Cohesion: 0.15
Nodes (12): input, intended_use_disclaimer, invocation, model, model_repo, output, runtime, skill (+4 more)

### Community 483 - "Community 483"
Cohesion: 0.15
Nodes (13): converter_command, converter_skill, converter_tool, errors, generated_files, next_step, output_directory, output_usd_path (+5 more)

### Community 484 - "Community 484"
Cohesion: 0.15
Nodes (13): converter_command, converter_skill, converter_tool, errors, generated_files, next_step, output_directory, output_usd_path (+5 more)

### Community 485 - "Community 485"
Cohesion: 0.15
Nodes (13): items, type, items, minItems, type, $comment, pattern, type (+5 more)

### Community 486 - "Community 486"
Cohesion: 0.15
Nodes (13): pattern, type, items, maxItems, minItems, properties, items, type (+5 more)

### Community 487 - "Community 487"
Cohesion: 0.15
Nodes (13): $comment, type, minLength, type, properties, minLength, type, category (+5 more)

### Community 488 - "Community 488"
Cohesion: 0.19
Nodes (5): emit_user_input_required(), probe_nvcr_image_ref(), run_workflow_registry_probe(), preflight_credentials.sh script, usage()

### Community 489 - "Community 489"
Cohesion: 0.17
Nodes (13): Beehive downstream attribution, get_node_info accessor, Mobility tri-state, Node GPS and location resolution, Node identity sourcing and pywaggle upload contract, node-manifest-v2.json, Plugin duration performance telemetry, plugin.timeit context manager (+5 more)

### Community 490 - "Community 490"
Cohesion: 0.15
Nodes (12): actions, export, automl_enabled, automl_default_parameters, core_module, path, schema_action, spec_template (+4 more)

### Community 491 - "Community 491"
Cohesion: 0.26
Nodes (12): _build_parser(), _check_label_case(), _check_leakage(), main(), normalize_label(), ArgumentParser, Path, Return a list of human-readable validation errors (empty == valid).      Uses st (+4 more)

### Community 492 - "Community 492"
Cohesion: 0.14
Nodes (13): class_weight, dice_weight, hidden_dim, importance_sample_ratio, mask_weight, nheads, num_object_queries, mask_former (+5 more)

### Community 493 - "Community 493"
Cohesion: 0.54
Nodes (13): automl_default_parameters, automl_default_parameters, automl_default_parameters, automl_default_parameters, dataset.augmentation.test_max_size, dataset.augmentation.test_min_size, dataset.augmentation.train_max_size, train.optim.backbone_multiplier (+5 more)

### Community 494 - "Community 494"
Cohesion: 0.29
Nodes (12): main(), online_softmax_kernel_tma(), Constant, TMA single-tile strategy (TILE_SIZE >= N)., Online 2-pass strategy (one block per row)., Chunked 3-pass strategy (persistent scheduling)., _ref_softmax(), run_chunked() (+4 more)

### Community 495 - "Community 495"
Cohesion: 0.19
Nodes (12): benchmark_softmax(), constexpr, Tensor, Host wrapper for Triton softmax.      Applies softmax along the last dimension (, Test function to verify correctness., Benchmark Triton vs PyTorch softmax., Triton kernel for row-wise softmax.      Each program processes one row using th, Softmax kernel for rows larger than BLOCK_SIZE.      Uses multiple passes over t (+4 more)

### Community 496 - "Community 496"
Cohesion: 0.23
Nodes (12): matmul(), matmul_fp16(), matmul_kernel(), Constant, Tensor, Host wrapper for cuTile matrix multiplication.      Args:         a: Input tenso, FP16 matrix multiplication optimized for tensor cores.      Args:         a: Inp, Test function to verify correctness against PyTorch. (+4 more)

### Community 497 - "Community 497"
Cohesion: 0.21
Nodes (12): flash_attention_backward(), flash_attention_backward_kernel(), flash_attention_forward(), flash_attention_forward_kernel(), constexpr, Tensor, Flash Attention backward pass.      Key insight: Recompute attention weights on-, Host wrapper for Flash Attention forward pass.      Args:         Q: Query tenso (+4 more)

### Community 498 - "Community 498"
Cohesion: 0.24
Nodes (12): benchmark_rope(), precompute_freqs(), Constant, Tensor, Apply RoPE in-place to Q.  Q is modified directly.      Args:         Q:, Reference RoPE using PyTorch ops (returns new tensor, not in-place)., In-place RoPE: one block handles one (token, head) pair.     Persistent loop ove, Precompute RoPE cos/sin tables. (+4 more)

### Community 499 - "Community 499"
Cohesion: 0.17
Nodes (10): cutile_groupnorm(), group_norm_kernel(), GroupNorm, Constant, pytorch_reference(), Compute group normalization using PyTorch's built-in module., Initialize PyTorch GroupNorm wrapper., Apply group normalization. (+2 more)

### Community 500 - "Community 500"
Cohesion: 0.21
Nodes (11): build_test_incident(), humanize_category(), Any, Safely traverse nested dicts/lists, returning *default* on any miss., ``"ppe_violation"`` → ``"Ppe Violation"``., Synthetic incident for end-to-end wiring tests., safe_get(), build_slack_blocks() (+3 more)

### Community 501 - "Community 501"
Cohesion: 0.17
Nodes (12): AutoML Policy, Container Image Confirmation, Credential Filtering, Non-Negotiable Launch Preflight Gate, Platform Preflight, tao-train-single-step Benchmark, Single-Step Skill Info, tao-train-single-step Skill (+4 more)

### Community 502 - "Community 502"
Cohesion: 0.24
Nodes (12): Cloud Trigger Pattern, Deferred Retry Queue, Object Store Propagation Lag, Sage Data API, Cloud Trigger and External Notification Pattern, Cloud Trigger Patterns, Cloud-trigger Watchers, Data Query First Report and History (+4 more)

### Community 503 - "Community 503"
Cohesion: 0.23
Nodes (9): Compose, build_transforms(), DataTrainingArguments, main(), ModelArguments, Build torchvision transforms from the image processor's config., main(), build_transforms() (+1 more)

### Community 504 - "Community 504"
Cohesion: 0.26
Nodes (12): Artifact Type, Explorer Mode, Nemotron Customize Workflow, Nemotron Customize Benchmark, Project Scaffold Brief, Stage Implementation Brief, Artifact Compatibility Reference, Run Command Reference (+4 more)

### Community 505 - "Community 505"
Cohesion: 0.21
Nodes (12): CrossEncoder (Reranker), Hard Negative Mining, NanoBEIR Evaluator, SentenceTransformer (Bi-Encoder), SparseEncoder (SPLADE), Train Sentence-Transformers Models, Base Model Selection Guide, Dataset Formats for Sentence-Transformers (+4 more)

### Community 506 - "Community 506"
Cohesion: 0.27
Nodes (12): Initramfs Refresh, Kernel Image Mirror, Module Shadowing, Build Source Freshness Gate, jetson-promote-image Skill, jetson-promote-image Skill Card, DUT Access, jetson-validate-image Skill (+4 more)

### Community 507 - "Community 507"
Cohesion: 0.26
Nodes (12): MoE Model OOM Sizing, NCCL Timeout Debugging, common_utils.py SLURM Helpers, initialize.py Distributed Init, Slurm sbatch Script, srun-native Multi-Node Approach, Multi-Node Slurm Templates, Two-Phase srun Pattern (+4 more)

### Community 508 - "Community 508"
Cohesion: 0.18
Nodes (12): Prop-Robotics-Neutral profile, simready-foundation-conform-fet-000-core, simready-foundation-conform-fet-001-minimal, simready-foundation-conform-fet-004-simulate-multi-body-physics, simready-validate, nv-core-package-sample, nv-core-package-sample-validation, simready-conform-profile (+4 more)

### Community 509 - "Community 509"
Cohesion: 0.17
Nodes (12): all_geometry_consistent, all_images_hu_like, all_pairs_readable, any_foreground_present, union_label_ids_present, all_images_nonconstant, directory, num_samples (+4 more)

### Community 510 - "Community 510"
Cohesion: 0.17
Nodes (12): anatomy, maisi_label_id, output_label_id, required, image_path, image_readable, items, type (+4 more)

### Community 511 - "Community 511"
Cohesion: 0.20
Nodes (12): assembly_root, loadable_subasset, new_root, parent_assembly, prototype, shared_layer, enum, type (+4 more)

### Community 512 - "Community 512"
Cohesion: 0.17
Nodes (12): consistency, input_dir, inventory, orientation, phi, preflight, findings, intended_use_disclaimer (+4 more)

### Community 513 - "Community 513"
Cohesion: 0.17
Nodes (12): evaluate.dataset, evaluate.evaluation, evaluate.evaluation.soft_accuracy, evaluate.generation, evaluate.metrics.names, evaluate.model, evaluate.results, evaluate.task (+4 more)

### Community 514 - "Community 514"
Cohesion: 0.17
Nodes (12): model_pt_present, type, properties, required, type, type, type, label_map_path (+4 more)

### Community 515 - "Community 515"
Cohesion: 0.17
Nodes (12): selected_calls, errors, input_usd_path, next_step, output_usd_path, passed, reports, skill (+4 more)

### Community 516 - "Community 516"
Cohesion: 0.17
Nodes (12): standalone-package, kit, kit-extension, pip, standalone, runtime_route, source, enum (+4 more)

### Community 517 - "Community 517"
Cohesion: 0.33
Nodes (10): _ensure_venv(), _is_ollama_url(), _load_dotenv(), _pack_baseline(), _pid_alive(), _resolve_hermes_model(), setup-graphify.sh script, _status() (+2 more)

### Community 518 - "Community 518"
Cohesion: 0.20
Nodes (6): expand_with_synonyms(), Add domain-specific synonyms to boost recall., Score a single document against query tokens., Compute a multiplier based on structural metadata match., Find top-K most relevant pipelines for a query., TestSynonymExpansion

### Community 519 - "Community 519"
Cohesion: 0.29
Nodes (3): extract_pipeline_metadata(), Extract structural metadata from a pipeline string for filtering., TestPipelineMetadata

### Community 520 - "Community 520"
Cohesion: 0.29
Nodes (3): Check source/sink presence, required props, and named-pad consistency., validate_pipeline_structure(), TestStructureValidation

### Community 521 - "Community 521"
Cohesion: 0.17
Nodes (12): maxItems, minItems, type, items, maxItems, minItems, type, properties (+4 more)

### Community 522 - "Community 522"
Cohesion: 0.32
Nodes (11): build_exact_match_spec(), load_jsonl_rows(), main(), Any, Path, Write rows as JSONL and return the written path., Load plain JSONL or .gz JSONL rows., Build a local exact-match spec that does not require model credentials. (+3 more)

### Community 523 - "Community 523"
Cohesion: 0.27
Nodes (11): extract_pages(), find_matches(), main(), page_records(), page_text(), rank_pages(), Query-turn filename fast path for the nemo-retriever skill.  Reads `./pdfs/` fro, Return list of (score, page_number, doc_stem, text) sorted by     descending sco (+3 more)

### Community 524 - "Community 524"
Cohesion: 0.29
Nodes (9): ndarray, Path, _save_image(), test_build_command_matches_documented_entrypoint(), test_load_config_override_accepts_flat_and_nested_keys(), test_load_config_override_rejects_unknown_key(), test_stage_config_writes_model_and_environment_overrides(), test_summarize_image_and_aggregate_pass() (+1 more)

### Community 525 - "Community 525"
Cohesion: 0.17
Nodes (12): all_images_finite, all_images_nonconstant, all_images_nonnegative, all_images_readable, all_shapes_match_requested, all_spacing_match_requested, directory, num_samples (+4 more)

### Community 526 - "Community 526"
Cohesion: 0.17
Nodes (12): all_images_finite, all_images_nonconstant, all_images_nonnegative, all_images_readable, all_shapes_match_requested, all_spacing_match_requested, directory, num_samples (+4 more)

### Community 527 - "Community 527"
Cohesion: 0.17
Nodes (12): minLength, type, items, minItems, type, properties, limitations, runtime (+4 more)

### Community 528 - "Community 528"
Cohesion: 0.17
Nodes (12): type, type, device, inference_seconds, type, device, inference_seconds, model_load_seconds (+4 more)

### Community 529 - "Community 529"
Cohesion: 0.17
Nodes (12): description, type, description, type, null, string, properties, description (+4 more)

### Community 530 - "Community 530"
Cohesion: 0.20
Nodes (4): probe_health_ready(), probe_models_json(), endpoint_common.sh script, wait_for_models_ready()

### Community 531 - "Community 531"
Cohesion: 0.17
Nodes (12): train, train, compile, core_module, epoch, optm_warmup_epochs, optm_weight_decay, path (+4 more)

### Community 532 - "Community 532"
Cohesion: 0.27
Nodes (11): convert_to_jpg(), generate_csv(), generate_csv_siamese(), main(), normalize_label(), parse_label_from_filename(), NV_PCB_Siamese 14-column CSV mode.      Copies SDG images into images_dir with t, Extract label from filename pattern like 'PCB+bridge_00000.png'. (+3 more)

### Community 533 - "Community 533"
Cohesion: 0.23
Nodes (12): gen_trt_engine, automl_default_parameters, automl_default_parameters, automl_default_parameters, core_module, path, schema_action, spec_template (+4 more)

### Community 534 - "Community 534"
Cohesion: 0.17
Nodes (11): actions, evaluate, automl_enabled, core_module, path, schema_action, spec_template, failures (+3 more)

### Community 535 - "Community 535"
Cohesion: 0.24
Nodes (11): benchmark_rmsnorm(), Constant, Tensor, Reference implementation using PyTorch ops., Simple timing benchmark., RMSNorm kernel.  Each block handles one or more rows (persistent loop).      For, Host wrapper: RMSNorm with a fixed occupancy=4 ct.launch.      Args:         x:, _ref_rmsnorm() (+3 more)

### Community 536 - "Community 536"
Cohesion: 0.23
Nodes (11): _adjust_group_size(), launch_split_gemm(), main(), Constant, Compute reference matrix multiplication using torch.matmul., Run split-K GEMM and verify correctness against torch reference., Adjust GROUP_SIZE_M to evenly divide num_tiles_m., Compute a split-K GEMM tile with atomic accumulation into the output. (+3 more)

### Community 537 - "Community 537"
Cohesion: 0.24
Nodes (11): GET /api/papers/{id} Endpoint, POST /api/papers/index Endpoint, arXiv ID, HF Papers API, Hugging Face Papers Platform, HF Paper Publisher Example Usage, HF Paper Publisher Quick Reference, arXiv Paper Template (+3 more)

### Community 538 - "Community 538"
Cohesion: 0.25
Nodes (11): BackboneBase Class, Backbone V2 Registry, build_model Function, Image Classification Task, Object Detection Task, Semantic Segmentation Task, TAOLightningModule, Phase 2 Codebase Exploration (+3 more)

### Community 539 - "Community 539"
Cohesion: 0.27
Nodes (11): Headless Mode, Inference Memory Tuning, inspect-ai, lighteval, Memory Reclamation, SGLang, vLLM, huggingface-community-evals Skill (+3 more)

### Community 540 - "Community 540"
Cohesion: 0.27
Nodes (11): PhysicsNeMo Datapipe, Live Discovery Principle, PhysicsNeMo Model Families, PhysicsNeMo Search Recipes, PhysicsNeMo Taxonomy Navigation, PhysicsNeMo Discoverability, SciML Task Types, PhysicsNeMo Search Recipes (+3 more)

### Community 541 - "Community 541"
Cohesion: 0.27
Nodes (11): Instanceability Verdict System, ref_remap Mode, restructure Mode, USD Structure Assessment, apply-restructure Reference, Hierarchy-Dedupe Rewrite Tool Behavioral Specification, Ref Remap Mode Reference, Restructure Mode Reference (+3 more)

### Community 542 - "Community 542"
Cohesion: 0.20
Nodes (11): LLM Endpoint, Model Cache Setup, OSMO Workflow Pipeline, Multimodal Query Configuration, SeedVR2 Super Resolution Model, E2E OSMO Workflow Config, E2E Super Resolution OSMO Workflow Config, Setup Model Cache OSMO Workflow Config (+3 more)

### Community 543 - "Community 543"
Cohesion: 0.33
Nodes (11): First Answer Checklist for MLM vs Bridge, Loss Correlation Testing, Megatron Bridge, Megatron-LM (MLM), pretrain_gpt.py, scripts/training/run_recipe.py, translate_mlm_to_bridge Script, vanilla_gpt_pretrain_config Recipe (+3 more)

### Community 544 - "Community 544"
Cohesion: 0.18
Nodes (11): BitsAllocated, Columns, InstanceNumber, NumberOfFrames, PhotometricInterpretation, PixelRepresentation, Rows, SOPInstanceUID (+3 more)

### Community 545 - "Community 545"
Cohesion: 0.18
Nodes (11): BLOCKED, blocked_validation_runtime, probed_clean, probed_with_findings, TIMEOUT, timeout_recorded, user_declined, FAIL (+3 more)

### Community 546 - "Community 546"
Cohesion: 0.18
Nodes (11): CT_BODY, MRI_BODY, MRI_BRAIN, properties, enum, type, modality, ndim (+3 more)

### Community 547 - "Community 547"
Cohesion: 0.18
Nodes (10): dicom_metadata, n_slices, single_series, modality, output, runtime, skill, required (+2 more)

### Community 548 - "Community 548"
Cohesion: 0.18
Nodes (11): fast, long, minutes, enum, properties, estimated_time, selection_reason, targets (+3 more)

### Community 549 - "Community 549"
Cohesion: 0.18
Nodes (10): limitations, additionalProperties, $comment, input, output, runtime, skill, required (+2 more)

### Community 550 - "Community 550"
Cohesion: 0.18
Nodes (11): official_helper, properties, required, type, type, type, invocation, official_helper (+3 more)

### Community 551 - "Community 551"
Cohesion: 0.33
Nodes (10): convergence_every_iteration(), fortran_order_reshape(), item_in_hot_loop(), iterate_array(), object_dtype(), per_element_loop(), ndarray, python_min_max() (+2 more)

### Community 553 - "Community 553"
Cohesion: 0.18
Nodes (11): type, BodyPartExamined, series, SeriesDescription, SeriesInstanceUID, SeriesNumber, properties, type (+3 more)

### Community 554 - "Community 554"
Cohesion: 0.18
Nodes (11): type, items, type, all_present, files, properties, required, type (+3 more)

### Community 555 - "Community 555"
Cohesion: 0.47
Nodes (10): _args(), _fake_upstream(), Namespace, Path, test_custom_model_config_override_is_used(), test_preflight_payload_succeeds_without_upstream(), test_stage_configs_targets_existing_upstream_scripts(), test_validate_datalist_accepts_relative_images_and_default_modality() (+2 more)

### Community 556 - "Community 556"
Cohesion: 0.18
Nodes (11): type, items, type, all_present, files, properties, required, type (+3 more)

### Community 557 - "Community 557"
Cohesion: 0.18
Nodes (11): type, items, type, all_present, files, properties, required, type (+3 more)

### Community 558 - "Community 558"
Cohesion: 0.18
Nodes (11): type, type, type, properties, type, type, command, command_prefix (+3 more)

### Community 559 - "Community 559"
Cohesion: 0.18
Nodes (11): required, type, affine_match, affine_max_abs_diff, input_shape, input_spacing, output_shape, output_spacing (+3 more)

### Community 560 - "Community 560"
Cohesion: 0.18
Nodes (11): required, type, affine_match, affine_max_abs_diff, input_shape, input_spacing, output_shape, output_spacing (+3 more)

### Community 561 - "Community 561"
Cohesion: 0.44
Nodes (10): apply_metadata(), _build_metadata(), _custom_layer_metadata(), emit(), _load_extra_metadata(), main(), Any, Namespace (+2 more)

### Community 562 - "Community 562"
Cohesion: 0.38
Nodes (10): _bounds_metadata(), emit(), main(), _max_delta(), Any, Namespace, Path, repair_minimal() (+2 more)

### Community 563 - "Community 563"
Cohesion: 0.18
Nodes (11): properties, kit-extension, pip, standalone, description, type, package, source (+3 more)

### Community 564 - "Community 564"
Cohesion: 0.18
Nodes (11): type, caveat, recommended_tool, runtime_profiling, summary, type, additionalProperties, description (+3 more)

### Community 565 - "Community 565"
Cohesion: 0.18
Nodes (11): additionalProperties, description, properties, type, description, type, assetValidator, package (+3 more)

### Community 566 - "Community 566"
Cohesion: 0.18
Nodes (11): $comment, type, properties, items, type, $ref, complete, entries (+3 more)

### Community 567 - "Community 567"
Cohesion: 0.18
Nodes (11): pattern, type, properties, concept, reason, target, tier, type (+3 more)

### Community 568 - "Community 568"
Cohesion: 0.31
Nodes (8): move_cursor_to_first_line(), print_not_registered_state(), print_provider_name(), print_registered_state(), print_state(), register-azure-providers.sh script, test_cli_install(), usage()

### Community 569 - "Community 569"
Cohesion: 0.45
Nodes (9): check_az_auth(), check_min_version(), fail(), finish(), ok(), require_cmds(), preflight.sh script, version_ge() (+1 more)

### Community 570 - "Community 570"
Cohesion: 0.44
Nodes (9): check_min_version(), fail(), finish(), load_env(), ok(), require_cmds(), preflight.sh script, version_ge() (+1 more)

### Community 571 - "Community 571"
Cohesion: 0.45
Nodes (9): check_az_auth(), check_min_version(), fail(), finish(), ok(), require_cmds(), preflight.sh script, version_ge() (+1 more)

### Community 572 - "Community 572"
Cohesion: 0.33
Nodes (3): main(), run_client(), SyncServer

### Community 573 - "Community 573"
Cohesion: 0.25
Nodes (10): benchmark_matmul(), matmul(), matmul_kernel(), Constant, Tensor, Block-swizzle for L2 cache locality (L2 reuse across tiles)., Tiled GEMM: C = A @ B.      Each block computes one (TILE_M, TILE_N) output tile, GEMM C = A @ B with fixed tile sizes and occupancy.      Args:         a: (M, K) (+2 more)

### Community 574 - "Community 574"
Cohesion: 0.25
Nodes (10): autocast_ctx(), load_pair_dataset(), log_trackio_dashboard(), main(), Dataset, Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., Load a contrastive-pair dataset for training.      StaticEmbedding starts from r, bf16/fp16 autocast for evaluator calls outside the trainer. (+2 more)

### Community 575 - "Community 575"
Cohesion: 0.25
Nodes (5): NotifierResult, Outcome of a single backend delivery attempt., Any, Posts incident notifications to a Slack channel via the Slack Web API., SlackNotifier

### Community 576 - "Community 576"
Cohesion: 0.22
Nodes (10): Robot Assembly Template Generation Prompt, Warehouse Template Generation Prompt, Warehouse Workflow Config, Bright Lighting, Dim Lighting, Dry Surface Condition, Lighting (Augmentation Variable), Moderate Lighting (+2 more)

### Community 577 - "Community 577"
Cohesion: 0.24
Nodes (10): Compatibility Registry Invariants, HF Hub Xet CDN Hang, Idefics3 Llama Generate Workaround, Phase 0.5 Runner, Phase 4.3 Dockerfile Injection, PyTorch 2.5 SDPA GQA Workaround, SmolVLM 256M VQAv2 Requirements, Compatibility Workarounds Registry (+2 more)

### Community 578 - "Community 578"
Cohesion: 0.27
Nodes (10): BEVFusion, LiDAR Camera Fusion, tao-train-bevfusion Benchmark Report, tao-train-bevfusion SKILL, tao-train-bevfusion Skill Card, BEVFusion Skill Info, BEVFusion Dataset Convert Spec Template, BEVFusion Evaluate Spec Template (+2 more)

### Community 579 - "Community 579"
Cohesion: 0.24
Nodes (9): ConstBool, ConstInt, fmha_forward(), fmha_kernel(), Tensor, Host wrapper for FMHA forward pass.      Args:         q: Query tensor [batch, n, Test FMHA against PyTorch reference., cuTile kernel for Fused Multi-Head Attention.      Args:         Q: Query tensor (+1 more)

### Community 580 - "Community 580"
Cohesion: 0.20
Nodes (7): gradio-app/trackio, Trackio Logging Metrics, Trackio, TRL Integration, wandb Compatibility, Trackio CLI Retrieving Metrics, trackio CLI

### Community 581 - "Community 581"
Cohesion: 0.20
Nodes (10): BSP Customization Workflow, quick_start_prefill, jetson-print-device-info Benchmark, jetson-print-device-info Skill, jetson-print-device-info Skill Card, jetson-quick-start Skill, jetson-quick-start Skill Card, jetson-set-target Skill (+2 more)

### Community 582 - "Community 582"
Cohesion: 0.20
Nodes (10): BSP Build, Build Modes, DTB Build, Kernel Image Build, OOT Modules Build, Jetson Build Modes Reference, DT Mode Build, Full Mode Build (+2 more)

### Community 583 - "Community 583"
Cohesion: 0.20
Nodes (10): Image Captioning, Metadata Filtering, Multimodal Query, Reasoning Panel, RAG UI on Port 8090, VLM Embeddings, VLM Inference, VLM Reranker (+2 more)

### Community 584 - "Community 584"
Cohesion: 0.20
Nodes (10): anatomy_list_requested, body_region_requested, config_infer_override, config_infer_override_path, num_output_samples_requested, required, type, random_seed (+2 more)

### Community 585 - "Community 585"
Cohesion: 0.20
Nodes (10): backing_op, canonical_name, cost_class, gpu_bound, implementations, preferred_provider, scope_policy, required (+2 more)

### Community 586 - "Community 586"
Cohesion: 0.20
Nodes (10): config_file, required, type, command, exit_code, model_inventory, official_entrypoint, output_dir (+2 more)

### Community 587 - "Community 587"
Cohesion: 0.20
Nodes (10): format, height, sha256, width, additionalProperties, required, type, path (+2 more)

### Community 588 - "Community 588"
Cohesion: 0.22
Nodes (10): operationsAvailable, required, application, extension, package, path, source, version (+2 more)

### Community 589 - "Community 589"
Cohesion: 0.20
Nodes (9): phase4_targets, allOf, $comment, description, mode, required, $schema, title (+1 more)

### Community 590 - "Community 590"
Cohesion: 0.20
Nodes (10): FBMEM (Framebuffer Memory), Memory Hierarchy Layer, SYSMEM (Pageable Host Memory), ZCMEM (Pinned Host Memory), R201 Allocation Inside a Loop, R202 Rebind Pattern x = x + y, R001 Vectorized Elementwise Expression, R006 Pre-Allocation via out= Parameter (+2 more)

### Community 591 - "Community 591"
Cohesion: 0.22
Nodes (4): _by_name(), Internal ApiEntry bookkeeping (token strings, docs_url, cupynumeric_name)     mu, test_parse_comparison_covers_all_token_formats(), test_render_markdown_drops_redundant_fields()

### Community 592 - "Community 592"
Cohesion: 0.29
Nodes (10): Data Designer Autopilot Workflow, Data Designer Interactive Workflow, PersonFromFakerSamplerParams, PersonSamplerParams, Person Sampling, Preview Review Guide, Seed Datasets Reference, Data Designer Skill (+2 more)

### Community 593 - "Community 593"
Cohesion: 0.38
Nodes (9): _affine_from_dicom(), main(), _missing_required_tags(), _public_path(), Dataset, ndarray, Path, Build a NIfTI-style RAS+ affine from DICOM ImageOrientationPatient + PixelSpacin (+1 more)

### Community 594 - "Community 594"
Cohesion: 0.44
Nodes (9): container_names(), kubectl_json(), main(), pod_names(), Any, Path, redact(), run() (+1 more)

### Community 595 - "Community 595"
Cohesion: 0.20
Nodes (9): # TODO: Store time step as timedelta, # TODO: Set grid dimensions from reference. Keep public, # TODO: Replace with actual checkpoint URL, # NOTE: Only override .to() if there is non-PyTorch state to manage, # TODO: Reshape input tensor for the core model, # TODO: Reshape output back to E2S format, # TODO: Return actual output instead of placeholder, # TODO: Import optional packages here (+1 more)

### Community 596 - "Community 596"
Cohesion: 0.38
Nodes (9): find_base_python(), interpreter_version(), log(), main(), parse_version(), Path, Path to the interpreter inside a venv, per platform., Locate a base interpreter for the requested version for `python -m venv`. (+1 more)

### Community 597 - "Community 597"
Cohesion: 0.20
Nodes (10): type, type, properties, type, cuda, estimated_cost, preflight, warnings (+2 more)

### Community 598 - "Community 598"
Cohesion: 0.20
Nodes (10): type, device, subprocess_seconds, device, runtime, subprocess_seconds, properties, required (+2 more)

### Community 599 - "Community 599"
Cohesion: 0.20
Nodes (10): type, type, properties, type, cuda, estimated_cost, preflight, warnings (+2 more)

### Community 600 - "Community 600"
Cohesion: 0.20
Nodes (10): type, device, subprocess_seconds, device, runtime, subprocess_seconds, properties, required (+2 more)

### Community 601 - "Community 601"
Cohesion: 0.49
Nodes (9): _args(), _fake_upstream(), Namespace, Path, test_preflight_payload_reports_skill_entrypoint(), test_stage_configs_writes_absolute_paths_and_training_options(), test_validate_datalist_rejects_missing_validation_split(), test_validate_datalist_requires_training_and_validation_cases() (+1 more)

### Community 602 - "Community 602"
Cohesion: 0.20
Nodes (10): type, device, subprocess_seconds, device, runtime, subprocess_seconds, properties, required (+2 more)

### Community 603 - "Community 603"
Cohesion: 0.20
Nodes (10): items, type, items, type, type, converter_command, generated_files, sidecar_inputs (+2 more)

### Community 604 - "Community 604"
Cohesion: 0.20
Nodes (10): items, type, items, type, type, converter_command, errors, sidecar_inputs (+2 more)

### Community 605 - "Community 605"
Cohesion: 0.20
Nodes (10): items, type, type, items, type, findings, payloads, usedLayers (+2 more)

### Community 606 - "Community 606"
Cohesion: 0.20
Nodes (10): type, identifier, identifier, rootLayer, stage, type, additionalProperties, properties (+2 more)

### Community 607 - "Community 607"
Cohesion: 0.20
Nodes (10): minLength, type, minLength, type, properties, op, param, question (+2 more)

### Community 608 - "Community 608"
Cohesion: 0.44
Nodes (8): check_min_version(), fail(), finish(), ok(), require_cmds(), preflight.sh script, version_ge(), warn()

### Community 609 - "Community 609"
Cohesion: 0.29
Nodes (9): _build_parser(), build_state(), main(), ArgumentParser, Namespace, Path, Return a resolved image URI from versions.yaml at the given key path.      Looks, _resolve_image_from_versions_yaml() (+1 more)

### Community 610 - "Community 610"
Cohesion: 0.29
Nodes (9): _build_inference_spec(), main(), _pick_best(), prepare(), Any, Path, Write best_model.json and best_model_inference_spec.yaml.      Returns a dict ma, Return (iteration_label, iteration_dict) with the lowest far_pct. (+1 more)

### Community 611 - "Community 611"
Cohesion: 0.20
Nodes (9): _adjust_group_size(), matmul_kernel(), Constant, Compute reference matrix multiplication using torch.matmul., Heuristic tile config selection., Adjust GROUP_SIZE_M to evenly divide num_tiles_m., Compute matrix multiplication over 4D tensors using tiled MMA., reference_matmul() (+1 more)

### Community 612 - "Community 612"
Cohesion: 0.29
Nodes (9): autocast_ctx(), load_resolved_dataset(), log_trackio_dashboard(), main(), Load (query, positive, negative, score) rows. The MSMARCO subset is keyed by, bf16/fp16 autocast for evaluator calls outside the trainer (which has its own au, Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam. (+1 more)

### Community 613 - "Community 613"
Cohesion: 0.29
Nodes (9): autocast_ctx(), load_resolved_dataset(), log_trackio_dashboard(), main(), Load (query, positive, negative, score) rows. The MSMARCO subset is keyed by, bf16/fp16 autocast for evaluator calls outside the trainer (which has its own au, Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam. (+1 more)

### Community 614 - "Community 614"
Cohesion: 0.22
Nodes (7): CONFIGS, resolve_or_override(), resolve_unique(), RESOURCES, apply_config.sh script, SPARSE4D_REPO, TRITON_REPO

### Community 615 - "Community 615"
Cohesion: 0.24
Nodes (7): build_dashboard_message(), _format_timestamp(), GatewayRpcError, _http_url_to_ws_url(), Exception, Raised when a gateway RPC call returns an error frame., Build a markdown notification body for OpenClaw chat.

### Community 616 - "Community 616"
Cohesion: 0.22
Nodes (9): Trailer Dashcam Template Generation Prompt, Clear Weather, Evening Time of Day, Midday Time of Day, Morning Time of Day, Overcast Weather, Rain Weather, Time of Day (Augmentation Variable) (+1 more)

### Community 617 - "Community 617"
Cohesion: 0.36
Nodes (9): Auto Labeling Model Cache, Cosmos Model Cache, OSMO Cache Workflow, Output Retrieval, VDA Setup Guide, VDA Troubleshooting, Pre-Submit Guard Script, Credential Preflight Script (+1 more)

### Community 618 - "Community 618"
Cohesion: 0.33
Nodes (9): Brev GPU Instances, Cosmos-Predict2.5, Cosmos-RL, TAO Inference Microservice, Service Registry, Inference Service Configuration, TAO Inference Microservice, Brev GPU Instances (+1 more)

### Community 619 - "Community 619"
Cohesion: 0.31
Nodes (9): Action Recognition, tao-train-action-recognition Benchmark Report, tao-train-action-recognition SKILL, tao-train-action-recognition Skill Card, Action Recognition Skill Info, Action Recognition Evaluate Spec Template, Action Recognition Export Spec Template, Action Recognition Inference Spec Template (+1 more)

### Community 620 - "Community 620"
Cohesion: 0.28
Nodes (9): nibabel (NIfTI Python Library), PHI (Protected Health Information) Detection, pydicom (DICOM Python Library), DICOM Metadata Extract Skill, DICOM Metadata Extract Skill Manifest, DICOM Series Preflight Skill, DICOM Series Preflight Skill Manifest, DICOM Series to Volume Skill (+1 more)

### Community 621 - "Community 621"
Cohesion: 0.22
Nodes (9): NVSkills-Eval Benchmarking Framework, DICOM Metadata Extract Benchmark, DICOM Series Preflight Benchmark, DICOM Series to Volume Benchmark, MoE Dispatcher Selection Benchmark, MoE Hardware Configs Benchmark, MoE Long Context Benchmark, MoE Optimization Workflow Benchmark (+1 more)

### Community 622 - "Community 622"
Cohesion: 0.25
Nodes (9): Subtree Hashing for Instance Candidates, USD Edit Target Planning, USD Hierarchy Deduplication, Variant and Payload Gates, USD Edit Target Planner, Output Saving Policy, USD Variants and Payloads Strategy, USD Hierarchy Dedupe Candidates (+1 more)

### Community 623 - "Community 623"
Cohesion: 0.22
Nodes (9): Diffusion UNet finetuning, LPIPS perceptual loss library, MAISI VAE autoencoder, environment_maisi_vae_train.json, config_maisi_vae_train.json, MONAI-style JSON datalist, NIfTI volume format, NV-Generate-VAE-Finetune SKILL (+1 more)

### Community 624 - "Community 624"
Cohesion: 0.25
Nodes (9): Hugging Face ZeroGPU Skill, torch.cuda Monkey-Patch, gr.State Semantics, Gradio, Module-Scope Model Loading, Pickle Serialization, Process Isolation, spaces Package (+1 more)

### Community 625 - "Community 625"
Cohesion: 0.25
Nodes (9): Ingestor API, Ingestor Server, Agentic RAG Configuration, RAG API Reference, Data Catalog Configuration, RAG Server, RAG Server API, Agentic RAG (+1 more)

### Community 626 - "Community 626"
Cohesion: 0.39
Nodes (9): Nemotron-3 Content Safety, Nemotron Content Safety Reasoning 4B, Nemotron System Prompt Template, Policy Markdown Template, Content Safety V2 Taxonomy, Policy Archetypes Patterns, Target Models Documentation, Nemotron Policy Generator Skill (+1 more)

### Community 627 - "Community 627"
Cohesion: 0.22
Nodes (9): approved, type, properties, skipped, approved_by_user, reason, status, type (+1 more)

### Community 628 - "Community 628"
Cohesion: 0.22
Nodes (9): counting_method, layers, additionalProperties, description, required, type, payloads, references (+1 more)

### Community 629 - "Community 629"
Cohesion: 0.22
Nodes (8): schema_version, additionalProperties, $comment, concepts, required, $schema, title, type

### Community 630 - "Community 630"
Cohesion: 0.56
Nodes (9): train.optim.warmup_epochs, automl_default_parameters, automl_default_parameters, automl_default_parameters, train.optim.backbone_multiplier, train.optim.lr, train.optim.momentum, train.optim.weight_decay (+1 more)

### Community 631 - "Community 631"
Cohesion: 0.31
Nodes (8): SequentialEvaluator, autocast_ctx(), log_trackio_dashboard(), main(), Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., bf16/fp16 autocast for evaluator calls outside the trainer (which has its own au, Surface the Trackio dashboard URL so the user can watch training live., setup_logging()

### Community 632 - "Community 632"
Cohesion: 0.42
Nodes (8): fused_with_out(), jacobi_step(), masked_assign(), matmul_chain(), ndarray, residual(), solve(), vectorized_update()

### Community 633 - "Community 633"
Cohesion: 0.36
Nodes (8): extract(), main(), _public_path(), Any, Path, Extract metadata from a DICOM file., Extract metadata from a DICOM file. Returns a JSON-serialisable dict., _safe_str()

### Community 634 - "Community 634"
Cohesion: 0.22
Nodes (9): type, minimum, type, minimum, type, properties, acceptable, n_fail (+1 more)

### Community 635 - "Community 635"
Cohesion: 0.42
Nodes (9): AWS Context Discovery Skill, Python Environment Requirements, Python Environment Setup Skill, SageMaker Deployment Planner Skill, SageMaker IAM Preflight Skill, Production Defaults Deployment Template, SageMaker Production Defaults Skill, Model to Serving Container Reference (+1 more)

### Community 636 - "Community 636"
Cohesion: 0.31
Nodes (4): __assign_variant(), __derive_generation_and_product_line(), __jetson_present(), detect_jetson.sh script

### Community 637 - "Community 637"
Cohesion: 0.22
Nodes (9): required, type, checked_upstream_roots, command, exit_code, official_entrypoint, upstream_commit, upstream_root (+1 more)

### Community 638 - "Community 638"
Cohesion: 0.22
Nodes (9): required, type, checked_upstream_roots, command, exit_code, official_entrypoint, upstream_commit, upstream_root (+1 more)

### Community 639 - "Community 639"
Cohesion: 0.22
Nodes (9): type, type, string, anatomy, finetuned_ckpt, recommended_ckpt, version, type (+1 more)

### Community 640 - "Community 640"
Cohesion: 0.39
Nodes (8): ndarray, Nifti1Image, Path, test_build_command_uses_documented_monai_bundle_entrypoint(), test_find_output_mask_prefers_upstream_single_image_layout(), test_mask_summary_accepts_known_labels_and_matching_geometry(), test_mask_summary_flags_labels_missing_from_loaded_label_map(), _write_nifti()

### Community 641 - "Community 641"
Cohesion: 0.36
Nodes (6): check_dependencies(), main(), Any, Path, _skill_name(), _write_report()

### Community 642 - "Community 642"
Cohesion: 0.22
Nodes (9): description, type, type, description, items, type, extension, operationsAvailable (+1 more)

### Community 643 - "Community 643"
Cohesion: 0.22
Nodes (9): properties, type, items, type, composition, instanceablePrims, references, items (+1 more)

### Community 644 - "Community 644"
Cohesion: 0.22
Nodes (9): type, type, type, defaultPrim, identifier, openedWith, rootLayer, type (+1 more)

### Community 645 - "Community 645"
Cohesion: 0.22
Nodes (9): type, type, properties, auditReport, converter, targetBottleneck, validationReport, type (+1 more)

### Community 646 - "Community 646"
Cohesion: 0.22
Nodes (9): properties, type, type, type, type, gates, mutationPolicy, postValidation (+1 more)

### Community 647 - "Community 647"
Cohesion: 0.22
Nodes (9): type, identifier, identifier, rootLayer, stage, type, properties, required (+1 more)

### Community 648 - "Community 648"
Cohesion: 0.53
Nodes (8): check_min_version(), fail(), finish(), ok(), require_cmds(), preflight.sh script, version_ge(), warn()

### Community 649 - "Community 649"
Cohesion: 0.44
Nodes (7): check_min_version(), fail(), finish(), ok(), osmo_client_version(), preflight.sh script, version_ge()

### Community 650 - "Community 650"
Cohesion: 0.31
Nodes (4): emit_user_input_required(), run_workflow_registry_probe(), preflight_credentials.sh script, usage()

### Community 651 - "Community 651"
Cohesion: 0.33
Nodes (8): append_stage(), _build_parser(), main(), next_seq(), ArgumentParser, Path, Append one stage event. Caller is responsible for measuring duration.      Raise, Return seq for the next entry: last entry's seq + 1, or 1 if no log yet.

### Community 652 - "Community 652"
Cohesion: 0.22
Nodes (9): OCRNet Skill Info, OCRNet Dataset Convert Spec Template, OCRNet Evaluate Spec Template, OCRNet Export Spec Template, OCRNet Inference Spec Template, OCRNet Prune Spec Template, OCRNet Quantize Spec Template, OCRNet Retrain Spec Template (+1 more)

### Community 653 - "Community 653"
Cohesion: 0.28
Nodes (8): Constant, Tensor, Test function to verify correctness., cuTile kernel for vector addition: C = A + B      Translation from Triton:     -, Host wrapper for cuTile vector addition.      Args:         a: Input tensor A, test_vector_add(), vector_add(), vector_add_kernel()

### Community 654 - "Community 654"
Cohesion: 0.25
Nodes (8): constexpr, Tensor, Triton kernel for vector addition: C = A + B      Translation from CUDA:     - b, Host wrapper for Triton vector addition.      Equivalent to CUDA launch_vector_a, Test function to verify correctness., test_vector_add(), vector_add(), vector_add_kernel()

### Community 655 - "Community 655"
Cohesion: 0.22
Nodes (9): ModelRegistry Reference, Pipeline Options Reference, PretrainedModelOptions, Text Generation Guide, TextStreamer, Transformers.js ML in JavaScript, ModelRegistry, @huggingface/transformers npm package (+1 more)

### Community 656 - "Community 656"
Cohesion: 0.25
Nodes (9): VSS Deploy Dense Captioning Benchmark, RT-VLM API Surface Notes, POST /v1/chat/completions, POST /v1/generate_captions, Deploy RT-VLM Service, rtvi-vlm Docker Container, RTVI VLM Kafka Workflows, VSS Deploy Dense Captioning Skill (+1 more)

### Community 657 - "Community 657"
Cohesion: 0.25
Nodes (8): Arm Idle Event, Equipment Operation Event, Normal Assembly Event, Normal Backing Event, Normal Construction Event, Normal Towing Event, Normal Traffic Event Category, Worker Transit Event

### Community 658 - "Community 658"
Cohesion: 0.50
Nodes (8): City Traffic Augmentation Config, Cosmos Guardrail Model, Cosmos Reason Model, Cosmos Transfer 2.5 Model, Piazza Augmentation Config, Qwen2.5-14B-Instruct LLM Model, Qwen3-VL-30B-A3B-Instruct VLM Model, Robot Assembly Augmentation Config

### Community 659 - "Community 659"
Cohesion: 0.32
Nodes (8): 3D Parallel for MoE, FSDP for MoE, Expert Tensor Parallelism, Qwen3-VL Model, Selective Recompute, Vision Encoder, MoE VLM, MoE VLM Training

### Community 660 - "Community 660"
Cohesion: 0.50
Nodes (8): GGUF (GPT-Generated Unified Format), llama.cpp, Ollama, GGUF Conversion Guide, Local Models Hardware Guide, Hub Discovery Guide, GGUF Quantization Guide, huggingface-local-models Skill

### Community 661 - "Community 661"
Cohesion: 0.25
Nodes (8): Pipeline Assembly Rules, Extra Operations, Inference Chain, Local Image Source, Local Video Source, Multi-Stream Pattern, RTSP Source Element, Sink Elements

### Community 662 - "Community 662"
Cohesion: 0.25
Nodes (8): Human Zone Intrusion Event, Near Miss Arm Event, Near Miss Event Category, Near Miss Equipment Event, Near Miss Falling Object Event, Near Miss Following Event, Near Miss Lane Change Event, Obstacle Proximity Event

### Community 663 - "Community 663"
Cohesion: 0.25
Nodes (8): Image Bridge, Inline Root, open_usd, ovui Window Shell, Render Pipeline, Scene Loading, ovui Local Setup Shell And Renderer, Stage Loading

### Community 664 - "Community 664"
Cohesion: 0.25
Nodes (8): KubeRay, Long-Lived RayCluster Mode, NeMo-RL Recipes, nrl-k8s CLI, RayJob Mode (Ephemeral), sbatch Script, launch-nemo-rl Skill, launch-nemo-rl Skill Card

### Community 665 - "Community 665"
Cohesion: 0.29
Nodes (8): GPU CAGRA Index, Elasticsearch Vector DB, Natural Language Filter Generator, Hybrid Search, Milvus Vector DB, Multi-Collection Retrieval, Reranker, RAG Search and Retrieval Configuration

### Community 666 - "Community 666"
Cohesion: 0.25
Nodes (8): LLM Summarization, NvidiaRAG, NvidiaRAGIngestor, nvidia-rag Python Package, Redis, Document Summarization, RAG Summarization Configuration, RAG Library Full Mode

### Community 667 - "Community 667"
Cohesion: 0.25
Nodes (8): AccessionNumber, StudyDate, StudyDescription, StudyInstanceUID, StudyTime, study, required, type

### Community 668 - "Community 668"
Cohesion: 0.25
Nodes (8): class_name, module, provider, use_for, implementation, additionalProperties, required, type

### Community 669 - "Community 669"
Cohesion: 0.25
Nodes (8): code, level, items, type, required, type, message, findings

### Community 670 - "Community 670"
Cohesion: 0.25
Nodes (8): conversion_seconds, minimum, type, conversion_seconds, runtime, properties, required, type

### Community 671 - "Community 671"
Cohesion: 0.25
Nodes (8): cross_component_pairs, per_asset, skip, validation_scope, additionalProperties, description, required, type

### Community 672 - "Community 672"
Cohesion: 0.25
Nodes (8): default, items, type, properties, required, type, default, label_mappings

### Community 673 - "Community 673"
Cohesion: 0.25
Nodes (8): evaluate.vision.fps, evaluate, automl_default_parameters, core_module, path, popular, schema_action, spec_template

### Community 674 - "Community 674"
Cohesion: 0.25
Nodes (8): policy.lora.lora_alpha, policy.lora.lora_dropout, policy.lora.r, train.optm_decay_type, train.optm_lr, train.optm_weight_decay, train.train_batch_per_replica, automl_default_parameters

### Community 675 - "Community 675"
Cohesion: 0.29
Nodes (8): runtime_context, runtime_route, assetValidator, probed_at, sceneOptimizer, schemaVersion, required, required

### Community 676 - "Community 676"
Cohesion: 0.25
Nodes (8): train.optim.text_lr, train.optim.vision_lr, train, automl_default_parameters, core_module, path, schema_action, spec_template

### Community 677 - "Community 677"
Cohesion: 0.36
Nodes (7): find_issues(), fix_row(), main(), normalize_pipeline(), Apply automatic fixes to a pipeline. Returns (prompt, fixed_pipeline) or None to, Normalize whitespace and line continuations for comparison., Return list of (row_index_0based, issue_type, message) tuples.

### Community 678 - "Community 678"
Cohesion: 0.36
Nodes (4): Detect platform-sink mismatches:     - nveglglessink used alongside nv3dsink hin, validate_platform_sink(), Test platform-sink mismatch detection., TestPlatformSinkValidation

### Community 679 - "Community 679"
Cohesion: 0.36
Nodes (4): Detect nonsensical element ordering — e.g. an encoder appearing before a     dec, validate_element_ordering(), Test element ordering checks., TestElementOrderingValidation

### Community 681 - "Community 681"
Cohesion: 0.54
Nodes (7): fixture_path(), Path, _run(), test_output_validates_against_schema(), test_phi_flag_true_for_synthetic_phi(), test_required_schema_fields(), test_script_runs_and_returns_json()

### Community 682 - "Community 682"
Cohesion: 0.32
Nodes (8): null, string, type, type, modality, path, series_instance_uid, type

### Community 683 - "Community 683"
Cohesion: 0.50
Nodes (7): aws_bin(), load_payload(), log(), main(), Namespace, Return the raw payload text, BOM stripped. Validates JSON when applicable., resolve_region()

### Community 684 - "Community 684"
Cohesion: 0.46
Nodes (7): aws_bin(), log(), main(), CompletedProcess, Region from arg, then env, then the active profile's config., resolve_region(), run_aws()

### Community 685 - "Community 685"
Cohesion: 0.39
Nodes (7): main(), Run inspect-ai evaluation with HuggingFace Transformers backend.      Use this w, Configure environment variables for HuggingFace authentication., Run inspect-ai evaluation with vLLM backend.      Args:         model_id: Huggin, run_inspect_hf(), run_inspect_vllm(), setup_environment()

### Community 686 - "Community 686"
Cohesion: 0.39
Nodes (7): main(), Run lighteval with accelerate backend for multi-GPU distributed inference., Configure environment variables for HuggingFace authentication., Run lighteval with vLLM backend for efficient GPU inference.      Args:, run_lighteval_accelerate(), run_lighteval_vllm(), setup_environment()

### Community 687 - "Community 687"
Cohesion: 0.29
Nodes (8): jetson-customize-usb Skill, USB Run-State JSON Sidecar Schema, Tegra USB Architecture (T234 Orin / T264 Thor), Tegra USB Device Tree Bindings, tegra_xusb Host xHCI Controller, UPHY Lane Pool Resource, xudc Device Gadget Controller, xusb_padctl USB Pad Controller

### Community 688 - "Community 688"
Cohesion: 0.43
Nodes (7): any_match(), classify(), main(), parse_args(), Namespace, Route, score_route()

### Community 689 - "Community 689"
Cohesion: 0.36
Nodes (7): emit(), file_sha256_safe(), git_commit(), Any, Path, sha256_file(), tail()

### Community 690 - "Community 690"
Cohesion: 0.25
Nodes (8): required, type, command, exit_code, model_inventory, official_entrypoint, upstream_root, invocation

### Community 691 - "Community 691"
Cohesion: 0.25
Nodes (8): required, type, command, exit_code, model_inventory, official_entrypoint, upstream_root, invocation

### Community 692 - "Community 692"
Cohesion: 0.29
Nodes (8): minimum, type, additionalProperties, type, additionalProperties, type, class_counts, class_volumes_ml

### Community 693 - "Community 693"
Cohesion: 0.32
Nodes (8): null, string, type, type, materialized_usd_path, physics_usd_path, textured_usdz_path, type

### Community 694 - "Community 694"
Cohesion: 0.25
Nodes (8): items, type, type, properties, type, modifiedLayers, outputDirectory, outputs

### Community 695 - "Community 695"
Cohesion: 0.25
Nodes (8): minimum, type, errorCount, status, warningCount, properties, minimum, type

### Community 696 - "Community 696"
Cohesion: 0.32
Nodes (8): Common Preconditions Detail, /dev/shm (dshm) Shared Memory, HuggingFace Token (hf-token), nvoptix.bin OptiX Denoiser, OSMO Pod Template, Troubleshooting Guide, IsaacSim Render Issues, usd2roi-render Issues

### Community 697 - "Community 697"
Cohesion: 0.25
Nodes (7): HF_TOKEN, IMAGE_EDIT_API_KEY, LLM_API_KEY, OPENAI_API_KEY, augmentation_worker.sh script, UV_PROJECT_ENVIRONMENT, VLM_API_KEY

### Community 698 - "Community 698"
Cohesion: 0.25
Nodes (6): HF_TOKEN, LLM_API_KEY, OPENAI_API_KEY, auto_labeling_worker.sh script, UV_PROJECT_ENVIRONMENT, VLM_API_KEY

### Community 699 - "Community 699"
Cohesion: 0.29
Nodes (7): HF_TOKEN, LLM_API_KEY, OPENAI_API_KEY, _recover_augmented_video_from_tmp(), cosmos_worker.sh script, UV_PROJECT_ENVIRONMENT, VLM_API_KEY

### Community 700 - "Community 700"
Cohesion: 0.25
Nodes (8): inference, automl_default_parameters, automl_disabled_parameters, core_module, path, popular, schema_action, spec_template

### Community 701 - "Community 701"
Cohesion: 0.25
Nodes (8): quantize, automl_default_parameters, automl_disabled_parameters, core_module, path, popular, schema_action, spec_template

### Community 702 - "Community 702"
Cohesion: 0.36
Nodes (7): augment_and_transform_batch(), compute_metrics(), format_image_annotations_as_coco(), main(), make_collate_fn(), Format (image_id, categories, areas, bboxes) as a COCO annotation dict for DETR, Replicate HF repo compute_metrics: post-process + torchmetrics MeanAveragePrecis

### Community 703 - "Community 703"
Cohesion: 0.25
Nodes (8): class_weight, dice_weight, hidden_dim, importance_sample_ratio, mask_weight, nheads, num_object_queries, mask_former

### Community 704 - "Community 704"
Cohesion: 0.46
Nodes (7): add_kernel(), add_scalar_kernel(), main(), Constant, run_add(), run_add_scalar(), verify()

### Community 705 - "Community 705"
Cohesion: 0.25
Nodes (7): avgpool3d_kernel(), next_power_of_2(), Constant, pytorch_reference(), Return the smallest power of 2 >= x., Compute 3D average pooling over each output element using gather-based window ac, Compute 3D average pooling using PyTorch's built-in function.

### Community 706 - "Community 706"
Cohesion: 0.25
Nodes (7): maxpool3d_kernel(), next_power_of_2(), Constant, pytorch_reference(), Return the smallest power of 2 >= x., Compute 3D max pooling with dilation using gather-based window access., Compute 3D max pooling using PyTorch's built-in function.

### Community 707 - "Community 707"
Cohesion: 0.29
Nodes (7): kernel_cumsum(), Constant, Compute cumulative sum along axis 1 for each batch tile., Launch the cumulative sum kernel and return the output., Compute cumulative sum along dim 1 using PyTorch., test_cumsum(), torch_reference()

### Community 708 - "Community 708"
Cohesion: 0.36
Nodes (7): autocast_ctx(), log_trackio_dashboard(), main(), bf16/fp16 autocast for evaluator calls outside the trainer (which has its own au, Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., setup_logging()

### Community 709 - "Community 709"
Cohesion: 0.36
Nodes (7): autocast_ctx(), log_trackio_dashboard(), main(), Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., bf16/fp16 autocast for evaluator calls outside the trainer (which has its own au, setup_logging()

### Community 710 - "Community 710"
Cohesion: 0.36
Nodes (7): autocast_ctx(), log_trackio_dashboard(), main(), Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., bf16/fp16 autocast for evaluator calls outside the trainer (which has its own au, Surface the Trackio dashboard URL so the user can watch training live., setup_logging()

### Community 711 - "Community 711"
Cohesion: 0.36
Nodes (7): autocast_ctx(), log_trackio_dashboard(), main(), bf16/fp16 autocast for evaluator calls outside the trainer (which has its own au, Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., setup_logging()

### Community 712 - "Community 712"
Cohesion: 0.36
Nodes (7): autocast_ctx(), log_trackio_dashboard(), main(), Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., bf16/fp16 autocast for evaluator calls outside the trainer (which has its own au, setup_logging()

### Community 713 - "Community 713"
Cohesion: 0.36
Nodes (7): autocast_ctx(), log_trackio_dashboard(), main(), bf16/fp16 autocast for evaluator calls outside the trainer (which has its own au, Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., setup_logging()

### Community 714 - "Community 714"
Cohesion: 0.36
Nodes (7): autocast_ctx(), log_trackio_dashboard(), main(), bf16/fp16 autocast for evaluator calls outside the trainer (which has its own au, Surface the Trackio dashboard URL so the user can watch training live., Configure logging + TF32. Tees to logs/{RUN_NAME}.log and silences HTTP spam., setup_logging()

### Community 715 - "Community 715"
Cohesion: 0.29
Nodes (7): AOV Switching, event_type Envelope, Message Protocol, Selection Sync, Streaming Messages, Server Handler Map, MessageHandler

### Community 716 - "Community 716"
Cohesion: 0.48
Nodes (7): Augmentation Worker, Auto-Labeling Worker, Qwen2.5-14B-Instruct, SeedVR2-7B Super Resolution, Augmentation and Auto-Labeling Flow, Auto-Labeling Flow, E2E Flow

### Community 717 - "Community 717"
Cohesion: 0.57
Nodes (7): claude-code agent, codex agent, NVSkills-Eval benchmark framework, NV-Generate-MR BENCHMARK, NV-Generate-MR-Brain BENCHMARK, NV-Generate-MR-Brain-Finetune BENCHMARK, NV-Generate-VAE-Finetune BENCHMARK

### Community 718 - "Community 718"
Cohesion: 0.29
Nodes (7): arXiv, HuggingFace API, HuggingFace Hub, HuggingFace paper publisher skill, ML experiment report template, Modern research paper template, HuggingFace API Tool Builder skill

### Community 719 - "Community 719"
Cohesion: 0.43
Nodes (7): AutoML Phase 1 Baseline, AutoML Phase 3 Refinement, DEFT Loop, Consolidated Pre-Flight Guide, Phase Handoffs Guide, Pitfalls and Quality Checks, AutoML + DEFT Pipeline Skill

### Community 720 - "Community 720"
Cohesion: 0.33
Nodes (7): Memory Fragmentation, expandable_segments EnvVar, use_megatron_fsdp Config, Megatron FSDP Card, Megatron FSDP Skill, Memory Tuning Card, Memory Tuning Skill

### Community 721 - "Community 721"
Cohesion: 0.33
Nodes (7): Utilities and Configuration Classes, EngineFileMonitor Utility, On-The-Fly Model Update, PerfMonitor Utility, SensorInfo Utility, SmartRecordConfig Utility, SourceConfig Utility

### Community 722 - "Community 722"
Cohesion: 0.29
Nodes (7): EffectLayer, Pick Driven Effects, read_array_attribute, read_attribute, Prim Pick Effects, Stage Attribute Reads, write_attribute

### Community 723 - "Community 723"
Cohesion: 0.29
Nodes (5): HuggingFace Hub, check_system_dependencies(), Check if required system packages are available., Run a command with error handling., run_command()

### Community 724 - "Community 724"
Cohesion: 0.29
Nodes (7): acceptable, n_fail, n_warn, verdict, required, type, preflight

### Community 725 - "Community 725"
Cohesion: 0.29
Nodes (7): already_optimized, optimization, structuring, description, enum, type, phase_recommendation

### Community 726 - "Community 726"
Cohesion: 0.29
Nodes (7): approved_full_sweep, masked_stage_spot_check, minimum_openability, targeted, structural_only, scope, enum

### Community 727 - "Community 727"
Cohesion: 0.29
Nodes (7): finetuned_ckpt_exists, oom, train_loss_finite, val_dice_per_epoch, required, type, output

### Community 728 - "Community 728"
Cohesion: 0.29
Nodes (7): full, no_op, structural_only, workflow_mode, description, enum, type

### Community 729 - "Community 729"
Cohesion: 0.29
Nodes (7): gates, inputs, outputs, operations, schemaVersion, stage, required

### Community 730 - "Community 730"
Cohesion: 0.29
Nodes (7): S0, S1, S2, S3, S4, severity, enum

### Community 731 - "Community 731"
Cohesion: 0.38
Nodes (7): warn, fail, pass, enum, verdict, enum, type

### Community 732 - "Community 732"
Cohesion: 0.48
Nodes (7): Reolink cmd=Snap CGI endpoint, Reolink RLC-811A camera, Reolink snapshot auth and EXIF findings, Reolink camera audio capture for BirdNET, Reolink camera focus control via HTTP API, Reolink HTTP snapshot API, Reolink native still capture and lockout behavior

### Community 733 - "Community 733"
Cohesion: 0.38
Nodes (5): _find(), _find_sample_dir(), Path, # NOTE: do NOT write `Path(os.environ.get("SAMPLE_DIR", "")) or _find_sample_dir, _read_env_key()

### Community 734 - "Community 734"
Cohesion: 0.33
Nodes (6): compare_gaps(), download_air05(), Compare solutions at different MIP gap tolerances.      Parameters     ---------, Download air05.mps from MIPLIB if not present., Solve an LP/MILP problem from an MPS file.      Parameters     ----------     fi, solve_mps()

### Community 735 - "Community 735"
Cohesion: 0.48
Nodes (6): alloc_in_loop(), nonzero_then_index(), ndarray, rebind_in_loop(), reshape_in_hot_loop(), stack_in_loop()

### Community 736 - "Community 736"
Cohesion: 0.43
Nodes (7): 1-Millisecond Task Granularity Rule, SM Utilization Layer, R101 Python Loop with Array Indexing, R102 np.vectorize, R103 Iterating Over ndarray, RR-loop Recipe, RR-where Recipe

### Community 738 - "Community 738"
Cohesion: 0.29
Nodes (7): type, properties, type, type, code, level, message

### Community 739 - "Community 739"
Cohesion: 0.29
Nodes (7): Graphify Exports Reference, Graphify Extraction Spec Reference, GitHub Clone and Cross-Repo Merge Reference, Commit Hook and CLAUDE.md Integration Reference, Query Path Explain Reference, Video Audio Transcription Reference, Incremental Update and Cluster-Only Reference

### Community 740 - "Community 740"
Cohesion: 0.57
Nodes (6): log(), main(), CompletedProcess, require(), resolve_region(), run()

### Community 741 - "Community 741"
Cohesion: 0.43
Nodes (6): _inspect_evals_tasks_root(), main(), _normalize_task(), Path, Return the installed inspect_evals package path if available., Allow lighteval-style `suite|task|shots` strings by keeping the task name.

### Community 742 - "Community 742"
Cohesion: 0.43
Nodes (6): estimate_training_time(), extract_model_size(), main(), parse_args(), Estimate training time in hours., Extract model size from name or return parsed value.

### Community 743 - "Community 743"
Cohesion: 0.48
Nodes (5): emit_error(), parse_readme(), process_id(), hf_model_card_frontmatter.sh script, show_help()

### Community 744 - "Community 744"
Cohesion: 0.52
Nodes (5): extract_papers(), get_model_papers(), get_trending_models(), hf_model_papers_auth.sh script, show_help()

### Community 745 - "Community 745"
Cohesion: 0.43
Nodes (6): estimate_training_time(), extract_model_params(), main(), parse_args(), Extract model size in millions of parameters from the model name., Estimate training time in hours for vision model training.

### Community 746 - "Community 746"
Cohesion: 0.43
Nodes (5): orin_uses_upstream_vllm(), run_bench_cmd(), run_one(), bench_vllm.sh script, usage()

### Community 747 - "Community 747"
Cohesion: 0.48
Nodes (6): build_metric_bundle_example(), _bundle(), _ensure_deterministic_hash_seed(), main(), Any, Return bundled JSON for one configured SDK metric.

### Community 748 - "Community 748"
Cohesion: 0.38
Nodes (4): Path, test_build_command_matches_upstream_entrypoint(), test_load_config_override_accepts_nested_keys(), test_summarize_image_reports_ct_hu_like()

### Community 749 - "Community 749"
Cohesion: 0.38
Nodes (4): Path, test_anatomy_size_condition_overwrites_requested_slot(), test_curated_lung_tumor_mask_fixture_uses_robust_size(), test_summarize_mask_reports_missing_expected_label()

### Community 750 - "Community 750"
Cohesion: 0.29
Nodes (7): properties, type, logs, stderr_tail, stdout_tail, type, type

### Community 751 - "Community 751"
Cohesion: 0.29
Nodes (7): properties, type, logs, stderr_tail, stdout_tail, type, type

### Community 752 - "Community 752"
Cohesion: 0.29
Nodes (7): properties, type, logs, stderr_tail, stdout_tail, type, type

### Community 753 - "Community 753"
Cohesion: 0.29
Nodes (7): properties, type, logs, stderr_tail, stdout_tail, type, type

### Community 754 - "Community 754"
Cohesion: 0.57
Nodes (6): _download(), _extract_case(), _human(), main(), Path, Extract a single member from the MSD09 tar and return its path.

### Community 755 - "Community 755"
Cohesion: 0.48
Nodes (6): ndarray, Nifti1Image, Path, test_mask_summary_accepts_requested_labels_and_matching_geometry(), test_mask_summary_flags_unrequested_labels_and_geometry_mismatch(), _write_nifti()

### Community 756 - "Community 756"
Cohesion: 0.33
Nodes (7): Decimate Meshes, De-duplicate Geometry, De-duplicate Hierarchies, Delete Prims, Find Occluded Meshes, Generate Normals, Mesh Cleanup

### Community 757 - "Community 757"
Cohesion: 0.29
Nodes (6): additionalProperties, description, $id, $schema, title, type

### Community 758 - "Community 758"
Cohesion: 0.29
Nodes (6): additionalProperties, $comment, description, $schema, title, type

### Community 759 - "Community 759"
Cohesion: 0.29
Nodes (7): items, type, type, items, type, generatedFiles, operations

### Community 760 - "Community 760"
Cohesion: 0.43
Nodes (5): ARM_SUBSCRIPTION_ID, is_correct_tenant(), login_to_azure(), az-sub-init.sh script, validate_azure_token()

### Community 761 - "Community 761"
Cohesion: 0.33
Nodes (6): find_videos(), generate_configs(), Deterministic hash stable across Python sessions (no PYTHONHASHSEED dependence)., Find all MP4 videos in input directory., Generate cosmos configs for each video and augmentation., _stable_hash()

### Community 762 - "Community 762"
Cohesion: 0.29
Nodes (6): HF_TOKEN, LLM_API_KEY, OPENAI_API_KEY, pl_augmented_worker.sh script, UV_PROJECT_ENVIRONMENT, VLM_API_KEY

### Community 763 - "Community 763"
Cohesion: 0.29
Nodes (6): HF_TOKEN, LLM_API_KEY, OPENAI_API_KEY, pl_original_worker.sh script, UV_PROJECT_ENVIRONMENT, VLM_API_KEY

### Community 765 - "Community 765"
Cohesion: 0.29
Nodes (7): evaluate, automl_default_parameters, core_module, path, popular, schema_action, spec_template

### Community 766 - "Community 766"
Cohesion: 0.29
Nodes (6): actions, automl_enabled, failures, model, network_arch, schema_version

### Community 767 - "Community 767"
Cohesion: 0.29
Nodes (7): cal_batch_size, cal_batches, tensorrt, calibration, max_batch_size, min_batch_size, opt_batch_size

### Community 768 - "Community 768"
Cohesion: 0.29
Nodes (7): cal_batch_size, cal_batches, tensorrt, calibration, max_batch_size, min_batch_size, opt_batch_size

### Community 769 - "Community 769"
Cohesion: 0.29
Nodes (7): cal_batch_size, cal_batches, tensorrt, calibration, max_batch_size, min_batch_size, opt_batch_size

### Community 770 - "Community 770"
Cohesion: 0.29
Nodes (7): cal_batch_size, cal_batches, tensorrt, calibration, max_batch_size, min_batch_size, opt_batch_size

### Community 771 - "Community 771"
Cohesion: 0.29
Nodes (7): transform, global_crops_scale, global_crops_size, local_crops_scale, local_crops_size, n_global_crops, n_local_crops

### Community 772 - "Community 772"
Cohesion: 0.29
Nodes (7): freeze_steps, max_decay_steps, val_base, val_final, val_start, warm_up_steps, last_layer_learning_rate

### Community 773 - "Community 773"
Cohesion: 0.29
Nodes (7): cal_batch_size, cal_batches, tensorrt, calibration, max_batch_size, min_batch_size, opt_batch_size

### Community 774 - "Community 774"
Cohesion: 0.29
Nodes (7): cal_batch_size, cal_batches, tensorrt, calibration, max_batch_size, min_batch_size, opt_batch_size

### Community 775 - "Community 775"
Cohesion: 0.29
Nodes (7): cal_batch_size, cal_batches, tensorrt, calibration, max_batch_size, min_batch_size, opt_batch_size

### Community 776 - "Community 776"
Cohesion: 0.29
Nodes (7): train, checkpoint_interval, gpu_ids, num_epochs, num_gpus, num_nodes, validation_interval

### Community 777 - "Community 777"
Cohesion: 0.29
Nodes (7): cal_batch_size, cal_batches, tensorrt, calibration, max_batch_size, min_batch_size, opt_batch_size

### Community 778 - "Community 778"
Cohesion: 0.57
Nodes (6): CUDA, main(), ref_softmax(), test_chunked(), test_online(), test_tma()

### Community 779 - "Community 779"
Cohesion: 0.29
Nodes (7): TRL Training Skill, Direct Preference Optimization (DPO), Group Relative Policy Optimization (GRPO), Reward Model Training, Reinforce Leave One Out (RLOO), Supervised Fine-Tuning (SFT), TRL CLI Commands

### Community 780 - "Community 780"
Cohesion: 0.67
Nodes (6): _apply_tile_grid(), update_batch_size.sh script, update_smartcity_gdino(), update_smartcity_rtdetr(), update_warehouse_2d(), update_warehouse_3d()

### Community 781 - "Community 781"
Cohesion: 0.40
Nodes (6): Arrow PIL Bug Fix, Prepare Data, Dataset Validation and Preparation Reference, Dataset Recommendations Reference, Dataset Recommendations Table, Dataset Source Handling Reference

### Community 782 - "Community 782"
Cohesion: 0.40
Nodes (6): Augmentation Pipeline Concept, Auto-labeling Pipeline Concept, Cookbook Scene Concept, Shared Cookbook Layout Concept, Cookbook File Inventory, VDA Tuning Guide

### Community 783 - "Community 783"
Cohesion: 0.33
Nodes (6): BaseRecipe, Recipe Development, NeMo AutoModel Recipe Development Benchmark, NeMo AutoModel Recipe Development Skill, Recipe Development Skill Card, YAML Config Anatomy

### Community 784 - "Community 784"
Cohesion: 0.33
Nodes (6): BM25 Retriever for Pipeline Queries, Requirement Extraction, Security And Limitations, Shell Injection Prevention, Requirement Extraction Question Bank, DeepStream Generate Pipeline Skill Card

### Community 785 - "Community 785"
Cohesion: 0.33
Nodes (6): bwmgr (bandwidth manager), cactmon (EMC activity monitor), EMC DVFS (Dynamic Voltage Frequency Scaling), EMC DVFS disable reference, osp-controller (QoS path controller, T26x only), T26x EMC DVFS multi-path isolation

### Community 786 - "Community 786"
Cohesion: 0.47
Nodes (6): Chain-of-Thought, NVIDIA TAO Toolkit, Video Reasoning Annotation Configuration Reference, Domain Adaptation, Video Reasoning Annotation Pipeline, Video Reasoning Annotation Pipeline

### Community 787 - "Community 787"
Cohesion: 0.53
Nodes (6): Iterative Performance Optimization, TileIR Compilation, cuTile Kernel Performance Optimization Skill, cuTile API Reference, cuTile Patterns Quick-Reference, IR Analysis Guide

### Community 788 - "Community 788"
Cohesion: 0.33
Nodes (6): Megatron Bridge, MoE Dispatcher Selection Skill Card, MoE Hardware Configs Skill Card, MoE Long Context Skill Card, MoE Optimization Workflow Skill Card, MoE VLM Training Skill Card

### Community 789 - "Community 789"
Cohesion: 0.40
Nodes (6): ONNX Export, TensorRT Engine Builder, Phase 4 Export and TensorRT Integration, Phase 5 Packaging and L0 Testing, Phase 6 Container Testing, PointPillars Export Template

### Community 790 - "Community 790"
Cohesion: 0.33
Nodes (6): Optical Inspection Skill, Siamese Network Defect Detection, TAO Deploy Optical Inspection, Optical Inspection Inference Template, Optical Inspection Deploy Guide, Optical Inspection Deploy Skill Info

### Community 791 - "Community 791"
Cohesion: 0.33
Nodes (6): DPHY-direct camera topology, GMSL SerDes chain, Camera overlay templates README, MAX9295 GMSL serializer, MAX96712 GMSL deserializer, TCA9546 I2C mux

### Community 792 - "Community 792"
Cohesion: 0.33
Nodes (6): Embedding Recipe Reference, Evaluation Reference, Nemotron Embed Recipe, Nemotron Rerank Recipe, Remote Execution Reference, Nemotron Retrieval Recipes Skill Card

### Community 793 - "Community 793"
Cohesion: 0.40
Nodes (3): GetSolutionCallback, IncumbentCallback, main()

### Community 794 - "Community 794"
Cohesion: 0.40
Nodes (6): Hub Push, Saving Vision Models to Hub, HF_TOKEN, hub_model_id, Image Processor, push_to_hub

### Community 795 - "Community 795"
Cohesion: 0.33
Nodes (6): Object Detection Training, Object Detection Training Notebook, Albumentations, CPPE-5 Dataset, DETR, mAP Metrics

### Community 796 - "Community 796"
Cohesion: 0.33
Nodes (6): Reliability Principles for Training Jobs, Atomic Self-Contained Scripts, Clear Error Context, Reliability Over Performance, Test Happy Path, Verify Before Use

### Community 797 - "Community 797"
Cohesion: 0.40
Nodes (6): duration Parameter, ZeroGPU Quota System, How ZeroGPU Duration and Quota Work, illegal duration Error, quota exceeded Error, @spaces.GPU Decorator

### Community 798 - "Community 798"
Cohesion: 0.33
Nodes (6): Grafana Dashboard, OpenTelemetry Tracing, Prometheus Metrics, Traceloop SDK, Zipkin Tracing, RAG Observability Configuration

### Community 799 - "Community 799"
Cohesion: 0.33
Nodes (6): affine, axcodes, path, shape, spacing, required

### Community 800 - "Community 800"
Cohesion: 0.33
Nodes (6): dependent_after, independent, shared_first, enum, type, dependency_group

### Community 801 - "Community 801"
Cohesion: 0.40
Nodes (6): oav, so, enum, preferred_provider, provider, enum

### Community 802 - "Community 802"
Cohesion: 0.33
Nodes (6): openedWith, identifier, rootLayer, stage, required, type

### Community 803 - "Community 803"
Cohesion: 0.33
Nodes (6): recommendedNextActions, composition, findings, schemaVersion, stage, required

### Community 805 - "Community 805"
Cohesion: 0.67
Nodes (5): aws_bin(), log(), main(), CompletedProcess, run_aws()

### Community 806 - "Community 806"
Cohesion: 0.53
Nodes (5): Path, test_build_command_uses_official_entrypoint(), test_load_request_resolves_mask_path(), test_summarize_mask_accepts_maisi_body_label(), test_validate_mask_summary_rejects_missing_body_label()

### Community 807 - "Community 807"
Cohesion: 0.53
Nodes (5): check_dependencies(), main(), Any, Path, _write_report()

### Community 808 - "Community 808"
Cohesion: 0.53
Nodes (5): check_dependencies(), main(), Any, Path, _write_report()

### Community 809 - "Community 809"
Cohesion: 0.53
Nodes (5): check_dependencies(), emit(), main(), Any, Path

### Community 810 - "Community 810"
Cohesion: 0.33
Nodes (5): additionalProperties, $comment, $schema, title, type

### Community 811 - "Community 811"
Cohesion: 0.33
Nodes (6): fail, pass, skipped, validate_usd_minimum, enum, type

### Community 812 - "Community 812"
Cohesion: 0.33
Nodes (6): properties, recommendedNextActions, schemaVersion, items, type, type

### Community 813 - "Community 813"
Cohesion: 0.33
Nodes (5): additionalProperties, $comment, $schema, title, type

### Community 814 - "Community 814"
Cohesion: 0.33
Nodes (6): enum, tier_assignments, pattern, additionalProperties, propertyNames, type

### Community 815 - "Community 815"
Cohesion: 0.40
Nodes (6): Azure PIM/RBAC, Azure Cluster Deployment Reference, GPU Operator, Terraform Deployment, Helmfile (GPU Operator), nvidia/gpu-operator Chart v25.10.0

### Community 816 - "Community 816"
Cohesion: 0.67
Nodes (5): day_stats(), has_day(), main(), _post(), _valid()

### Community 817 - "Community 817"
Cohesion: 0.53
Nodes (5): build_processor(), compute_metrics(), main(), make_transforms(), Compute mean IoU from logits + masks. Does not assume torchmetrics.

### Community 818 - "Community 818"
Cohesion: 0.33
Nodes (6): teacher_temperature, max_decay_steps, val_base, val_final, val_start, warm_up_steps

### Community 819 - "Community 819"
Cohesion: 0.33
Nodes (6): cal_batch_size, cal_batches, tensorrt, calibration, min_batch_size, opt_batch_size

### Community 820 - "Community 820"
Cohesion: 0.53
Nodes (5): main(), matmul_kernel(), Constant, run_matmul(), verify()

### Community 821 - "Community 821"
Cohesion: 0.33
Nodes (5): cutile_gemv_kernel(), Constant, Compute matrix-vector multiplication using tiled MMA with persistent scheduling., Compute reference matrix-vector multiplication using torch.matmul., reference_matmul()

### Community 822 - "Community 822"
Cohesion: 0.33
Nodes (6): Pooling Module, SentenceTransformer Class, Transformer Module, encode_document Method, encode_query Method, Embedding Prompts System

### Community 823 - "Community 823"
Cohesion: 0.53
Nodes (5): download_ngc(), downloaded_refs, resolve_local_role(), resolve_ngc_role(), fetch_resources.sh script

### Community 824 - "Community 824"
Cohesion: 0.50
Nodes (5): autoformat.sh Script, Linting Tools (ruff, black, isort, pylint, mypy), mcore-linting-and-formatting Evaluation Benchmark, mcore-linting-and-formatting Skill, mcore-linting-and-formatting Skill Card

### Community 825 - "Community 825"
Cohesion: 0.40
Nodes (5): AutoML Support Detection, list_tao_capabilities.py Script, list_tao_models.py Script, tao-list-capabilities, TAO Skill Bank Capabilities Discovery

### Community 826 - "Community 826"
Cohesion: 0.40
Nodes (5): MinIO Object Storage, ovstorage Library, S3 Object Storage, StorageManager Class, Cloud Assets Skill

### Community 827 - "Community 827"
Cohesion: 0.40
Nodes (5): Hierarchical Context Parallel, context_parallel_size Config, hierarchical_context_parallel_sizes Config, Hierarchical Context Parallel Card, Hierarchical Context Parallel Skill

### Community 828 - "Community 828"
Cohesion: 0.50
Nodes (5): Disaggregated Serving, NCCL Collective Transport, NIXL/UCX Transport, Interconnect Env Vars Reference, Dynamo Interconnect Check Skill

### Community 829 - "Community 829"
Cohesion: 0.40
Nodes (5): Image Classification Training Notebook, AutoModelForImageClassification, Food-101 Dataset, TrainingArguments, ViT

### Community 830 - "Community 830"
Cohesion: 0.40
Nodes (5): Bad Pixel Threshold Metrics, KITTI-Style Outlier Rate, End-Point-Error Metric, RMSE Metric, StereoDepthEvaluator

### Community 831 - "Community 831"
Cohesion: 0.40
Nodes (5): Filter Think Tokens, Nemotron Models, Reasoning Content Streaming, Self-Reflection, RAG Reasoning and Generation Configuration

### Community 832 - "Community 832"
Cohesion: 0.40
Nodes (5): centimeters, meters, millimeters, other, enum

### Community 833 - "Community 833"
Cohesion: 0.40
Nodes (5): flagged_pairs_only, per_target_or_sample, whole_stage, scope_policy, enum

### Community 834 - "Community 834"
Cohesion: 0.40
Nodes (5): ref_remap, restructure, enum, type, mode

### Community 835 - "Community 835"
Cohesion: 0.40
Nodes (5): uid, name, transfer_syntax, required, type

### Community 836 - "Community 836"
Cohesion: 0.40
Nodes (5): usedLayers, variants, required, payloads, references

### Community 837 - "Community 837"
Cohesion: 0.70
Nodes (4): block(), field(), main(), sh()

### Community 838 - "Community 838"
Cohesion: 0.50
Nodes (4): SentenceTransformer, build_parser(), main(), ArgumentParser

### Community 839 - "Community 839"
Cohesion: 0.50
Nodes (5): Legate Mapper, Task Dispatch Layer, R104 .item() / .tolist() in Hot Loops, R105 If/While Branching on Reduction, RR-sync Recipe

### Community 841 - "Community 841"
Cohesion: 0.40
Nodes (5): shape, items, maxItems, minItems, type

### Community 842 - "Community 842"
Cohesion: 0.40
Nodes (5): spacing, items, maxItems, minItems, type

### Community 843 - "Community 843"
Cohesion: 0.70
Nodes (4): choose_model(), main(), Any, request_json()

### Community 844 - "Community 844"
Cohesion: 0.60
Nodes (4): check_cuda(), main(), parse_args(), Check CUDA availability and exit if not available.

### Community 846 - "Community 846"
Cohesion: 0.70
Nodes (4): emit_error(), process_id(), hf_enrich_models.sh script, show_help()

### Community 847 - "Community 847"
Cohesion: 0.40
Nodes (5): Resolve pinmux/gpio DTSI paths under $L4T_DIR. Returns (pinmux, gpio, rc)., _resolve_commit_targets(), Path, Resolve the cloned pinmux or gpio DTSI for the carrier., resolve_dtsi()

### Community 849 - "Community 849"
Cohesion: 0.70
Nodes (4): do_request(), parse_timing(), bench_ollama.sh script, usage()

### Community 850 - "Community 850"
Cohesion: 0.40
Nodes (5): ^S[0-4]$, response_guidance, patternProperties, type, type

### Community 851 - "Community 851"
Cohesion: 0.50
Nodes (4): main(), Any, Path, _write_report()

### Community 852 - "Community 852"
Cohesion: 0.40
Nodes (4): $comment, operations, schema, source

### Community 853 - "Community 853"
Cohesion: 0.40
Nodes (5): type, properties, inputs, schemaVersion, type

### Community 854 - "Community 854"
Cohesion: 0.40
Nodes (5): additionalProperties, required, type, status, full_sweep

### Community 855 - "Community 855"
Cohesion: 0.40
Nodes (5): $comment, type, null, string, backing_op

### Community 856 - "Community 856"
Cohesion: 0.50
Nodes (4): main(), Sage/Waggle Edge Plugin Template Minimal plugin that reads a sensor and publishe, Replace with actual sensor reading logic., read_sensor()

### Community 857 - "Community 857"
Cohesion: 0.70
Nodes (4): main(), parse_args(), Namespace, resolve_dest()

### Community 858 - "Community 858"
Cohesion: 0.40
Nodes (5): inference, core_module, path, schema_action, spec_template

### Community 859 - "Community 859"
Cohesion: 0.40
Nodes (5): FastFoundationStereo Skill Card, Important Parameters, Setup and Run Guide, Typical Spec Overrides, DepthNet Fast Stereo Deploy

### Community 860 - "Community 860"
Cohesion: 0.40
Nodes (5): lr_backbone, lr_linear_proj_mult, momentum, weight_decay, optim

### Community 861 - "Community 861"
Cohesion: 0.40
Nodes (5): train, core_module, path, schema_action, spec_template

### Community 862 - "Community 862"
Cohesion: 0.40
Nodes (5): backbone_multiplier, layer_decay, momentum, weight_decay, optim

### Community 863 - "Community 863"
Cohesion: 0.40
Nodes (5): lr_backbone, lr_linear_proj_mult, momentum, weight_decay, optim

### Community 864 - "Community 864"
Cohesion: 0.40
Nodes (5): drop_path_rate, img_size, num_register_tokens, patch_size, backbone

### Community 865 - "Community 865"
Cohesion: 0.40
Nodes (5): OCRNet Deploy Experiment Spec Template, OCRNet Deploy Guide, OCRNet Deploy Skill Info, OCRNet Skill, OCRNet Skill Card

### Community 866 - "Community 866"
Cohesion: 0.50
Nodes (3): CUDA, main(), verify()

### Community 867 - "Community 867"
Cohesion: 0.40
Nodes (5): Transformers.js Caching Reference, Browser Cache API, Filesystem Cache, Environment Configuration Reference, env Object Configuration

### Community 868 - "Community 868"
Cohesion: 0.60
Nodes (3): _check(), ensure_encoder_deps(), update_output_sink.sh script

### Community 869 - "Community 869"
Cohesion: 0.70
Nodes (4): _dump(), _hdr(), redact_secrets(), write_deployment_log.sh script

### Community 870 - "Community 870"
Cohesion: 0.60
Nodes (4): main(), normalize(), Path, Strip dangling *optional* depends_on entries in resolved compose at *path*.

### Community 871 - "Community 871"
Cohesion: 0.50
Nodes (4): Adapter Pattern, OvWidgets Application, RTX Viewport, OvWidgets Full Editor Shell

### Community 872 - "Community 872"
Cohesion: 0.50
Nodes (4): AppStreamer, DirectConfig, Streaming Client, WebRTC Streaming

### Community 873 - "Community 873"
Cohesion: 0.50
Nodes (4): Audio Ingestion, Nemotron Parse, Ingestion Configuration, Document Ingestion

### Community 874 - "Community 874"
Cohesion: 0.50
Nodes (4): Claude Code MCP Configuration, Fern Documentation, NemoClaw Docs MCP Server, NemoClaw User Guide Skill

### Community 875 - "Community 875"
Cohesion: 0.50
Nodes (4): Terraform Modules Documentation, Azure Resource Providers List, Microsoft Physical AI Toolchain, Terraform Modules

### Community 876 - "Community 876"
Cohesion: 0.50
Nodes (4): DAFT Dataset Validation, NVSkills-Eval Benchmark: tao-validate-dataset-format, tao-validate-dataset-format Skill, tao-validate-dataset-format Skill Card

### Community 877 - "Community 877"
Cohesion: 0.83
Nodes (4): decimateMeshes Operation, deduplicateGeometry Operation, Units and Tolerances Conversion Reference, Units and Tolerances Conversion Formula

### Community 878 - "Community 878"
Cohesion: 0.50
Nodes (4): Documentation Conventions, Google Style Docstrings, NeMo RL Documentation Skill, Sphinx Documentation

### Community 879 - "Community 879"
Cohesion: 0.50
Nodes (4): EAGLE-3 Speculative Decoding, jetson-speculative-decoding Skill, jetson-speculative-decoding Skill Card, Speculative Decoding

### Community 880 - "Community 880"
Cohesion: 0.50
Nodes (4): Floating Panel Projection, Native Prim Queries, Prim Info Panel, Prim Info Display

### Community 881 - "Community 881"
Cohesion: 0.50
Nodes (4): kernels-community, ZeroGPU CUDA Dependencies, flash-attn, CUDA Wheel Tags

### Community 882 - "Community 882"
Cohesion: 0.50
Nodes (4): ZeroGPU Concurrency Safety, Concurrency Safety Rules, No Mutable Global State, Unique File Paths per Invocation

### Community 883 - "Community 883"
Cohesion: 0.50
Nodes (4): How ZeroGPU Works Mechanism, Disk Offload Mechanism, GPU Worker Process, Main Web Process

### Community 884 - "Community 884"
Cohesion: 1.00
Nodes (4): NVIDIA Asset Validator, omni-asset-validate, omni-asset-validate-geometry, omni-asset-validate-physics

### Community 885 - "Community 885"
Cohesion: 0.50
Nodes (4): NVSkills-Eval Evaluation Framework, tao-train-pose-classification Evaluation Report, tao-train-reid Evaluation Report, tao-train-rtdetr Evaluation Report

### Community 886 - "Community 886"
Cohesion: 0.50
Nodes (4): Phase 0 Model Validation, Phase 1-3 Training Pipeline, Phase 4-6 Hub Push, Detailed Workflow Map

### Community 887 - "Community 887"
Cohesion: 0.67
Nodes (3): embed_images(), main(), Replace <img src="file.png"> with base64-embedded data URIs.

### Community 889 - "Community 889"
Cohesion: 0.67
Nodes (3): main(), Path, render_one()

### Community 890 - "Community 890"
Cohesion: 0.50
Nodes (3): $schema, title, type

### Community 891 - "Community 891"
Cohesion: 0.50
Nodes (4): _GenerateCtx, Resolved inputs for the `generate` subcommand., Write the 3 DTSI files. Returns dict of {label: path}., _write_generated_dtsis()

### Community 894 - "Community 894"
Cohesion: 0.50
Nodes (4): items, minItems, type, examples_unsafe

### Community 895 - "Community 895"
Cohesion: 0.50
Nodes (3): additionalProperties, $schema, type

### Community 896 - "Community 896"
Cohesion: 0.50
Nodes (3): additionalProperties, $schema, type

### Community 897 - "Community 897"
Cohesion: 0.50
Nodes (4): type, selected_calls, items, type

### Community 898 - "Community 898"
Cohesion: 0.50
Nodes (3): $schema, title, type

### Community 899 - "Community 899"
Cohesion: 0.50
Nodes (4): description, minimum, type, mesh_count

### Community 900 - "Community 900"
Cohesion: 0.50
Nodes (4): additionalProperties, required, concept, items

### Community 901 - "Community 901"
Cohesion: 0.50
Nodes (4): Output Rendering and Download, Preview Grid (Path B), Output Retrieval Reference, anomaly/ Tree Output

### Community 903 - "Community 903"
Cohesion: 0.50
Nodes (4): gpsd GPS daemon, Node SSH access routes and GPS probing, Thor nodes, WSN nodes

### Community 904 - "Community 904"
Cohesion: 0.83
Nodes (3): main(), query(), short()

### Community 906 - "Community 906"
Cohesion: 0.83
Nodes (3): main(), Path, validate()

### Community 907 - "Community 907"
Cohesion: 0.83
Nodes (3): colorize(), main(), palette()

### Community 908 - "Community 908"
Cohesion: 0.50
Nodes (4): backbone_multiplier, momentum, weight_decay, optim

### Community 909 - "Community 909"
Cohesion: 0.50
Nodes (4): tensorrt, max_batch_size, min_batch_size, opt_batch_size

### Community 910 - "Community 910"
Cohesion: 0.67
Nodes (3): CUDA, main(), verify()

### Community 912 - "Community 912"
Cohesion: 0.50
Nodes (4): DINO Detailed Guide Map, DINO Actions And Error Patterns, DINO AutoML And SDK Internals, DINO Data And Specs

### Community 913 - "Community 913"
Cohesion: 0.67
Nodes (3): Build Order For Agents, ovui Local Validation And Build Order, Validation Checklist

### Community 914 - "Community 914"
Cohesion: 0.67
Nodes (3): Camera Alignment Data JSON, Camera Layout PNG Image, Common Calibration Steps Reference

### Community 915 - "Community 915"
Cohesion: 0.67
Nodes (3): Capability Based Routing, Intent Based Routing, Omniverse Realtime Viewer Routing

### Community 916 - "Community 916"
Cohesion: 0.67
Nodes (3): cuTile Tile-Based Programming Model, Kernel Fusion, Tile Size Power-of-2 Restriction

### Community 917 - "Community 917"
Cohesion: 1.00
Nodes (3): LoRA (Low-Rank Adaptation), Unsloth, Unsloth Integration Guide

### Community 918 - "Community 918"
Cohesion: 1.00
Nodes (3): Multi-Objective Optimization, Pareto Frontier, cuOpt Multi-Objective Exploration Skill Card

### Community 919 - "Community 919"
Cohesion: 0.67
Nodes (3): NemoClaw, NVIDIA, NemoClaw User Guide Skill Card

### Community 920 - "Community 920"
Cohesion: 0.67
Nodes (3): Vehicle Routing Problem, cuOpt Server API Runable Assets, cuOpt REST Server Skill

### Community 921 - "Community 921"
Cohesion: 0.67
Nodes (3): Content Safety, NeMo Guardrails, NeMo Guardrails Configuration

### Community 922 - "Community 922"
Cohesion: 0.67
Nodes (3): drop_caches Memory Reclamation, Jetson Memory Audit Workflow, Jetson Memory Optimization Workflow

### Community 923 - "Community 923"
Cohesion: 0.67
Nodes (3): monai, compute_loss Function, DiceCELoss

### Community 924 - "Community 924"
Cohesion: 0.67
Nodes (3): Using timm models with HF Trainer, timm Library, TimmWrapper

### Community 925 - "Community 925"
Cohesion: 0.67
Nodes (3): Knowledge Graph, add-watch Reference, graphify Skill

### Community 926 - "Community 926"
Cohesion: 0.67
Nodes (3): Least Squares Optimization, Portfolio Variance Optimization, QP Python API Examples

### Community 927 - "Community 927"
Cohesion: 0.67
Nodes (3): Local App Package, Project Skeleton, ovui Local Project Structure

### Community 928 - "Community 928"
Cohesion: 0.67
Nodes (3): material-agent-client, physics-agent-client, identify-asset-context

### Community 929 - "Community 929"
Cohesion: 0.67
Nodes (3): Model Rejection Criteria, Model Discovery and Validation Reference, Task Type to AutoModel Mapping

### Community 930 - "Community 930"
Cohesion: 1.00
Nodes (3): NVIDIA Base Image, --runtime=nvidia, Docker Build and Deploy for Sage Edge Plugins

### Community 931 - "Community 931"
Cohesion: 0.67
Nodes (3): NV-Reason-CXR-3B, NV-Reason-CXR Skill, NV-Reason-CXR Manifest

### Community 932 - "Community 932"
Cohesion: 1.00
Nodes (3): Camera Auto-Select Skill, Camera Controls Skill, Camera Picker Skill

### Community 933 - "Community 933"
Cohesion: 0.67
Nodes (3): NVSkills-Eval Evaluation Framework, Physical AI Neural Reconstruction, Neural Reconstruction Evaluation Benchmark

### Community 934 - "Community 934"
Cohesion: 0.67
Nodes (3): MCP Server Configuration, ReAct Agent, MCP Server

### Community 935 - "Community 935"
Cohesion: 0.67
Nodes (3): SceneManager, Streaming Interaction Features, StageQueries

### Community 936 - "Community 936"
Cohesion: 0.67
Nodes (3): SegFormer, SegFormer Deploy Skill Info, SegFormer Skill Card

### Community 937 - "Community 937"
Cohesion: 0.67
Nodes (3): Packaging Sage/Hermes knowledge bundle, Sage documentation index, sagecontinuum GitHub org repo index

### Community 938 - "Community 938"
Cohesion: 0.67
Nodes (3): PDP Basic Reference Model, Routing Assets Overview, VRP Basic Reference Model

### Community 944 - "Community 944"
Cohesion: 1.00
Nodes (3): HuggingFace CLI Skill, HuggingFace MCP Server Skill, HuggingFace Memory Estimator Skill

### Community 945 - "Community 945"
Cohesion: 0.67
Nodes (3): Holoscan Conda Install Benchmark, Holoscan Conda Installation Skill, Holoscan Conda Install Skill Card

### Community 956 - "Community 956"
Cohesion: 0.67
Nodes (3): items, type, errors

### Community 957 - "Community 957"
Cohesion: 0.67
Nodes (3): warnings, items, type

### Community 958 - "Community 958"
Cohesion: 0.67
Nodes (3): items, type, generated_files

### Community 959 - "Community 959"
Cohesion: 0.67
Nodes (3): warnings, items, type

### Community 960 - "Community 960"
Cohesion: 0.67
Nodes (3): size_bytes, minimum, type

### Community 961 - "Community 961"
Cohesion: 0.67
Nodes (3): weight_hints, description, type

### Community 962 - "Community 962"
Cohesion: 0.67
Nodes (3): sublayers, items, type

### Community 963 - "Community 963"
Cohesion: 0.67
Nodes (3): unresolvedAssetPaths, items, type

### Community 964 - "Community 964"
Cohesion: 0.67
Nodes (3): variants, items, type

### Community 983 - "Community 983"
Cohesion: 0.67
Nodes (3): parse_args(), Namespace, Parse command-line arguments.

### Community 984 - "Community 984"
Cohesion: 0.67
Nodes (3): lr, args, optimizer

### Community 986 - "Community 986"
Cohesion: 0.67
Nodes (3): VSS Ask Video Benchmark, VSS Ask Video Skill, VSS Ask Video Skill Card

## Ambiguous Edges - Review These
- `USD Validation Runner` → `Automated Optical Inspection (AOI)`  [AMBIGUOUS]
  skills/physical-ai-defect-image-generation/SKILL.md · relation: semantically_similar_to

## Knowledge Gaps
- **6052 isolated node(s):** `benchmark-ds.sh script`, `ds-kitti-dump.sh script`, `ds-perf-run.sh script`, `ds-single-stream.sh script`, `ds-sweep.sh script` (+6047 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **534 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What is the exact relationship between `USD Validation Runner` and `Automated Optical Inspection (AOI)`?**
  _Edge tagged AMBIGUOUS (relation: semantically_similar_to) - confidence is low._
- **Why does `vss-manage-video-io-storage Skill` connect `Community 51` to `Community 292`, `Community 213`?**
  _High betweenness centrality (0.001) - this node is a cross-community bridge._
- **Why does `AutoML / Hyperparameter Optimization` connect `Community 94` to `Community 195`, `Community 136`, `Community 409`, `Community 379`, `Community 414`?**
  _High betweenness centrality (0.001) - this node is a cross-community bridge._
- **What connects `benchmark-ds.sh script`, `ds-kitti-dump.sh script`, `ds-perf-run.sh script` to the rest of the system?**
  _6052 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `TAO Dataset Spec` be split into smaller, more focused modules?**
  _Cohesion score 0.06427573358174196 - nodes in this community are weakly interconnected._
- **Should `TAO Manifest Actions` be split into smaller, more focused modules?**
  _Cohesion score 0.05164797825348284 - nodes in this community are weakly interconnected._
- **Should `TAO Augmentation Config` be split into smaller, more focused modules?**
  _Cohesion score 0.05013477088948787 - nodes in this community are weakly interconnected._