# Graph Report - $HOME/.hermes/profiles/sage  (2026-08-07)

## Corpus Check
- cluster-only mode — file stats not available

## Summary
- 410 nodes · 323 edges · 147 communities (40 shown, 107 thin omitted)
- Extraction: 92% EXTRACTED · 8% INFERRED · 0% AMBIGUOUS · INFERRED: 25 edges (avg confidence: 0.84)
- Token cost: 3,296 input · 1,805 output

## Graph Freshness
- Built from commit: `868d0393`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- Video Analysis & Deployment
- LLM Parallelism & Optimization
- Jetson BSP Customization
- Jetson Platform Configuration
- Computer Vision Models
- TAO AutoML Pipelines
- Physical AI Infrastructure
- Clinical ASR & Riva
- Holoscan Installation
- Jetson Diagnostics
- TAO Execution Platforms
- Triton & Kernel Orchestration
- Graphify & Documentation
- Waggle Design & Cache
- cuOpt Numerical Optimization
- Vision Training Utilities
- SageMaker Deployment
- Medical Brain Imaging
- TAO Training Workflows
- Distributed Training Managers
- Model Calibration
- RAG Evaluation
- TAO Inference Services
- Dynamo Routing & Troubleshooting
- Hugging Face Spaces
- Jetson LLM Optimization
- Preflight & Data Augmentation
- Waggle Platform SDK
- Skill Card Generation
- Distributed Setup Context
- AIQ Research & Deployment
- DeepStream Pipeline Tools
- Earth2Studio Installation
- HSB Application Setup
- HF Model Training
- Jetson LLM Packaging
- Research & Session Memory
- Medical Reasoning & Skills
- Model Infrastructure Application
- Model Mixins
- AIQ Deployment Skills
- cuOpt Installation
- Multi-Objective Optimization
- cuPyNumeric Data I/O
- cuPyNumeric Installation
- Hugging Face Publishing
- Jetson Memory Tuning
- CT RFlow Generation
- MR Image Generation
- CT Segmentation
- CT Segmentation Finetuning
- CTMR Segmentation
- Omniverse Simulation
- TAO Gap Analysis
- TAO Model Finetuning
- Cosmos Model Tuning
- TAO AutoML Launch
- TAO Image Mining
- TAO Dataset Validation
- DDP Configuration
- FSDP2 Configuration
- Megatron FSDP Configuration
- MoE Parallelism Config
- Distributed Initialization
- MoE Configuration
- CUDA Toolkit
- NVIDIA Driver
- Distributed Section Parsing
- cuDF Accelerated Computing
- CUDA-Q Onboarding
- cuFOLIO Skill
- cuOpt Routing API
- DALI Dynamic Mode
- Data Designer
- DeepStream Development
- DeepStream SOP Inference
- DICOM Metadata Extraction
- DICOM Preflight
- DICOM Volume Conversion
- Earth2Studio Data Sources
- Earth2Studio Diagnostics
- Earth2Studio Prognostics
- Earth2Studio Data Fetch
- Graphify Skill
- HF Hub CLI
- HF MCP Server
- HF Memory Estimation
- Holoscan Conda Setup
- HSB Flashing
- HF Model Finder
- HF Dataset Viewer
- HF Local Models
- HF API Builder
- HF ZeroGPU Skill
- Jetson Memory Audit
- Jetson BSP Info
- Jetson Device Info
- NeMo RL Launch
- MCore Issue Tracking
- MCore Linting Formatting
- MCore Slurm Execution
- MCore PR Management
- MCore Testing
- Multi-Node Slurm
- MoE Communication Overlap
- MoE Dispatcher Selection
- MoE Hardware Config
- MoE Long-Context Training
- MoE Training Optimization
- MoE VLM Training
- Recipe Recommender
- System Resiliency
- NeMo Retriever
- Documentation Conventions
- NeMo CLAW User Guide
- Nemotron Customization
- Nemotron Policy Generation
- Nemotron Retrieval Recipes
- Nemotron Speech
- Omniverse USD Tuning
- Cosmos Worker Scripts
- Config Generation
- Osmo Barrier Logic
- Augmented Worker Scripts
- Original Worker Scripts
- Side-by-Side Rendering
- Artifact Staging
- PhysicsNeMo Discoverability
- VLM Gap Analysis
- TAO Dataset Conversion
- TAO Capabilities
- TAO Model Porting
- RT-DETR Model
- TileGym cuTile Kernels
- TileGym Julia Conversion
- TileGym Triton Conversion
- cuTile Autotuning
- cuTile Performance Optimization
- cuTile Transformers Integration
- Sentence Transformers Training
- Transformers JS
- TRL Training
- Model Architecture Mapping

## God Nodes (most connected - your core abstractions)
1. `tao-run-automl` - 16 edges
2. `vss-deploy-profile` - 14 edges
3. `vss-summarize-video` - 12 edges
4. `Physical AI Infrastructure Setup And Resilient Scaling` - 9 edges
5. `tao-run-automl` - 9 edges
6. `jetson-init-image` - 8 edges
7. `holoscan-setup` - 6 edges
8. `Build BSP Source Skill` - 6 edges
9. `jetson-promote-image` - 6 edges
10. `jetson-init-source` - 6 edges

## Surprising Connections (you probably didn't know these)
- `Sequence Packing` --references--> `prepare_padded_or_packed_sequence_batch`  [EXTRACTED]
  skills/nemo-mbridge-perf-sequence-packing/SKILL.md → src/megatron/bridge/data/sequence_batching.py
- `Sequence Packing` --references--> `gpt_step`  [EXTRACTED]
  skills/nemo-mbridge-perf-sequence-packing/SKILL.md → src/megatron/bridge/training/gpt_step.py
- `jetson-init-target` --references--> `Platform Template`  [EXTRACTED]
  skills/jetson-init-target/SKILL.md → references/platform_template.yaml
- `jetson-link-docs` --references--> `Platform Template`  [EXTRACTED]
  skills/jetson-link-docs/SKILL.md → references/platform_template.yaml
- `apply_model_infrastructure` --calls--> `make_cp_batch_and_ctx`  [INFERRED]
  _transformers/infrastructure.py → components/distributed/cp_utils.py

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Sage Platform Redesign** — docs_infra_problems, docs_local_cache, docs_pywaggle2 [EXTRACTED 1.00]
- **AI-Q Blueprint Ecosystem** — skills_aiq_deploy, skills_aiq_research [EXTRACTED 1.00]
- **AutoMagicCalib Calibration Workflow** — skills_amc_setup_calibration_stack_skill, skills_amc_run_sample_calibration_skill, skills_amc_run_video_calibration_skill [EXTRACTED 1.00]
- **cuOpt Development and Usage** — skills_cuopt_developer_skill, skills_cuopt_install_skill, skills_cuopt_multi_objective_exploration_skill, skills_cuopt_numerical_optimization_api_skill [INFERRED 0.90]
- **cuOpt Numerical Optimization Suite** — skills_cuopt_numerical_optimization_api, skills_cuopt_numerical_optimization_formulation, skills_cuopt_server_api_python [EXTRACTED 1.00]
- **cuPyNumeric Ecosystem** — skills_cupynumeric_hdf5, skills_cupynumeric_install, skills_cupynumeric_migration_readiness, skills_cupynumeric_parallel_data_load [EXTRACTED 1.00]
- **DeepStream SDK Tooling** — skills_deepstream_dev, skills_deepstream_generate_pipeline, skills_deepstream_import_vision_model, skills_deepstream_profile_pipeline, skills_deepstream_sop [INFERRED 0.90]
- **DICOM Processing Pipeline** — skills_dicom_metadata_extract, skills_dicom_series_preflight, skills_dicom_series_to_volume [INFERRED 0.90]
- **Clinical ASR Flywheel** — skills_digital_health_clinical_asr_build, skills_digital_health_clinical_asr_eval [EXTRACTED 1.00]
- **Clinical ASR Flywheel** — skills_digital_health_clinical_asr_setup, skills_digital_health_clinical_asr_build, skills_digital_health_clinical_asr_eval, skills_digital_health_clinical_asr_finetune [EXTRACTED 1.00]
- **Dynamo Deployment Workflow** — skills_dynamo_recipe_runner, skills_dynamo_router_starter, skills_dynamo_interconnect_check, skills_dynamo_troubleshoot [INFERRED 0.90]
- **Earth2Studio Model Creation** — skills_earth2studio_create_datasource, skills_earth2studio_create_diagnostic, skills_earth2studio_create_prognostic [INFERRED 0.90]
- **SageMaker Deployment Workflow** — skills_hf_cloud_sagemaker_deployment_planner_skill, skills_hf_cloud_aws_context_discovery_skill, skills_hf_cloud_python_env_setup_skill, skills_hf_cloud_sagemaker_iam_preflight_skill, skills_hf_cloud_serving_image_selection_skill, skills_hf_cloud_sagemaker_production_defaults_skill [EXTRACTED 1.00]
- **Earth2Studio Toolset** — skills_earth2studio_deterministic_forecast_skill, skills_earth2studio_discover_skill, skills_earth2studio_install_skill [INFERRED 0.90]
- **Holoscan SDK Installation Suite** — skills_holoscan_setup, skills_holoscan_install_container, skills_holoscan_install_debian, skills_holoscan_install_wheel, skills_holoscan_install_source [EXTRACTED 1.00]
- **Holoscan Sensor Bridge Management** — skills_hsb_setup, skills_hsb_app, skills_hsb_flash, skills_hsb_test [INFERRED 0.90]
- **HF Training & Monitoring Flow** — skills_huggingface_llm_trainer, skills_huggingface_vision_trainer, skills_huggingface_trackio [EXTRACTED 1.00]
- **HF Space Creation & UI Flow** — skills_huggingface_spaces, skills_huggingface_gradio, skills_huggingface_lora_space_builder [EXTRACTED 1.00]
- **Jetson BSP Customization Workflow** — skills_jetson_init_source_skill, skills_jetson_derive_carrier_skill, skills_jetson_build_source_skill, skills_jetson_promote_image_skill [EXTRACTED 1.00]
- **Jetson Hardware Customization Skills** — skills_jetson_customize_camera_skill, skills_jetson_customize_mgbe_skill, skills_jetson_customize_pcie_skill, skills_jetson_customize_pinmux_skill [INFERRED 0.90]
- **Jetson Power and Thermal Tuning** — skills_jetson_customize_clocks_skill, skills_jetson_customize_fan_skill, skills_jetson_customize_nvpmodel_skill [INFERRED 0.90]
- **BSP Setup Flow** — skills_jetson_download_bsp, skills_jetson_init_image, skills_jetson_init_source, skills_jetson_link_docs [INFERRED 0.90]
- **BSP I/O Customization** — skills_jetson_customize_pinmux, skills_jetson_customize_uphy, skills_jetson_customize_usb [INFERRED 0.90]
- **Memory Optimization Flow** — skills_jetson_diagnostic, skills_jetson_headless_mode, skills_jetson_inference_mem_tune [INFERRED 0.80]
- **BSP Setup Sequence** — skills_jetson_init_target, skills_jetson_init_image, skills_jetson_init_source, skills_jetson_link_docs [EXTRACTED 1.00]
- **LLM Deployment and Benchmarking** — skills_jetson_llm_serve, skills_jetson_llm_benchmark, skills_jetson_package [INFERRED 0.90]
- **Jetson Deploy Pipeline** — skills_jetson_promote_image_skill, skills_jetson_flash_image_skill, skills_jetson_validate_image_skill [EXTRACTED 1.00]
- **Jetson Setup Flow** — skills_jetson_quick_start_skill, skills_jetson_set_target_skill, skills_jetson_init_target_skill, skills_jetson_download_bsp_skill, skills_jetson_init_image_skill, skills_jetson_init_source_skill [EXTRACTED 1.00]
- **Distributed Infrastructure Initialization Flow** — components_distributed_init_utils_initialize_distributed, recipes_dist_utils_parse_distributed_section, components_distributed_config_distributedsetup, transformers_infrastructure_instantiate_infrastructure, transformers_infrastructure_apply_model_infrastructure [EXTRACTED 1.00]
- **Distributed Training Strategies** — components_distributed_config_fsdp2config, components_distributed_config_megatronfsdpconfig, components_distributed_config_ddpconfig [EXTRACTED 1.00]
- **GPU Memory Reduction Strategies** — skills_nemo_mbridge_perf_memory_tuning_skill, skills_nemo_mbridge_perf_activation_recompute_skill, skills_nemo_mbridge_perf_cpu_offloading_skill, skills_nemo_mbridge_perf_megatron_fsdp_skill [INFERRED 0.90]
- **MoE Performance Optimization** — skills_nemo_mbridge_perf_expert_parallel_overlap_skill, skills_nemo_mbridge_perf_moe_comm_overlap_skill, skills_nemo_mbridge_perf_moe_dispatcher_selection_skill, skills_nemo_mbridge_perf_moe_hardware_configs_skill [INFERRED 0.90]
- **MoE Performance Tuning Suite** — skills_nemo_mbridge_perf_moe_long_context, skills_nemo_mbridge_perf_moe_optimization_workflow, skills_nemo_mbridge_perf_moe_vlm_training [INFERRED 0.90]
- **NeMo-RL Research Workflow** — skills_nemo_rl_auto_research, skills_nemo_rl_session_memory, skills_nemo_rl_brev_etiquette [EXTRACTED 1.00]
- **NV-Generate-CTMR Synthesis Suite** — skills_nv_generate_ct_rflow, skills_nv_generate_mr, skills_nv_generate_mr_brain, skills_nv_generate_mr_brain_finetune, skills_nv_generate_vae_finetune [INFERRED 0.90]
- **MedTech Segmentation Suite** — skills_nv_segment_ct, skills_nv_segment_ct_finetune, skills_nv_segment_ctmr [INFERRED 0.90]
- **Omniverse USD Workflow** — skills_omniverse_cad_to_simready, skills_omniverse_realtime_viewer, skills_omniverse_usd_performance_tuning [INFERRED 0.90]
- **Physical AI Infrastructure Stack** — infra_cluster_azure, infra_cluster_microk8s, infra_osmo_cli, infra_nim_operator, infra_nvcf, infra_azure_foundry [EXTRACTED 1.00]
- **Synthetic Data Generation Workloads** — skills_physical_ai_defect_image_generation, skills_physical_ai_people_attribute_search, skills_physical_ai_video_data_augmentation [INFERRED 0.90]
- **NVIDIA RAG Blueprint Tooling** — skills_rag_blueprint_skill, skills_rag_eval_skill, skills_rag_perf_skill [INFERRED 0.90]
- **TAO Gap Analysis Tools** — skills_tao_analyze_gaps_visual_changenet, skills_tao_analyze_gaps_vlm_bcq [INFERRED 0.90]
- **Cosmos Model Family** — skills_tao_finetune_cosmos_embed, skills_tao_finetune_cosmos_reason [EXTRACTED 1.00]
- **VCN AOI SDA Pipeline** — skills_tao_route_visual_changenet_samples, skills_tao_mine_aoi_images [EXTRACTED 1.00]
- **VLM-based Annotation Skills** — skills_tao_generate_image_grounding, skills_tao_generate_referring_expressions, skills_tao_generate_video_reasoning_annotations [INFERRED 0.90]
- **TAO Execution Platforms** — skills_tao_run_on_brev_skill, skills_tao_run_on_kubernetes_skill, skills_tao_run_on_local_docker_skill, skills_tao_run_on_slurm_skill [INFERRED 1.00]
- **AOI Training Pipeline Flow** — skills_tao_run_automl_skill, skills_tao_run_deft_aoi_skill, skills_tao_run_automl_deft_pipeline_skill [EXTRACTED 1.00]
- **TAO GPU Runtime Stack** — nvidia_driver_580, cuda_toolkit_13_0, nvidia_container_toolkit_1_19_0 [EXTRACTED 1.00]
- **AutoML Enabled Models** — skills_tao_train_action_recognition_skill, skills_tao_train_bevfusion_skill, skills_tao_train_centerpose_skill, skills_tao_train_deformable_detr_skill, skills_tao_train_depth_anything_v2_skill, skills_tao_train_dino_skill, skills_tao_train_fast_foundation_stereo_skill, skills_tao_train_foundation_stereo_skill [EXTRACTED 1.00]
- **AutoML Enabled Models** — skills_tao_train_grounding_dino_grounding_dino, skills_tao_train_image_classification_classification_pyt, skills_tao_train_mask_auto_encoder_mae, skills_tao_train_mask_auto_label_mal, skills_tao_train_mask_grounding_dino_mask_grounding_dino, skills_tao_train_mask2former_mask2former, skills_tao_train_metric_learning_recognition_ml_recog, skills_tao_train_nvdinov2_nvdinov2, skills_tao_train_nvpanoptix3d_nvpanoptix3d [EXTRACTED 1.00]
- **Segmentation Models** — skills_tao_train_mask_auto_label_mal, skills_tao_train_mask_grounding_dino_mask_grounding_dino, skills_tao_train_mask2former_mask2former, skills_tao_train_nvpanoptix3d_nvpanoptix3d [EXTRACTED 1.00]
- **Self-Supervised Learning Models** — skills_tao_train_mask_auto_encoder_mae, skills_tao_train_nvdinov2_nvdinov2 [EXTRACTED 1.00]
- **AutoML Enabled Models** — skills_tao_train_ocdnet_ocdnet, skills_tao_train_ocrnet_ocrnet, skills_tao_train_oneformer_oneformer, skills_tao_train_optical_inspection_optical_inspection, skills_tao_train_pointpillars_pointpillars, skills_tao_train_pose_classification_pose_classification, skills_tao_train_reid_reid [EXTRACTED 1.00]
- **TAO Model Training Suite** — skills_tao_train_segformer_skill, skills_tao_train_sparse4d_skill, skills_tao_train_visual_changenet_skill [INFERRED 1.00]
- **TileGym Kernel Conversion Suite** — skills_tilegym_adding_cutile_kernel_skill, skills_tilegym_converting_cutile_to_julia_skill, skills_tilegym_converting_cutile_to_triton_skill [INFERRED 1.00]
- **Deep Agent Orchestration Pipeline** — skills_tilegym_cutile_python_orchestration_analyzer, skills_tilegym_cutile_python_orchestration_kernel, skills_tilegym_cutile_python_orchestration_composer [EXTRACTED 1.00]
- **VSS Deployment Ecosystem** — skills_vss_deploy_dense_captioning, skills_vss_deploy_detection_tracking_2d, skills_vss_deploy_detection_tracking_3d, skills_vss_deploy_video_embedding [EXTRACTED 1.00]
- **VSS Analytics Pipeline** — skills_vss_setup_behavior_analytics, skills_vss_setup_video_analytics_api, skills_vss_query_analytics [INFERRED 0.90]
- **VSS Video Reporting Flow** — skills_vss_generate_video_report, skills_vss_manage_video_io_storage, skills_vss_summarize_video [EXTRACTED 1.00]
- **Video Summarization Execution Flow** — skills_vss_summarize_video_skill, skills_vss_manage_video_io_storage_skill, skills_vss_summarize_video_lvs_service, skills_vss_summarize_video_vlm_endpoint [EXTRACTED 1.00]
- **Video Summarization Reference Material** — skills_vss_summarize_video_ref_api, skills_vss_summarize_video_ref_deployment, skills_vss_summarize_video_ref_debugging, skills_vss_summarize_video_ref_env [EXTRACTED 1.00]

## Communities (147 total, 107 thin omitted)

### Community 0 - "Video Analysis & Deployment"
Cohesion: 0.08
Nodes (32): RT-Embed Video Embedding, RT-VLM Dense Captioning, RTVI-CV 2D Detection/Tracking, RTVI-CV-3D (MV3DT), vss-ask-video, vss-deploy-dense-captioning, vss-deploy-detection-tracking-2d, vss-deploy-detection-tracking-3d (+24 more)

### Community 1 - "LLM Parallelism & Optimization"
Cohesion: 0.10
Nodes (12): Activation Recompute Skill, CPU Offloading Skill, CUDA Graphs Skill, MoE Expert-Parallel Overlap Skill, Hierarchical Context Parallel Skill, Megatron FSDP Skill, Memory Tuning Skill, Parallelism Strategy Selection (+4 more)

### Community 2 - "Jetson BSP Customization"
Cohesion: 0.18
Nodes (19): Build BSP Source Skill, Customize Camera Skill, Customize Clocks Skill, Customize Fan Skill, Customize MGBE Skill, Customize nvpmodel Skill, Customize PCIe Skill, Customize Pinmux Skill (+11 more)

### Community 3 - "Jetson Platform Configuration"
Cohesion: 0.21
Nodes (17): Target Platform Contract, BSP Platforms Catalogue, Platform Template, jetson-customize-pinmux, generate_dtsi.py, modify_pinmux.py, jetson-customize-uphy, jetson-customize-usb (+9 more)

### Community 4 - "Computer Vision Models"
Cohesion: 0.14
Nodes (17): Grounding DINO, Classification PyT, Mask2Former, MAE, MAL, Mask Grounding DINO, ML Recog, NVDINOv2 (+9 more)

### Community 5 - "TAO AutoML Pipelines"
Cohesion: 0.17
Nodes (13): NVIDIA Container Toolkit 1.19.0, AutoML + DEFT Pipeline, tao-run-automl, DEFT Loop Reporter Agent, tao-run-deft-aoi, tao-train-action-recognition, tao-train-bevfusion, tao-train-centerpose (+5 more)

### Community 6 - "Physical AI Infrastructure"
Cohesion: 0.18
Nodes (11): Azure AI Foundry Inference, Azure Cluster, MicroK8s Cluster, NIM Operator Inference, NVCF Inference, OSMO CLI, Physical AI Defect Image Generation, Physical AI Infrastructure Setup And Resilient Scaling (+3 more)

### Community 7 - "Clinical ASR & Riva"
Cohesion: 0.29
Nodes (8): Clinical ASR Build, Clinical ASR Eval, Clinical ASR Finetune, Clinical ASR Setup, Finetune ASR, Riva ASR, Riva ASR Custom, Riva NIM Setup

### Community 8 - "Holoscan Installation"
Cohesion: 0.33
Nodes (7): holoscan-install-container, holoscan-install-debian, holoscan-install-source, holoscan-install-wheel, holoscan-setup, check_conda.sh, check_ngc_image.sh

### Community 9 - "Jetson Diagnostics"
Cohesion: 0.29
Nodes (7): jetson-diagnostic, detect_jetson.sh, mem_summary.sh, snapshot.sh, jetson-headless-mode, apply.sh, plan.sh

### Community 10 - "TAO Execution Platforms"
Cohesion: 0.33
Nodes (7): TAO Inference Microservice, Brev Platform, Kubernetes Platform, Local Docker Platform, SLURM Platform, TAO Execution SDK, tao-setup-nvidia-gpu-host

### Community 11 - "Triton & Kernel Orchestration"
Cohesion: 0.29
Nodes (7): cuTile to Triton Conversion Workflow, Analyzer Agent, Composer Agent, Kernel Agent, Deep Agent Orchestration Workflow, cuTile Python Programming Skill, PyTorch Implementation Tracing Workflow

### Community 12 - "Graphify & Documentation"
Cohesion: 0.40
Nodes (3): Graphify Workflow, graphify skill, sage-waggle skill

### Community 14 - "cuOpt Numerical Optimization"
Cohesion: 0.53
Nodes (6): Linear Programming, Mixed-Integer Linear Programming, Quadratic Programming, cuOpt Numerical Optimization API, Numerical Optimization Formulation, cuOpt Server Python API

### Community 16 - "SageMaker Deployment"
Cohesion: 0.53
Nodes (6): AWS Context Discovery Skill, Python Environment Setup for SageMaker Skill, SageMaker Deployment Planner Skill, SageMaker IAM Preflight Skill, SageMaker Production Defaults Skill, Serving Image Selection Skill

### Community 17 - "Medical Brain Imaging"
Cohesion: 0.33
Nodes (6): nv-generate-mr-brain, nv-generate-mr-brain-finetune, run_mr_brain_finetune.py, run_mr_brain.py, NV-Generate-VAE-Finetune, run_vae_finetune.py

### Community 18 - "TAO Training Workflows"
Cohesion: 0.47
Nodes (6): TAO Train SegFormer, TAO Train Single Step, TAO Train Sparse4D, TAO Train Visual ChangeNet, tao-launch-workflow, tao-run-automl

### Community 19 - "Distributed Training Managers"
Cohesion: 0.40
Nodes (5): DDPManager, FSDP2Manager, MegatronFSDPManager, AutoPipeline, instantiate_infrastructure

### Community 20 - "Model Calibration"
Cohesion: 0.50
Nodes (5): scripts/run_sample_calibration.py, Calibrate Sample Dataset Skill, scripts/run_video_calibration.py, Calibrate from Video Files Skill, Launch AutoMagicCalib Release Containers Skill

### Community 21 - "RAG Evaluation"
Cohesion: 0.50
Nodes (5): NVIDIA RAG Blueprint, evaluate_rag.py, On-disk RAG evaluation, rag-perf CLI, RAG-Perf

### Community 22 - "TAO Inference Services"
Cohesion: 0.50
Nodes (4): tao-run-inference-service, tao-generate-image-grounding, tao-generate-referring-expressions, tao-generate-video-reasoning-annotations

### Community 23 - "Dynamo Routing & Troubleshooting"
Cohesion: 0.83
Nodes (4): Dynamo Interconnect Check, Dynamo Recipe Runner, Dynamo Router Starter, Dynamo Troubleshoot

### Community 24 - "Hugging Face Spaces"
Cohesion: 0.50
Nodes (4): Hugging Face Community Evals, Gradio UI Builder, Gradio LoRA Space Builder, Hugging Face Spaces

### Community 25 - "Jetson LLM Optimization"
Cohesion: 0.50
Nodes (4): jetson-inference-mem-tune, jetson-llm-benchmark, jetson-llm-serve, jetson-speculative-decoding

### Community 26 - "Preflight & Data Augmentation"
Cohesion: 0.50
Nodes (4): pre_submit_guard.py, preflight_credentials.sh, prepare_demo_assets.sh, Physical AI Video Data Augmentation Workflow Orchestrator

### Community 27 - "Waggle Platform SDK"
Cohesion: 0.50
Nodes (4): pluginctl, pywaggle SDK, sesctl, Sage Continuum & Waggle Platform

### Community 28 - "Skill Card Generation"
Cohesion: 0.50
Nodes (4): Skill Card Generator, discover_assets.py, render_card.py, validate_submission.py

### Community 29 - "Distributed Setup Context"
Cohesion: 0.67
Nodes (3): DistributedSetup, MeshContext, create_distributed_setup_from_config

### Community 30 - "AIQ Research & Deployment"
Cohesion: 0.67
Nodes (3): aiq-deploy Skill, scripts/aiq.py, AIQ Research Skill

### Community 31 - "DeepStream Pipeline Tools"
Cohesion: 0.67
Nodes (3): DeepStream Pipeline Builder, DeepStream Import Vision Model, DeepStream Profiling Skill

### Community 32 - "Earth2Studio Installation"
Cohesion: 0.67
Nodes (3): Earth2Studio Deterministic Forecast Skill, Earth2Studio Discoverability Skill, Earth2Studio Installation Skill

### Community 33 - "HSB Application Setup"
Cohesion: 0.67
Nodes (3): hsb-app, hsb-setup, hsb-test

### Community 34 - "HF Model Training"
Cohesion: 0.67
Nodes (3): Hugging Face LLM Trainer, Trackio Experiment Tracking, Hugging Face Vision Trainer

### Community 35 - "Jetson LLM Packaging"
Cohesion: 1.00
Nodes (3): jetson-llm-benchmark, jetson-llm-serve, jetson-package

### Community 36 - "Research & Session Memory"
Cohesion: 0.67
Nodes (3): Auto Research, Brev Etiquette, Session Memory

### Community 37 - "Medical Reasoning & Skills"
Cohesion: 0.67
Nodes (3): NV-Reason-CXR, run_nv_reason_cxr.py, NVIDIA Skill Finder

## Knowledge Gaps
- **244 isolated node(s):** `accelerated-computing-cudf skill`, `aiq-deploy skill`, `Graphify Workflow`, `pywaggle2 Acquisition Ladder`, `Two-Layer Cache Eviction` (+239 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **107 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What connects `accelerated-computing-cudf skill`, `aiq-deploy skill`, `Graphify Workflow` to the rest of the system?**
  _244 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Video Analysis & Deployment` be split into smaller, more focused modules?**
  _Cohesion score 0.08266129032258064 - nodes in this community are weakly interconnected._
- **Should `LLM Parallelism & Optimization` be split into smaller, more focused modules?**
  _Cohesion score 0.09956709956709957 - nodes in this community are weakly interconnected._
- **Should `Computer Vision Models` be split into smaller, more focused modules?**
  _Cohesion score 0.13970588235294118 - nodes in this community are weakly interconnected._